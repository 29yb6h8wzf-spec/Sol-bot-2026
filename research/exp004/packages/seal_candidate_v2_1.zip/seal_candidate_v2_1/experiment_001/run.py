"""Experiment 001 (v2) - reference-run based Gross vs Net. Research / paper only: no exchange client, no engine edits."""
from __future__ import annotations

import argparse
import glob
import json
import os
from dataclasses import asdict, dataclass

import numpy as np
import pandas as pd

from .baseline import run_baseline
from .commission import check_fee_scenario
from .compare import (FP_MODES, decompose_fixed_path, funding_convention_check, funding_exit_candle_uncertainty,
                      match_zero_cost, overlay_comparison, reconcile)
from .costs import FundingIndex
from .metrics import bootstrap_ci, clean, max_drawdown, profit_factor, summarize
from .records import load_records
from .strict_repro import check_reproduction


@dataclass(frozen=True)
class Thresholds:
    """Fixed BEFORE looking at results. Do not tune after seeing data."""
    reconcile_tol: float = 1e-9
    identity_tol: float = 1e-9
    max_path_changed_share: float = 0.005
    max_newly_filled_share: float = 0.005
    max_gross_undefined_share: float = 0.005


CAVEATS = [
    "Reference trades come from the REAL engine run with original costs; nothing is re-scanned to build the Gross set.",
    "Fixed-path Gross = same trades, entry at bar open, exit at engine exit_ref, zero costs.",
    "Engine 'gross_r' is post-slippage; slippage cost here = fixed-path gross minus engine gross_r (includes the "
    "risk-denominator effect). Cost order slippage -> fees -> funding is a convention; shares are order-dependent.",
    "Given proposal-fixed stop/target, slippage changes a path only via the invalid-levels-at-fill rejection; "
    "router/non-overlap/daily-limit effects were not visible and are tested only via the zero-cost re-run match.",
    "Random baseline: no-overlap scope strategy+symbol, same-bar stop-first, funding window convention checked vs reference.",
    "No out-of-sample split here. No claim of profitability.",
]


def _series_summary(df: pd.DataFrame, col: str) -> dict:
    r = df.sort_values("exit_time")[col].dropna().to_numpy(float)
    if not len(r):
        return {"n": 0}
    return {"n": int(len(r)), "expectancy_r": float(r.mean()), "total_r": float(r.sum()),
            "win_rate": float((r > 0).mean()), "profit_factor": profit_factor(r), "max_drawdown_r": max_drawdown(r)}


def classify(overall: dict, ci: tuple) -> dict:
    ge, ne = overall["gross_fixed_path"]["expectancy_r"], overall["net_reference_formula"]["expectancy_r"]
    cost = overall["costs_r"]["per_trade"]
    comp = {k: v / overall["n"] for k, v in overall["costs_r"].items() if k in ("fees", "slippage", "funding")}
    if ge <= 0 or ci[0] <= 0:
        code = "NO_PROVEN_GROSS_EDGE"
        text = "Gross edge not established on the fixed path (gross <= 0 or CI95 includes 0). Costs add on top."
    elif ne <= 0:
        code, text = "COSTS_ERASE_GROSS_EDGE", "Gross edge appears real (CI95 > 0) but costs erase it."
    else:
        code, text = "NET_POSITIVE_UNVERIFIED", "Net > 0 in-sample only. Needs out-of-sample + paper trading."
    v = {"code": code, "text": text, "gross_expectancy_r": ge, "gross_ci95": list(ci), "net_expectancy_r": ne,
         "cost_per_trade_r": cost, "cost_components_per_trade_r": comp}
    if ne < 0:
        v["loss_attribution_accounting_identity"] = {
            "signal_part_(-gross)_share": (-ge) / (-ne), "cost_part_share": cost / (-ne)}
        v["primary_driver"] = "signal_quality" if (-ge) > cost else "costs"
        if ge < 0:
            v["note"] = "gross < 0 AND costs > 0: both contribute; 'primary_driver' is the larger part."
    return v


def run_experiment(ref_src, zero_src=None, candles: dict | None = None, funding: dict | None = None,
                   n_runs: int = 500, seed: int = 20261111, warmup_bars: int = 300,
                   th: Thresholds = Thresholds(), expected: dict | None = None,
                   expected_abs_tol: float = 1e-6, tier: str = "H", legacy_baseline: bool = True,
                   commission_records=None, source_digest: str | None = None) -> tuple[dict, dict]:
    """tier 'H' = historical replication (strict reproduction gate applies);
    tier 'C' = confirmatory on unseen data (no original to reproduce -> that gate is not applicable)."""
    if tier not in ("H", "C"):
        raise ValueError("tier must be 'H' or 'C'")
    ref = load_records(ref_src)
    filled = ref[ref["status"] == "FILLED"].reset_index(drop=True)
    rej = ref[ref["status"] == "REJECTED"]
    recon_rep, recon_df = reconcile(filled, th.reconcile_tol)
    fp_all = decompose_fixed_path(filled)
    undefined = fp_all["r_gross"].isna()
    fp = fp_all[~undefined].reset_index(drop=True)
    ref_col = "engine_net_r" if "engine_net_r" in filled.columns and filled["engine_net_r"].notna().all() else "r_full"
    report: dict = {"meta": {"seed": seed, "n_runs": n_runs, "thresholds": asdict(th),
                             "n_proposals": int(len(ref)), "n_filled": int(len(filled)), "n_rejected": int(len(rej)),
                             "reject_reasons": rej["reject_reason"].value_counts().to_dict()
                             if "reject_reason" in rej.columns else {},
                             "caveats": CAVEATS}}
    ref_src_df = filled if ref_col != "r_full" else fp_all
    report["reference_net"] = {"source_column": ref_col, "overall": _series_summary(ref_src_df, ref_col),
                               "by_strategy": {k: _series_summary(g, ref_col) for k, g in ref_src_df.groupby("strategy")}}
    report["fixed_path_gross"] = {
        "n_gross_undefined_excluded": int(undefined.sum()),
        "overall": summarize(fp, FP_MODES),
        "by_strategy": {k: summarize(g, FP_MODES) for k, g in fp.groupby("strategy")},
        "by_symbol": {k: summarize(g, FP_MODES) for k, g in fp.groupby("symbol")},
        "by_strategy_symbol": {f"{a}|{b}": summarize(g, FP_MODES) for (a, b), g in fp.groupby(["strategy", "symbol"])}}
    report["cost_decomposition"] = {
        "engine_formulas": {k: report["fixed_path_gross"]["overall"]["costs_r"][k] for k in ("fees", "slippage", "funding", "all", "per_trade")},
        "identity_max_abs_err": float(fp_all["identity_err"].max()) if len(fp_all) else 0.0,
        "overlay_model_comparison": overlay_comparison(fp),
        "reconciliation_vs_engine": recon_rep}
    zero_rep = None
    if zero_src is not None:
        zero = load_records(zero_src)
        zero_rep, path_changes = match_zero_cost(ref, zero, fp_all)
    else:
        path_changes = pd.DataFrame()
    report["zero_cost_counterfactual"] = zero_rep or {"provided": False}
    conv = "(t0,t1]"
    if candles and funding:
        checks = {}
        for sym, g in filled.groupby("symbol"):
            if sym in candles and sym in funding:
                t = pd.to_datetime(candles[sym]["time"], utc=True)
                interval = int(pd.Series(t).diff().median().value)
                checks[sym] = funding_convention_check(g, funding[sym], interval)
        report["funding_convention_check"] = checks
        if checks:
            conv = next(iter(checks.values()))["best"]
    ci = bootstrap_ci(fp["r_gross"].to_numpy(), seed=seed) if len(fp) else (float("nan"), float("nan"))
    if candles and legacy_baseline:
        report["random_baseline"] = run_baseline(fp, candles, funding, n_runs, seed, warmup_bars, conv)
    repro = check_reproduction(filled, expected, expected_abs_tol, source_digest) if tier == "H" else {"provided": False, "passed": None, "reason": "not applicable in tier C"}
    report["reference_reproduction"] = repro
    recon_err = filled["reconstruction_error"].fillna("").astype(str) if "reconstruction_error" in filled.columns else None
    n_recon_err = int((recon_err != "").sum()) if recon_err is not None else None
    report["exit_reconstruction"] = {"checked": recon_err is not None, "n_errors": n_recon_err,
                                     "examples": filled.loc[recon_err != "", ["trade_id", "reconstruction_error"]].head(5)
                                     .to_dict("records") if recon_err is not None and n_recon_err else []}
    gates = {
        **({"reproduces_original_reference": bool(repro["passed"])} if tier == "H" else {}),
        "exit_reconstruction_ok": bool(recon_err is not None and n_recon_err == 0),
        "reconciliation_vs_engine": bool(recon_rep.get("passed")),
        "cost_identity": bool(len(fp_all) and report["cost_decomposition"]["identity_max_abs_err"] <= th.identity_tol),
        "gross_defined_share_ok": bool(len(filled) and undefined.sum() / len(filled) <= th.max_gross_undefined_share),
        "zero_cost_run_provided": zero_rep is not None,
        "zero_cost_run_is_actually_zero": bool(zero_rep and zero_rep["zero_run_has_zero_costs"]),
        "path_stable_under_zero_cost": bool(zero_rep and zero_rep["path_changed_share_of_ref_filled"] <= th.max_path_changed_share
                                            and zero_rep["newly_filled_share_of_ref_filled"] <= th.max_newly_filled_share)}
    if funding and "exit_available_ms" in filled.columns and len(filled):
        ambiguity = {}
        for sym, g in filled.groupby("symbol"):
            if sym in funding:
                ambiguity[sym] = funding_exit_candle_uncertainty(g.reset_index(drop=True), funding[sym], 300_000_000_000)
        report["funding_exit_candle_uncertainty"] = ambiguity
    report["commission_check"] = check_fee_scenario(commission_records, sorted(filled["symbol"].unique()),
                                                    float(filled["fee_rate_per_side"].iloc[0]) if len(filled) else 0.0005)
    report["tier"] = tier
    report["gates"] = gates
    failed = [k for k, v in gates.items() if not v]
    if failed:
        report["verdict"] = {"code": "INCONCLUSIVE_GATES_FAILED", "failed_gates": failed,
                             "text": "No conclusion about gross edge is allowed: validation gates failed.",
                             "numbers_for_inspection_only": classify(report["fixed_path_gross"]["overall"], ci)
                             if len(fp) else None}
    else:
        report["verdict"] = classify(report["fixed_path_gross"]["overall"], ci)
        if "random_baseline" in report:
            b = report["random_baseline"]["ALL"]
            report["verdict"]["gross_p_value_vs_random"] = b["gross"]["p_value_ge_actual"]
            report["verdict"]["net_p_value_vs_random"] = b["net"]["p_value_ge_actual"]
    tables = {"trades_fixed_path": fp_all, "reconciliation_trades": recon_df, "path_changes": path_changes}
    return clean(report), tables


def results_markdown(rep: dict) -> str:
    L = ["# Experiment 001 results", "", "## Gates"] + [f"- {k}: {'PASS' if v else 'FAIL'}" for k, v in rep["gates"].items()]
    if not rep["reference_reproduction"]["passed"]:
        L += ["", "### Reference reproduction FAILED", "```", json.dumps(rep["reference_reproduction"], indent=1), "```"]
    ref = rep["reference_net"]["overall"]
    L += ["", "## Reference Net (original engine)", f"n={ref.get('n')} expectancy={ref.get('expectancy_r')} total_R={ref.get('total_r')}"]
    L += ["", "## Fixed-path Gross and cost decomposition (same trades)",
          "| group | n | gross | after slip | after fees | net | cost/trade | flipped |", "|---|---|---|---|---|---|---|---|"]
    fpg = rep["fixed_path_gross"]
    for name, s in [("ALL", fpg["overall"])] + list(fpg["by_strategy"].items()) + list(fpg["by_strategy_symbol"].items()):
        if s.get("n"):
            fl = s["gross_winners_flipped_to_losers"]["rate"]
            L.append(f"| {name.replace('|', ' / ')} | {s['n']} | {s['gross_fixed_path']['expectancy_r']:.3f} | "
                     f"{s['after_slippage']['expectancy_r']:.3f} | {s['after_fees']['expectancy_r']:.3f} | "
                     f"{s['net_reference_formula']['expectancy_r']:.3f} | {s['costs_r']['per_trade']:.3f} | "
                     f"{'n/a' if fl is None else format(fl, '.0%')} |")
    L += ["", "## Zero-cost counterfactual (separate run)", "```", json.dumps(rep["zero_cost_counterfactual"], indent=1), "```",
          "", "## Verdict", "```", json.dumps(rep["verdict"], indent=1), "```"]
    return "\n".join(L)


def load_klines(paths) -> pd.DataFrame:
    frames = []
    for p in paths:
        df = pd.read_csv(p, header=None, usecols=range(6), names=["time", "open", "high", "low", "close", "volume"])
        df = df[pd.to_numeric(df["time"], errors="coerce").notna()].astype(float)
        unit = "us" if df["time"].max() > 1e14 else "ms"
        df["time"] = pd.to_datetime(df["time"].astype("int64"), unit=unit, utc=True)
        frames.append(df)
    return pd.concat(frames).drop_duplicates("time").sort_values("time").reset_index(drop=True)


def load_funding(paths) -> FundingIndex:
    frames = []
    for p in paths:
        df = pd.read_csv(p)
        tcol = next(c for c in df.columns if c in ("calc_time", "fundingTime", "time"))
        rcol = next(c for c in df.columns if c in ("last_funding_rate", "fundingRate", "rate"))
        frames.append(pd.DataFrame({"t": pd.to_datetime(pd.to_numeric(df[tcol]).astype("int64"), unit="ms", utc=True),
                                    "r": df[rcol].astype(float)}))
    f = pd.concat(frames).drop_duplicates("t")
    return FundingIndex(f["t"], f["r"])


def _find(dirpath, symbol, exts):
    hits = [h for e in exts for h in glob.glob(os.path.join(dirpath, f"{symbol}*{e}"))]
    if not hits:
        raise FileNotFoundError(f"No files for {symbol} in {dirpath}")
    return sorted(hits)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--reference", required=True, help="records from the REAL engine, original costs")
    ap.add_argument("--zero-cost", help="records from a separate REAL-engine re-run with fee=slippage=funding=0")
    ap.add_argument("--klines-dir")
    ap.add_argument("--funding-dir")
    ap.add_argument("--out", default="experiment_001_out")
    ap.add_argument("--runs", type=int, default=500)
    ap.add_argument("--seed", type=int, default=20261111)
    ap.add_argument("--warmup", type=int, default=300)
    ap.add_argument("--expected", help="JSON with the ORIGINAL pilot totals: {n_trades, net_r_sum, by_strategy:{..}}")
    ap.add_argument("--expected-abs-tol", type=float, default=1e-6,
                    help="use e.g. 0.005 ONLY if the original summary is rounded to 2 decimals")
    a = ap.parse_args(argv)
    ref = load_records(a.reference)
    syms = sorted(ref["symbol"].unique())
    candles = {s: load_klines(_find(a.klines_dir, s, [".zip", ".csv"])) for s in syms} if a.klines_dir else None
    funding = {s: load_funding(_find(a.funding_dir, s, [".zip", ".csv"])) for s in syms} if a.funding_dir else None
    expected = json.load(open(a.expected)) if a.expected else None
    report, tables = run_experiment(ref, a.zero_cost, candles, funding, a.runs, a.seed, a.warmup,
                                    expected=expected, expected_abs_tol=a.expected_abs_tol)
    os.makedirs(a.out, exist_ok=True)
    json.dump(report, open(os.path.join(a.out, "report.json"), "w"), indent=2)
    for k, t in tables.items():
        t.to_csv(os.path.join(a.out, f"{k}.csv"), index=False)
    md = results_markdown(report)
    open(os.path.join(a.out, "results.md"), "w").write(md)
    print(md)


if __name__ == "__main__":
    main()
