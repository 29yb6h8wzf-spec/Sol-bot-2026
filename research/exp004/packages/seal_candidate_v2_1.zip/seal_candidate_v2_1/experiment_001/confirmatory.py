"""Tier C analysis entry point (pre-registration v2, section 3): gates -> block-bootstrap CIs (gross, net) ->
conditional null p-value -> decision state per arm. NEVER call this on Tier C data before the sealed date."""
from __future__ import annotations

from .block_bootstrap import analyze, sensitivity
from .decision import DecisionConfig, decide_arm
from .null_model import run_conditional_null
from .run import run_experiment


def analyze_arm(name: str, ref, zero, candles: dict, funding: dict | None, cfg: DecisionConfig, *, window_days: int = 182,
                B_boot: int = 10000, n_null: int = 10000, seed: int = 20261111, commission_records=None,
                masks: dict | None = None, confirmatory: bool = True) -> dict:
    report, tables = run_experiment(ref, zero, candles, funding, tier="C", legacy_baseline=False,
                                    commission_records=commission_records)
    fp = tables["trades_fixed_path"]
    fp = fp[fp["r_gross"].notna()].reset_index(drop=True)
    kw = dict(window_days=window_days, alpha_one_sided=cfg.alpha, seed=seed)
    gross = analyze(fp["r_gross"].to_numpy(), fp["exit_time"], B=B_boot, **kw)
    net = analyze(fp["r_full"].to_numpy(), fp["exit_time"], B=B_boot, **kw)
    null_summary, _ = run_conditional_null(fp, candles, funding, n_runs=n_null, seed=seed, masks=masks)
    if confirmatory:
        decision = decide_arm(name, report["gates"], int(len(fp)), int(gross["n_blocks"]), gross, net,
                              null_summary["ALL"]["gross"]["p"], cfg)
    else:
        decision = {"arm": name, "state": "EXPLORATORY_NO_DECISION", "stage_g_rejected": None,
                    "reasons": ["exploratory arm: reported in full, cannot support a decision; promotion needs a new "
                                "pre-registration on new unseen data"]}
    return {"arm": name, "decision": decision, "gross_ci": gross, "net_ci": net,
            "block_sensitivity": {"gross": sensitivity(fp["r_gross"].to_numpy(), fp["exit_time"], window_days=window_days,
                                                       B=min(B_boot, 2000), alpha_one_sided=cfg.alpha, seed=seed),
                                  "net": sensitivity(fp["r_full"].to_numpy(), fp["exit_time"], window_days=window_days,
                                                     B=min(B_boot, 2000), alpha_one_sided=cfg.alpha, seed=seed)},
            "null": null_summary, "gates": report["gates"], "experiment_report": report}


def analyze_family(arms: dict, candles: dict, funding: dict | None, cfg: DecisionConfig, **kw) -> dict:
    """arms: {name: {'ref': df, 'zero': df}}. The same cfg.alpha applies to every arm (family of 2 -> 0.025)."""
    return {n: analyze_arm(n, a["ref"], a["zero"], candles, funding, cfg, **kw) for n, a in arms.items()}


def analyze_protocol(cfg: dict, data: dict, candles: dict, funding: dict | None, *, commission_records=None) -> dict:
    """data = {arm: {'ref': df, 'zero': df}} for every arm named in cfg. Confirmatory arms get a decision state,
    exploratory arms are reported without one. All numbers come from the frozen config."""
    from .config import decision_config
    dc = decision_config(cfg)
    out = {}
    for arm in list(cfg["confirmatory_arms"]) + list(cfg["exploratory_arms"]):
        a = data[arm]
        out[arm] = analyze_arm(arm, a["ref"], a["zero"], candles, funding, dc, window_days=cfg["window_days"],
                               B_boot=cfg["bootstrap_B"], n_null=cfg["null_runs"], seed=cfg["seed"],
                               commission_records=commission_records, confirmatory=arm in cfg["confirmatory_arms"])
    return out
