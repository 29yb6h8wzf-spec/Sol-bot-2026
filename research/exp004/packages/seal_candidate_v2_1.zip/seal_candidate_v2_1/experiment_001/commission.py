"""B9 - account commission-rate record (GET /fapi/v1/commissionRate, USD-M futures) vs the assumed fee scenario.
The primary scenario (5 bp taker, 2 bp maker) stays a SCENARIO; this module only states whether the real account
supports it. Status: VERIFIED | MISMATCH | STALE | MISSING. Never raises on bad data: it reports."""
from __future__ import annotations

import json
import math
from datetime import datetime, timezone

REQUIRED = ("symbol", "makerCommissionRate", "takerCommissionRate", "retrieved_at", "source")


def _num(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if math.isfinite(v) and v >= 0 else None


def parse_records(obj) -> tuple[dict, list]:
    """obj: list of record dicts (or JSON text/path content). Returns ({symbol: rec}, errors)."""
    if isinstance(obj, (str, bytes)):
        obj = json.loads(obj)
    errors, out = [], {}
    if not isinstance(obj, list):
        return {}, ["commission records must be a JSON list"]
    for i, r in enumerate(obj):
        if not isinstance(r, dict) or any(k not in r for k in REQUIRED):
            errors.append(f"record {i}: needs keys {list(REQUIRED)}")
            continue
        maker, taker = _num(r["makerCommissionRate"]), _num(r["takerCommissionRate"])
        try:
            ts = datetime.fromisoformat(str(r["retrieved_at"]).replace("Z", "+00:00"))
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
        except ValueError:
            ts = None
        if maker is None or taker is None or ts is None:
            errors.append(f"record {i} ({r.get('symbol')}): non-numeric rate or bad retrieved_at")
            continue
        out[str(r["symbol"])] = {"maker": maker, "taker": taker, "retrieved_at": ts, "source": r["source"]}
    return out, errors


def check_fee_scenario(records, symbols, taker_assumed: float = 0.0005, maker_assumed: float = 0.0002,
                       now: datetime | None = None, max_age_days: int = 30) -> dict:
    now = now or datetime.now(timezone.utc)
    recs, errors = parse_records(records) if records is not None else ({}, ["no commission records supplied"])
    per, statuses = {}, []
    for s in symbols:
        r = recs.get(s)
        if r is None:
            per[s] = {"status": "MISSING"}
        elif (now - r["retrieved_at"]).days > max_age_days:
            per[s] = {"status": "STALE", "age_days": (now - r["retrieved_at"]).days}
        elif not math.isclose(r["taker"], taker_assumed, rel_tol=0, abs_tol=1e-12) or \
                not math.isclose(r["maker"], maker_assumed, rel_tol=0, abs_tol=1e-12):
            per[s] = {"status": "MISMATCH", "taker_actual": r["taker"], "maker_actual": r["maker"],
                      "taker_assumed": taker_assumed, "maker_assumed": maker_assumed}
        else:
            per[s] = {"status": "VERIFIED", "retrieved_at": r["retrieved_at"].isoformat()}
        statuses.append(per[s]["status"])
    for bad in ("MISMATCH", "STALE", "MISSING"):
        if bad in statuses:
            overall = bad
            break
    else:
        overall = "VERIFIED"
    return {"status": overall, "per_symbol": per, "parse_errors": errors,
            "note": "primary cost scenario is a scenario; MISMATCH/STALE/MISSING means the account fee tier is not demonstrated"}
