"""Random-entry baseline priced with the ENGINE's own accounting (engine_model).

Entry = open of a uniformly random bar (no future information used to pick it). Stop%, RR and horizon are drawn
JOINTLY from the real reference trades of the same (strategy, symbol). Exit rule/fill = engine rule (stop first on
same-bar touches, gap-through stop fills at the open, timeout at last bar close). Costs = the reference run's
rates. No-overlap scope: per SYMBOL across all strategies (engine rule: next_allowed per symbol).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .costs import FundingIndex, to_ns
from .engine_model import find_exit, fill_prices, levels_valid, r_components, zero_cost_gross


@dataclass
class Candles:
    t_ns: np.ndarray
    open: np.ndarray
    high: np.ndarray
    low: np.ndarray
    close: np.ndarray
    pool: np.ndarray
    interval_ns: int


def make_candles(df: pd.DataFrame, warmup_bars: int = 300) -> Candles:
    t = to_ns(df["time"])
    n = len(df)
    idx = np.arange(n)
    ok = (idx >= warmup_bars) & (idx <= n - 2)
    if "valid" in df.columns:
        ok &= df["valid"].to_numpy(bool)
    return Candles(t, df["open"].to_numpy(float), df["high"].to_numpy(float), df["low"].to_numpy(float),
                   df["close"].to_numpy(float), np.flatnonzero(ok), int(np.median(np.diff(t))))


@dataclass
class Spec:
    n: int
    stop_pct: np.ndarray
    rr: np.ndarray
    horizon: np.ndarray
    long_share: float
    fee: float
    slip: float


def build_spec(g: pd.DataFrame) -> Spec:
    risk = np.abs(g["entry_open"] - g["stop"]).to_numpy(float)
    horizon = g["horizon_bars"].to_numpy(float) if "horizon_bars" in g.columns and g["horizon_bars"].notna().all() \
        else np.full(len(g), float(g["held_bars"].max()))
    fees, slips = g["fee_rate_per_side"].unique(), g["slippage_rate_per_side"].unique()
    if len(fees) != 1 or len(slips) != 1:
        raise ValueError("Baseline needs uniform fee/slippage within each (strategy, symbol)")
    return Spec(len(g), risk / g["entry_open"].to_numpy(float),
                np.abs(g["target"] - g["entry_open"]).to_numpy(float) / risk, horizon.astype(int),
                float((g["side"] == 1).mean()), float(fees[0]), float(slips[0]))


def window_sum(fidx: FundingIndex, t0, t1, convention: str):
    return fidx.sum_between(t0, t1) if convention == "(t0,t1]" else fidx.sum_between(t0 - 1, t1 - 1)


def simulate_symbol_run(rng, c: Candles, specs: dict, fidx, convention="(t0,t1]"):
    """One symbol, ONE shared timeline for all strategies (engine: no-overlap per symbol across strategies;
    a rejected fill does not occupy the timeline). Returns {strategy: (gross0_array, net_array)}."""
    names = sorted(specs)
    ns = np.array([specs[k].n for k in names], float)
    cum = np.cumsum(ns) / ns.sum()
    total = int(ns.sum())
    cand = np.unique(c.pool[rng.integers(0, len(c.pool), size=total * 4)]) if len(c.pool) else np.array([], int)
    n_c = len(c.close)
    recs = {k: [] for k in names}
    next_free = -1
    for i in cand:
        if i < next_free:
            continue
        name = names[min(int(np.searchsorted(cum, rng.random(), side="right")), len(names) - 1)]
        spec = specs[name]
        k = int(rng.integers(0, len(spec.stop_pct)))
        side = 1 if rng.random() < spec.long_share else -1
        h = int(spec.horizon[k])
        if i + h > n_c:
            continue
        o = c.open[i]
        stop, target = o * (1 - side * spec.stop_pct[k]), o * (1 + side * spec.stop_pct[k] * spec.rr[k])
        if not bool(levels_valid(side, o * (1 + side * spec.slip), stop, target)):
            continue                                      # engine raises DataRejected; timeline not occupied
        sl = slice(i, i + h)
        _, exit_ref, held = find_exit(side, c.open[sl], c.high[sl], c.low[sl], c.close[sl], stop, target)
        recs[name].append((int(i), side, o, stop, target, exit_ref, held))
        next_free = i + held                              # next entry bar >= entry bar + held (actual_end rule)
    out = {}
    for name in names:
        spec, r = specs[name], recs[name]
        if len(r) > spec.n:
            pick = np.sort(rng.choice(len(r), spec.n, replace=False))
            r = [r[j] for j in pick]
        if not r:
            out[name] = (np.array([]), np.array([]))
            continue
        a = np.array(r, dtype=float)
        i, side, o, stop, target, exit_ref, held = (a[:, j] for j in range(7))
        i, held, side = i.astype(int), held.astype(int), side.astype(int)
        fund = np.zeros(len(i))
        if fidx is not None:
            fund = window_sum(fidx, c.t_ns[i], c.t_ns[i + held - 1] + c.interval_ns, convention)
        entry, exit_fill = fill_prices(side, o, exit_ref, spec.slip)
        _, _, _, net, _ = r_components(side, entry, exit_fill, stop, spec.fee, fund)
        out[name] = (zero_cost_gross(side, o, exit_ref, stop, target), net)
    return out


def run_baseline(fp: pd.DataFrame, candles: dict, funding: dict | None, n_runs=500, seed=20261111,
                 warmup_bars=300, convention="(t0,t1]") -> dict:
    cmap = {s: make_candles(v, warmup_bars) for s, v in candles.items()}
    specs = {}
    for (st, sym), g in fp.groupby(["strategy", "symbol"]):
        if sym not in cmap:
            raise ValueError(f"No candles for {sym}")
        specs.setdefault(sym, {})[st] = build_spec(g)
    strategies = sorted({st for d in specs.values() for st in d})
    acc = {s: np.zeros((n_runs, 4)) for s in strategies}   # gross_sum, gross_n, net_sum, net_n
    for r in range(n_runs):
        rng = np.random.default_rng([seed, r])
        for sym in sorted(specs):
            res = simulate_symbol_run(rng, cmap[sym], specs[sym], (funding or {}).get(sym), convention)
            for st, (g0, net) in res.items():
                ok = ~np.isnan(g0)
                acc[st][r] += (g0[ok].sum(), ok.sum(), net.sum(), len(net))
    acc["ALL"] = sum(acc[s] for s in strategies)
    groups = {s: fp[fp["strategy"] == s] for s in strategies}
    groups["ALL"] = fp
    out = {"n_runs": n_runs, "seed": seed, "warmup_bars": warmup_bars, "funding_convention": convention,
           "no_overlap_scope": "symbol (shared across strategies)"}
    for name, g in groups.items():
        a = acc[name]
        res = {"n_actual": int(len(g)), "mean_n_random": float(a[:, 3].mean())}
        for key, col, s_j, n_j in (("gross", "r_gross", 0, 1), ("net", "r_full", 2, 3)):
            dist = a[:, s_j] / np.maximum(a[:, n_j], 1)
            act = float(g[col].mean(skipna=True))
            res[key] = {"actual_expectancy_r": act, "random_mean": float(dist.mean()),
                        "random_p05": float(np.quantile(dist, .05)), "random_p50": float(np.quantile(dist, .5)),
                        "random_p95": float(np.quantile(dist, .95)),
                        "p_value_ge_actual": float((1 + (dist >= act).sum()) / (1 + n_runs))}
        out[name] = res
    return out
