"""Faithful replica of signals_v2/replay.py trade math (as pasted by the project owner).

This module is an ORACLE / accounting layer. It never replaces the real engine:
the reference trades come from the real engine; these formulas are used to (a) reconcile
the exported engine numbers trade by trade, (b) build the fixed-path zero-cost view,
(c) price random-entry trades with identical accounting.

Facts taken from the engine snippet:
  entry      = next_bar.open * (1 + side*slip)                (adverse)
  stop/target are PROPOSAL references (not re-derived from the fill)
  stop is checked before target inside the same bar; stop fill = min(stop, open) long / max(stop, open) short
  exit_fill  = exit_ref * (1 - side*slip)
  risk       = |entry - stop|  (entry INCLUDES slippage)
  engine "gross_r" is therefore AFTER slippage, BEFORE fee/funding.
Consequence: given fixed stop/target, slippage can change the PATH only through the
"invalid levels at fill" rejection; fees and funding never change the path.
"""
from __future__ import annotations

import numpy as np


class DataRejected(Exception):
    pass


def find_exit(side, bar_open, bar_high, bar_low, bar_close, stop, target):
    """Vectorized equivalent of the engine's per-bar loop. Returns (reason, exit_ref, held_bars)."""
    if side == 1:
        s, t = bar_low <= stop, bar_high >= target
    else:
        s, t = bar_high >= stop, bar_low <= target
    hit = s | t
    if hit.any():
        k = int(hit.argmax())
        if s[k]:  # stop wins if both touched in the same bar
            ref = min(stop, bar_open[k]) if side == 1 else max(stop, bar_open[k])
            return "STOP", float(ref), k + 1
        return "TARGET", float(target), k + 1
    return "TIMEOUT", float(bar_close[-1]), len(bar_close)


def levels_valid(side, entry, stop, target):
    side, entry, stop, target = map(np.asarray, (side, entry, stop, target))
    return np.where(side == 1, (stop < entry) & (entry < target), (target < entry) & (entry < stop))


def fill_prices(side, entry_open, exit_ref, slip):
    return entry_open * (1 + side * slip), exit_ref * (1 - side * slip)


def r_components(side, entry, exit_fill, stop, fee_rate, funding_total):
    """Exactly the engine's formulas. Returns gross_r (post-slippage), fee_r, funding_r, net_r, risk."""
    risk = np.abs(entry - stop)
    gross = side * (exit_fill - entry) / risk
    fee = fee_rate * (entry + exit_fill) / risk
    fund = side * funding_total * entry / risk
    return gross, fee, fund, gross - fee - fund, risk


def zero_cost_gross(side, entry_open, exit_ref, stop, target):
    """Same path, zero costs: entry at the bar open, exit at exit_ref. NaN where levels are invalid at the open
    (the engine would reject such a trade in a zero-slippage run)."""
    risk = np.abs(entry_open - stop)
    ok = levels_valid(side, entry_open, stop, target)
    with np.errstate(divide="ignore", invalid="ignore"):
        g = side * (exit_ref - entry_open) / risk
    return np.where(ok, g, np.nan)
