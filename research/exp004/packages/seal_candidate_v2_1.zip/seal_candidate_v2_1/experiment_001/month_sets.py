"""Seal-time assertions for Experiment 002 (metadata only; opens no outcome data)."""
from datetime import date

HISTORICAL = [f"{y}-{m:02d}" for y, m in [(2024, 11), (2024, 12)] + [(2025, k) for k in range(1, 13)] + [(2026, k) for k in range(1, 11)]]
CONFIRMATORY_START = date(2026, 12, 1)
CONFIRMATORY = ["2026-12", "2027-01", "2027-02", "2027-03", "2027-04", "2027-05"]
UNUSED_BUFFER = ["2026-11"]


def assert_month_sets(seal_date: date, historical=HISTORICAL, confirmatory=CONFIRMATORY, buffer=UNUSED_BUFFER):
    assert len(historical) == 24 and len(set(historical)) == 24, "historical must be exactly 24 distinct months"
    assert historical == sorted(historical), "historical months must be chronological"
    assert not set(historical) & set(confirmatory), "historical and confirmatory overlap"
    assert not set(buffer) & (set(historical) | set(confirmatory)), "buffer month reused"
    assert confirmatory == sorted(confirmatory) and min(confirmatory) > max(historical), "confirmatory must be strictly later"
    assert min(confirmatory) > max(buffer), "buffer must precede confirmatory"
    y, m = map(int, min(confirmatory).split("-"))
    assert date(y, m, 1) > seal_date, "confirmatory data must start after the seal date"
    return True
