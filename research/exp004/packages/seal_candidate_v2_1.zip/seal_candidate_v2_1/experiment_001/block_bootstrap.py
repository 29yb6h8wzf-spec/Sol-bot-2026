"""B3 - synchronized calendar-block studentized bootstrap for the mean R per trade.

Why: trades inside a week (and SOL/XRP at the same time) are dependent; a trade-level bootstrap understates uncertainty
(audit finding 3). Blocks are calendar blocks (default 7 days, aligned to Mondays UTC) shared by BOTH symbols.
Statistic: mu = sum(R) / n over all trades (ratio estimator over blocks). Studentized (bootstrap-t) with the cluster-robust
SE so that 26 blocks still give near-nominal size. Same function is used for gross and for net.
Interval level = 1 - 2*alpha_one_sided: the lower bound is the one-sided alpha bound, the upper bound is the opposite tail.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

ORIGIN = pd.Timestamp("2024-01-01", tz="UTC")   # a Monday: 7-day blocks coincide with ISO weeks


def block_ids(times, block_days: int = 7) -> np.ndarray:
    t = pd.DatetimeIndex(pd.to_datetime(times, utc=True))
    return np.floor((t - ORIGIN).total_seconds().to_numpy() / 86400.0 / block_days).astype(np.int64)


def _cluster(values, blocks):
    values = np.asarray(values, float)
    ub, inv = np.unique(blocks, return_inverse=True)
    S = np.bincount(inv, weights=values, minlength=len(ub))
    n = np.bincount(inv, minlength=len(ub)).astype(float)
    return ub, S, n


def studentized_block_bootstrap(values, blocks, *, alpha_one_sided: float = 0.025, B: int = 10000, seed: int = 20261111,
                                window_blocks: int | None = None) -> dict:
    values = np.asarray(values, float)
    if not np.isfinite(values).all():
        raise ValueError("non-finite values")
    ub, S, n = _cluster(values, blocks)
    G = len(ub)
    out = {"method": "studentized_block_bootstrap", "level": 1 - 2 * alpha_one_sided, "alpha_one_sided": alpha_one_sided,
           "B": B, "seed": seed, "n": int(n.sum()), "n_blocks": int(G),
           "n_empty_blocks": (int(window_blocks - G) if window_blocks is not None else None)}
    if G < 3:
        out.update(point=float("nan"), se=float("nan"), lo=float("nan"), hi=float("nan"), note="fewer than 3 non-empty blocks")
        return out
    mu = S.sum() / n.sum()
    resid = S - mu * n
    se = np.sqrt(G / (G - 1) * (resid ** 2).sum()) / n.sum()
    out.update(point=float(mu), se=float(se))
    if se == 0:
        out.update(lo=float(mu), hi=float(mu), note="zero variance")
        return out
    rng = np.random.default_rng(seed)
    counts = rng.multinomial(G, np.full(G, 1.0 / G), size=B).astype(float)
    n_star = counts @ n
    S_star = counts @ S
    ok = n_star > 0
    mu_star = np.where(ok, S_star / np.where(ok, n_star, 1), 0.0)
    q = counts @ (S ** 2) - 2 * mu_star * (counts @ (S * n)) + mu_star ** 2 * (counts @ (n ** 2))
    se_star = np.sqrt(np.maximum(G / (G - 1) * q, 0.0)) / np.where(ok, n_star, 1)
    good = ok & (se_star > 0)
    t_star = (mu_star[good] - mu) / se_star[good]
    a = alpha_one_sided
    out["lo"] = float(mu - np.quantile(t_star, 1 - a) * se)
    out["hi"] = float(mu - np.quantile(t_star, a) * se)
    out["B_effective"] = int(good.sum())
    return out


def analyze(values, exit_times, *, block_days: int = 7, window_days: int | None = None, **kw) -> dict:
    blocks = block_ids(exit_times, block_days)
    wb = None if window_days is None else int(np.ceil(window_days / block_days))
    r = studentized_block_bootstrap(values, blocks, window_blocks=wb, **kw)
    r["block_days"] = block_days
    return r


def sensitivity(values, exit_times, *, window_days=None, block_days_list=(7, 14, 1), **kw) -> dict:
    """Primary = 7 days; 14-day and 1-day blocks reported as sensitivity (never used for the decision)."""
    return {str(d): analyze(values, exit_times, block_days=d, window_days=window_days, **kw) for d in block_days_list}


def naive_trade_bootstrap_lower(values, alpha_one_sided=0.025, B=2000, seed=1) -> float:
    """Trade-level percentile bootstrap lower bound - kept ONLY to demonstrate the problem in tests."""
    v = np.asarray(values, float)
    rng = np.random.default_rng(seed)
    means = rng.choice(v, size=(B, v.size), replace=True).mean(axis=1)
    return float(np.quantile(means, alpha_one_sided))
