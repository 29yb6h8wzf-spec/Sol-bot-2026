"""B4 - conditional random-entry null (replaces the v1 random baseline for Tier C).

Held fixed (taken from the real run): decision grid (entry bar = 64 + 12k), eligibility masks, month/week structure,
per-symbol per-week trade counts and strategy labels, per-symbol long share, per-(symbol, strategy) geometry
(stop%, RR, horizon) sampled jointly, engine fill/exit/cost accounting, overlap rule (per symbol across strategies:
next entry bar >= entry bar + held; rejected fills do not occupy the timeline).
Randomized: WHICH eligible grid points fire inside each week, and the direction.
Known approximation (disclosed): inside a week the first c_w feasible points of a random subset are taken, so a
week's trades are slightly earlier in the week than the real ones; size is verified by simulation (scripts/calibrate_null.py).
p = (1 + k) / (1 + B) with paired exceedance flags kept for gross AND net (they need not coincide run by run).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from .block_bootstrap import block_ids
from .costs import FundingIndex, to_ns
from .engine_model import find_exit, fill_prices, levels_valid, r_components, zero_cost_gross


@dataclass
class _Geom:
    stop_pct: np.ndarray
    rr: np.ndarray
    horizon: np.ndarray


@dataclass
class _SymbolSpec:
    weeks: dict            # week id -> list of strategy labels (real executed trades)
    geom: dict             # strategy -> _Geom
    long_share: float
    fee: float
    slip: float


def _bars(df: pd.DataFrame):
    t = to_ns(df["time"])
    return {"t": t, "o": df["open"].to_numpy(float), "h": df["high"].to_numpy(float), "l": df["low"].to_numpy(float),
            "c": df["close"].to_numpy(float), "interval": int(np.median(np.diff(t))),
            "week": block_ids(df["time"], 7)}


def build_spec(fp_sym: pd.DataFrame, horizon_default: int) -> _SymbolSpec:
    fees, slips = fp_sym["fee_rate_per_side"].unique(), fp_sym["slippage_rate_per_side"].unique()
    if len(fees) != 1 or len(slips) != 1:
        raise ValueError("uniform fee/slippage required per symbol")
    weeks = {}
    for w, g in fp_sym.groupby(block_ids(fp_sym["entry_time"], 7)):
        weeks[int(w)] = list(g["strategy"])
    geom = {}
    for st, g in fp_sym.groupby("strategy"):
        risk = np.abs(g["entry_open"] - g["stop"]).to_numpy(float)
        hz = g["horizon_bars"].to_numpy(float) if "horizon_bars" in g.columns and g["horizon_bars"].notna().all() \
            else np.full(len(g), float(horizon_default))
        geom[st] = _Geom(risk / g["entry_open"].to_numpy(float),
                         np.abs(g["target"] - g["entry_open"]).to_numpy(float) / risk, hz.astype(int))
    return _SymbolSpec(weeks, geom, float((fp_sym["side"] == 1).mean()), float(fees[0]), float(slips[0]))


def _grid(b, stride, first_entry, horizon, mask):
    n = len(b["c"])
    e = np.arange(first_entry, n - horizon + 1, stride)
    if mask is not None:
        e = e[np.asarray(mask, bool)[e]]
    return e, b["week"][e]


def _one_run(rng, b, spec: _SymbolSpec, grid, grid_week, fidx, convention):
    n = len(b["c"])
    next_free, rows = -1, []
    by_week = {}
    for w in np.unique(grid_week):
        by_week[int(w)] = grid[grid_week == w]
    for w in sorted(spec.weeks):
        labels, pts = spec.weeks[w], by_week.get(w)
        if pts is None or len(pts) == 0:
            continue
        cand = np.sort(rng.choice(pts, min(len(pts), 3 * len(labels)), replace=False))
        order = list(rng.permutation(len(labels)))
        slot = 0
        for e in cand:
            if slot >= len(labels):
                break
            if e < next_free:
                continue
            st = labels[order[slot]]
            gm = spec.geom[st]
            k = int(rng.integers(0, len(gm.stop_pct)))
            side = 1 if rng.random() < spec.long_share else -1
            h = int(gm.horizon[k])
            if e + h > n:
                continue
            o = b["o"][e]
            stop, target = o * (1 - side * gm.stop_pct[k]), o * (1 + side * gm.stop_pct[k] * gm.rr[k])
            if not bool(levels_valid(side, o * (1 + side * spec.slip), stop, target)):
                continue
            sl = slice(e, e + h)
            _, exit_ref, held = find_exit(side, b["o"][sl], b["h"][sl], b["l"][sl], b["c"][sl], stop, target)
            rows.append((st, e, side, o, stop, target, exit_ref, held))
            next_free = e + held
            slot += 1
    return rows


def _score(rows, b, spec, fidx, convention):
    if not rows:
        return np.array([]), np.array([]), []
    names = [r[0] for r in rows]
    a = np.array([r[1:] for r in rows], float)
    e, side, o, stop, target, exit_ref, held = (a[:, j] for j in range(7))
    e, side, held = e.astype(int), side.astype(int), held.astype(int)
    fund = np.zeros(len(e))
    if fidx is not None:
        t0, t1 = b["t"][e], b["t"][e + held - 1] + b["interval"]
        fund = fidx.sum_between(t0, t1) if convention == "(t0,t1]" else fidx.sum_between(t0 - 1, t1 - 1)
    entry, exit_fill = fill_prices(side, o, exit_ref, spec.slip)
    _, _, _, net, _ = r_components(side, entry, exit_fill, stop, spec.fee, fund)
    return zero_cost_gross(side, o, exit_ref, stop, target), net, names


def run_conditional_null(fp: pd.DataFrame, candles: dict, funding: dict | None = None, *, n_runs: int = 1000,
                         seed: int = 20261111, stride: int = 12, first_entry: int = 64, horizon_bars: int = 48,
                         masks: dict | None = None, convention: str = "(t0,t1]") -> tuple[dict, dict]:
    syms = sorted(fp["symbol"].unique())
    bars = {s: _bars(candles[s]) for s in syms}
    specs = {s: build_spec(fp[fp["symbol"] == s], horizon_bars) for s in syms}
    grids = {s: _grid(bars[s], stride, first_entry, horizon_bars, (masks or {}).get(s)) for s in syms}
    strategies = sorted(fp["strategy"].unique())
    G = np.zeros((n_runs, 1 + len(strategies), 2))     # sums gross/net per [ALL, strategies...]
    N = np.zeros((n_runs, 1 + len(strategies), 2))
    for r in range(n_runs):
        rng = np.random.default_rng([seed, r])
        for s in syms:
            rows = _one_run(rng, bars[s], specs[s], *grids[s], (funding or {}).get(s), convention)
            g0, net, names = _score(rows, bars[s], specs[s], (funding or {}).get(s), convention)
            if not len(net):
                continue
            ok = ~np.isnan(g0)
            names = np.array(names)
            for j, st in enumerate([None] + strategies):
                m = np.ones(len(net), bool) if st is None else (names == st)
                G[r, j, 0] += g0[m & ok].sum(); G[r, j, 1] += (m & ok).sum()
                N[r, j, 0] += net[m].sum(); N[r, j, 1] += m.sum()
    arrays, summary = {}, {"n_runs": n_runs, "seed": seed, "stride": stride, "first_entry_bar": first_entry,
                           "convention": convention, "approximation": "first c_w feasible points of a random subset per week"}
    for j, st in enumerate(["ALL"] + strategies):
        sub = fp if st == "ALL" else fp[fp["strategy"] == st]
        dist_g = G[:, j, 0] / np.maximum(G[:, j, 1], 1)
        dist_n = N[:, j, 0] / np.maximum(N[:, j, 1], 1)
        act_g, act_n = float(sub["r_gross"].mean(skipna=True)), float(sub["r_full"].mean())
        ex_g, ex_n = dist_g >= act_g, dist_n >= act_n
        arrays[st] = {"gross": dist_g, "net": dist_n, "exceed_gross": ex_g, "exceed_net": ex_n}
        p_g, p_n = (1 + ex_g.sum()) / (1 + n_runs), (1 + ex_n.sum()) / (1 + n_runs)
        summary[st] = {"n_actual": int(len(sub)), "mean_n_null": float(N[:, j, 1].mean()),
                       "shortfall_share": float(1 - N[:, j, 1].mean() / max(len(sub), 1)),
                       "gross": {"actual": act_g, "null_mean": float(dist_g.mean()), "p": float(p_g),
                                 "mc_se": float(np.sqrt(p_g * (1 - p_g) / n_runs))},
                       "net": {"actual": act_n, "null_mean": float(dist_n.mean()), "p": float(p_n),
                               "mc_se": float(np.sqrt(p_n * (1 - p_n) / n_runs))},
                       "paired_flags_identical_share": float((ex_g == ex_n).mean())}
    return summary, arrays
