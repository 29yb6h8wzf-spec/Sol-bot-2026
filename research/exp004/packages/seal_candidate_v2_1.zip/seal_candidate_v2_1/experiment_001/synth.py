"""Synthetic worlds for calibration and tests (no real data). A 'real run' emulates the sequential pilot loop."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .engine_model import find_exit, fill_prices, levels_valid, r_components, zero_cost_gross

STRATS = ("trend_pullback", "volatility_breakout", "liquidity_reversal")


def market(n_bars: int, seed: int, start="2026-12-01", vol=0.002, drift=0.0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    close = 100 * np.exp(np.cumsum(rng.normal(drift, vol, n_bars)))
    open_ = np.concatenate([[100.0], close[:-1]]) * (1 + rng.normal(0, 0.0007, n_bars))
    sp = np.abs(rng.normal(0, 0.001, n_bars))
    return pd.DataFrame({"time": pd.date_range(start, periods=n_bars, freq="5min", tz="UTC"), "open": open_,
                         "high": np.maximum(open_, close) * (1 + sp), "low": np.minimum(open_, close) * (1 - sp),
                         "close": close})


def real_run(candles: dict, rng, *, fire_prob=0.08, foresight=0.0, stride=12, first_entry=64, horizon=48,
             fee=0.0005, slip=0.0002, min_stop_pct=None) -> pd.DataFrame:
    """Emulates the pilot loop: grid, overlap per symbol, rejections release timeline. foresight>0 gives the 'strategy'
    look-ahead knowledge of the next 12 bars' direction (an edge that a valid null must detect)."""
    rows = []
    for sym, df in candles.items():
        o, h, l, c = (df[k].to_numpy(float) for k in ("open", "high", "low", "close"))
        n = len(df)
        next_free = -1
        for e in range(first_entry, n - horizon + 1, stride):
            if e < next_free or rng.random() > fire_prob:
                continue
            if foresight > 0 and rng.random() < foresight:
                side = 1 if c[min(e + 12, n - 1)] > o[e] else -1
            else:
                side = 1 if rng.random() < 0.5 else -1
            sp = float(np.clip(rng.lognormal(np.log(0.003), 0.5), 0.001, 0.02))
            if min_stop_pct is not None and sp < min_stop_pct:
                continue
            stop, target = o[e] * (1 - side * sp), o[e] * (1 + side * sp * 2)
            if not bool(levels_valid(side, o[e] * (1 + side * slip), stop, target)):
                continue
            sl = slice(e, e + horizon)
            reason, exit_ref, held = find_exit(side, o[sl], h[sl], l[sl], c[sl], stop, target)
            entry, exit_fill = fill_prices(side, o[e], exit_ref, slip)
            _, _, _, net, _ = r_components(side, entry, exit_fill, stop, fee, 0.0)
            rows.append(dict(symbol=sym, strategy=STRATS[int(rng.integers(0, 3))], side=side, entry_open=o[e], stop=stop,
                             target=target, exit_ref=exit_ref, exit_reason=reason, held_bars=held, horizon_bars=horizon,
                             entry_time=df["time"].iloc[e], exit_time=df["time"].iloc[e + held - 1],
                             fee_rate_per_side=fee, slippage_rate_per_side=slip,
                             r_gross=float(zero_cost_gross(side, o[e], exit_ref, stop, target)), r_full=float(net)))
            next_free = e + held
    return pd.DataFrame(rows)
