"""Frozen protocol configuration (v2.1). The JSON file is part of the seal manifest."""
from __future__ import annotations

import json
import os

from .decision import DecisionConfig

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_PATH = os.path.join(HERE, "..", "protocol_config_v2_1.json")
REQUIRED = ("protocol_version", "confirmatory_arms", "exploratory_arms", "alpha_one_sided_per_arm", "interval_level",
            "n_min", "min_blocks", "mei_gross", "block_days", "bootstrap_B", "null_runs", "seed", "window_days")


def load_config(path: str | None = None) -> dict:
    with open(path or DEFAULT_PATH) as fh:
        cfg = json.load(fh)
    missing = [k for k in REQUIRED if k not in cfg]
    if missing:
        raise ValueError(f"config missing keys: {missing}")
    if abs(cfg["interval_level"] - (1 - 2 * cfg["alpha_one_sided_per_arm"])) > 1e-12:
        raise ValueError("interval_level must equal 1 - 2*alpha_one_sided_per_arm")
    if abs(cfg["alpha_one_sided_per_arm"] * len(cfg["confirmatory_arms"]) - cfg["alpha_total"]) > 1e-12:
        raise ValueError("alpha_one_sided_per_arm * n_confirmatory_arms must equal alpha_total")
    if set(cfg["confirmatory_arms"]) & set(cfg["exploratory_arms"]):
        raise ValueError("an arm cannot be both confirmatory and exploratory")
    return cfg


def decision_config(cfg: dict) -> DecisionConfig:
    return DecisionConfig(n_min=cfg["n_min"], min_blocks=cfg["min_blocks"], alpha=cfg["alpha_one_sided_per_arm"],
                          mei_gross=dict(cfg["mei_gross"]))
