"""B2 - decision rule of Pre-registration v2 section 3 (per arm), with strict boundary semantics.

Order of evaluation (first match wins):
 1 INVALID                  any gate failed, or any statistic non-finite, or interval level != 1-2*alpha
 2 INCONCLUSIVE_INSUFFICIENT n_trades < n_min or n_blocks < min_blocks
 3 Stage G: reject iff gross.lo > 0 AND null_p_gross < alpha      (strict inequalities)
     -> Stage N (fixed sequence, no extra alpha): net.lo > 0 -> EDGE_NET_SUPPORTED else COSTS_ERASE_EDGE
 4 RETIRE                   Stage G not rejected AND gross.hi < MEI  (strict)
 5 INCONCLUSIVE_POWER       everything else
"Not rejected" never means "zero edge".
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

STATES = ("INVALID", "INCONCLUSIVE_INSUFFICIENT", "EDGE_NET_SUPPORTED", "COSTS_ERASE_EDGE", "RETIRE", "INCONCLUSIVE_POWER",
          "EXPLORATORY_NO_DECISION")   # last one: exploratory arms (e.g. V1 under option C) never receive a decision state


def alpha_for_family(total_alpha: float, n_arms: int) -> float:
    return total_alpha / n_arms


@dataclass(frozen=True)
class DecisionConfig:
    n_min: int                      # no default on purpose: fixed by simulation S-1 and approved before the seal
    min_blocks: int
    alpha: float = 0.025
    mei_gross: dict = field(default_factory=lambda: {"BASE": 0.55, "V1": 0.35})


def _finite(*xs):
    return all(isinstance(x, (int, float)) and math.isfinite(x) for x in xs)


def decide_arm(arm: str, gates: dict, n_trades: int, n_blocks: int, gross: dict, net: dict, null_p_gross: float,
               cfg: DecisionConfig) -> dict:
    """gross/net: dicts with 'lo','hi','level' as produced by block_bootstrap (level must equal 1-2*alpha)."""
    res = {"arm": arm, "state": None, "reasons": [], "stage_g_rejected": None}
    failed = sorted(k for k, v in gates.items() if not v)
    if failed:
        res.update(state="INVALID", reasons=[f"failed gates: {failed}"])
        return res
    for name, ci in (("gross", gross), ("net", net)):
        if not _finite(ci.get("lo"), ci.get("hi")):
            res.update(state="INVALID", reasons=[f"non-finite {name} interval"])
            return res
        if abs(ci.get("level", float("nan")) - (1 - 2 * cfg.alpha)) > 1e-12:
            res.update(state="INVALID", reasons=[f"{name} interval level {ci.get('level')} != 1-2*alpha"])
            return res
    if not _finite(null_p_gross):
        res.update(state="INVALID", reasons=["non-finite null p-value"])
        return res
    if n_trades < cfg.n_min or n_blocks < cfg.min_blocks:
        res.update(state="INCONCLUSIVE_INSUFFICIENT",
                   reasons=[f"n_trades {n_trades} (min {cfg.n_min}), n_blocks {n_blocks} (min {cfg.min_blocks})"])
        return res
    rejected = gross["lo"] > 0 and null_p_gross < cfg.alpha
    res["stage_g_rejected"] = bool(rejected)
    if rejected:
        if net["lo"] > 0:
            res.update(state="EDGE_NET_SUPPORTED", reasons=["gross and net lower bounds > 0"])
        else:
            res.update(state="COSTS_ERASE_EDGE", reasons=["gross edge supported, net lower bound <= 0"])
        return res
    mei = cfg.mei_gross[arm]
    if gross["hi"] < mei:
        res.update(state="RETIRE", reasons=[f"gross upper bound {gross['hi']:.4f} < MEI {mei}"])
        return res
    res.update(state="INCONCLUSIVE_POWER", reasons=["not rejected and upper bound not below MEI"])
    return res


def decide_family(arms: dict, cfg: DecisionConfig) -> dict:
    """arms: {name: dict(gates, n_trades, n_blocks, gross, net, null_p_gross)}. One cfg.alpha for every arm."""
    return {name: decide_arm(name, **a, cfg=cfg) for name, a in arms.items()}
