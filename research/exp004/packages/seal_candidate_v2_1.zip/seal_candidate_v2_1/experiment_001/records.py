"""Canonical trade-record schema exported from the REAL engine (one row per proposal)."""
from __future__ import annotations

import numpy as np
import pandas as pd

REQUIRED = ["trade_id", "symbol", "strategy", "direction", "status", "entry_time", "entry_open", "stop", "target",
            "fee_rate_per_side", "slippage_rate_per_side", "funding_rate_total"]
FILLED_REQUIRED = ["exit_time", "exit_ref", "exit_reason", "held_bars"]
# ReplayResult returns entry_fill, exit_fill, net_r, fee_r, funding_r. engine_gross_r is DERIVED by the exporter as
# net_r + fee_r + funding_r (the engine's own identity). exit_ref and risk are NOT returned by the engine.
ENGINE_COLS = ["engine_entry_fill", "engine_exit_fill", "engine_gross_r", "engine_fee_r", "engine_funding_r", "engine_net_r"]
OPTIONAL = ["horizon_bars", "reject_reason", "signal_time", "exit_available_ms", "reconstruction_error"] + ENGINE_COLS


def make_trade_id(symbol, strategy, signal_time, direction) -> str:
    return f"{symbol}|{strategy}|{pd.Timestamp(signal_time).isoformat()}|{str(direction).upper()}"


def load_records(src) -> pd.DataFrame:
    df = src.copy() if isinstance(src, pd.DataFrame) else (
        pd.read_json(src) if str(src).endswith(".json") else pd.read_csv(src))
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    df["status"] = df["status"].astype(str).str.upper().str.strip()
    if not df["status"].isin(["FILLED", "REJECTED", "FILTERED"]).all():
        raise ValueError("status must be FILLED, REJECTED or FILTERED")
    side = df["direction"].astype(str).str.upper().str.strip().map({"LONG": 1, "SHORT": -1})
    if side.isna().any():
        raise ValueError("direction must be LONG or SHORT")
    df["side"] = side.astype(int)
    if df["trade_id"].duplicated().any():
        raise ValueError("trade_id must be unique")
    for c in ("entry_time", "exit_time"):
        if c in df.columns:
            df[c] = pd.to_datetime(df[c], utc=True)
    num = ["entry_open", "stop", "target", "fee_rate_per_side", "slippage_rate_per_side", "funding_rate_total",
           "exit_ref", "held_bars", "horizon_bars"] + ENGINE_COLS
    for c in num:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    f = df["status"] == "FILLED"
    for c in FILLED_REQUIRED:
        if c not in df.columns or df.loc[f, c].isna().any():
            raise ValueError(f"FILLED rows need non-null {c}")
    if "exit_reason" in df.columns:
        df["exit_reason"] = df["exit_reason"].astype(str).str.upper()
    return df.reset_index(drop=True)
