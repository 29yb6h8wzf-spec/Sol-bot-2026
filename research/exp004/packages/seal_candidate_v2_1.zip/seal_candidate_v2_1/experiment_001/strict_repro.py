"""B1 - strict reproduction gate.

Blind spots of the v1 check (audit finding 10): any dict with unrecognized keys passed; only supplied groups were
compared; offsetting errors inside a group were invisible. This version:
  * validates the expected-file schema EXACTLY (required keys, no unknown keys, types, finite numbers);
  * requires the group set to equal the reference's strategy set in BOTH directions;
  * checks internal consistency of the expected file (group counts/sums add up to the totals);
  * optionally checks a source digest and row-level results (trade_id, net_r, timestamps, exit_reason);
  * states its own limit: grouped totals cannot detect offsetting errors inside a group.
Reproduction proves determinism / internal consistency of the replay, NOT market realism.
"""
from __future__ import annotations

import difflib
import math

import numpy as np
import pandas as pd

REQUIRED_TOP = ("n_trades", "net_r_sum", "by_strategy")
OPTIONAL_TOP = ("source_digest", "trades")
GROUP_KEYS = {"n", "net_r_sum"}
ROW_KEYS = {"trade_id", "net_r", "entry_time", "exit_time", "exit_reason"}


def _is_int(x):
    return isinstance(x, (int, np.integer)) and not isinstance(x, bool)


def _is_num(x):
    return isinstance(x, (int, float, np.integer, np.floating)) and not isinstance(x, bool) and math.isfinite(float(x))


def validate_expected_schema(expected) -> list[str]:
    err: list[str] = []
    if not isinstance(expected, dict) or not expected:
        return ["expected must be a non-empty JSON object"]
    allowed = set(REQUIRED_TOP) | set(OPTIONAL_TOP)
    for k in expected:
        if k not in allowed:
            hint = difflib.get_close_matches(k, allowed, n=1)
            err.append(f"unknown key '{k}'" + (f" (did you mean '{hint[0]}'?)" if hint else ""))
    for k in REQUIRED_TOP:
        if k not in expected:
            err.append(f"missing required key '{k}'")
    if "n_trades" in expected and not (_is_int(expected["n_trades"]) and expected["n_trades"] >= 0):
        err.append("n_trades must be a non-negative integer")
    if "net_r_sum" in expected and not _is_num(expected["net_r_sum"]):
        err.append("net_r_sum must be a finite number")
    bs = expected.get("by_strategy")
    if "by_strategy" in expected:
        if not isinstance(bs, dict) or not bs:
            err.append("by_strategy must be a non-empty object")
        else:
            for name, g in bs.items():
                if not isinstance(g, dict) or set(g) != GROUP_KEYS:
                    err.append(f"by_strategy['{name}'] must have exactly keys {sorted(GROUP_KEYS)}")
                    continue
                if not (_is_int(g["n"]) and g["n"] >= 0):
                    err.append(f"by_strategy['{name}'].n must be a non-negative integer")
                if not _is_num(g["net_r_sum"]):
                    err.append(f"by_strategy['{name}'].net_r_sum must be a finite number")
    if "source_digest" in expected and not (isinstance(expected["source_digest"], str) and expected["source_digest"]):
        err.append("source_digest must be a non-empty string")
    if "trades" in expected:
        rows = expected["trades"]
        if not isinstance(rows, list):
            err.append("trades must be a list")
        else:
            for i, r in enumerate(rows):
                if not isinstance(r, dict) or not {"trade_id", "net_r"} <= set(r) or set(r) - ROW_KEYS:
                    err.append(f"trades[{i}] must contain trade_id, net_r and only keys {sorted(ROW_KEYS)}")
                    break
    return err


def check_reproduction(filled: pd.DataFrame, expected, abs_tol: float = 1e-6, source_digest: str | None = None) -> dict:
    if expected is None:
        return {"provided": False, "passed": False, "reason": "no expected summary supplied"}
    schema_errors = validate_expected_schema(expected)
    out = {"provided": True, "abs_tol": abs_tol, "schema_errors": schema_errors, "differences": [],
           "level": "row_level" if isinstance(expected, dict) and "trades" in expected else "grouped",
           "limit": "grouped totals cannot detect offsetting errors inside a group; the gate proves determinism, not market realism"}
    if schema_errors:
        out["passed"] = False
        return out
    diffs: list[str] = []
    got_n = int(len(filled))
    got_sum = float(filled["engine_net_r"].sum()) if "engine_net_r" in filled.columns else float("nan")
    if expected["n_trades"] != got_n:
        diffs.append(f"n_trades expected {expected['n_trades']} got {got_n}")
    if not abs(expected["net_r_sum"] - got_sum) <= abs_tol:
        diffs.append(f"net_r_sum expected {expected['net_r_sum']} got {got_sum}")
    bs = expected["by_strategy"]
    if sum(g["n"] for g in bs.values()) != expected["n_trades"]:
        diffs.append("expected file inconsistent: group counts do not add up to n_trades")
    if not abs(sum(g["net_r_sum"] for g in bs.values()) - expected["net_r_sum"]) <= abs_tol * (len(bs) + 1):
        diffs.append("expected file inconsistent: group sums do not add up to net_r_sum")
    got_groups = set(filled["strategy"].unique()) if got_n else set()
    exp_groups = set(bs)
    if got_groups != exp_groups:
        diffs.append(f"group set differs: only in reference {sorted(got_groups - exp_groups)}, only in expected {sorted(exp_groups - got_groups)}")
    for name in sorted(got_groups & exp_groups):
        g = filled[filled["strategy"] == name]
        if bs[name]["n"] != len(g):
            diffs.append(f"{name}: n expected {bs[name]['n']} got {len(g)}")
        if not abs(bs[name]["net_r_sum"] - g["engine_net_r"].sum()) <= abs_tol:
            diffs.append(f"{name}: net_r_sum expected {bs[name]['net_r_sum']} got {g['engine_net_r'].sum()}")
    if "source_digest" in expected:
        if source_digest is None:
            diffs.append("expected carries a source_digest but none was supplied to verify it")
        elif source_digest != expected["source_digest"]:
            diffs.append("source_digest mismatch")
    if "trades" in expected:
        rows = {r["trade_id"]: r for r in expected["trades"]}
        if len(rows) != len(expected["trades"]):
            diffs.append("expected trades contain duplicate trade_id")
        mine = filled.set_index("trade_id")
        if set(rows) != set(mine.index):
            diffs.append(f"trade_id sets differ: missing {len(set(rows) - set(mine.index))}, extra {len(set(mine.index) - set(rows))}")
        for tid in sorted(set(rows) & set(mine.index)):
            r, m = rows[tid], mine.loc[tid]
            if not abs(r["net_r"] - m["engine_net_r"]) <= abs_tol:
                diffs.append(f"{tid}: net_r expected {r['net_r']} got {m['engine_net_r']}")
            for k, col in (("entry_time", "entry_time"), ("exit_time", "exit_time")):
                if k in r and pd.Timestamp(r[k]).tz_convert("UTC") != pd.Timestamp(m[col]).tz_convert("UTC"):
                    diffs.append(f"{tid}: {k} expected {r[k]} got {m[col]}")
            if "exit_reason" in r and str(r["exit_reason"]).upper() != str(m["exit_reason"]).upper():
                diffs.append(f"{tid}: exit_reason expected {r['exit_reason']} got {m['exit_reason']}")
        if len(diffs) > 25:
            diffs = diffs[:25] + [f"... {len(diffs) - 25} more"]
    out["got"] = {"n_trades": got_n, "net_r_sum": got_sum}
    out["expected"] = {k: v for k, v in expected.items() if k not in ("by_strategy", "trades")}
    out["differences"] = diffs
    out["passed"] = not diffs
    return out
