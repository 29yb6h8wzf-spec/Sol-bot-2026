from __future__ import annotations

import math

import numpy as np
import pandas as pd

MODES = {"gross": "r_gross", "fees_only": "r_fees",
         "fees_slippage": "r_fees_slip", "full_net": "r_full"}


def max_drawdown(r) -> float:
    r = np.asarray(r, dtype=float)
    if r.size == 0:
        return 0.0
    cum = np.cumsum(r)
    peak = np.maximum.accumulate(np.concatenate(([0.0], cum)))[1:]
    return float((peak - cum).max())


def profit_factor(r):
    r = np.asarray(r, dtype=float)
    gains, losses = r[r > 0].sum(), -r[r < 0].sum()
    return None if losses == 0 else float(gains / losses)


def summarize(g: pd.DataFrame, modes: dict | None = None) -> dict:
    g = g.sort_values("exit_time", kind="stable")
    out: dict = {"n": int(len(g))}
    if len(g) == 0:
        return out
    for name, col in (modes or MODES).items():
        r = g[col].to_numpy()
        out[name] = {
            "expectancy_r": float(r.mean()), "total_r": float(r.sum()),
            "win_rate": float((r > 0).mean()), "profit_factor": profit_factor(r),
            "max_drawdown_r": max_drawdown(r),
        }
    tot = {"fees": g["fee_r"].sum(), "slippage": g["slippage_r"].sum(), "funding": g["funding_r"].sum()}
    out["costs_r"] = {**{k: float(v) for k, v in tot.items()},
                      "all": float(sum(tot.values())), "per_trade": float(sum(tot.values()) / len(g))}
    q = g["stop_dist_pct"].quantile([.1, .25, .5, .75, .9])
    out["stop_dist_pct"] = {f"p{int(k * 100)}": float(v) for k, v in q.items()}
    gw = g[g["r_gross"] > 0]
    flipped = int((gw["r_full"] <= 0).sum())
    out["gross_winners_flipped_to_losers"] = {
        "count": flipped, "of_gross_winners": int(len(gw)),
        "rate": float(flipped / len(gw)) if len(gw) else None}
    months = g["exit_time"].dt.strftime("%Y-%m")
    out["monthly"] = {m: {"n": int(len(x)), "gross_r": float(x["r_gross"].sum()),
                          "full_net_r": float(x["r_full"].sum())}
                      for m, x in g.groupby(months)}
    return out


def sanity_checks(df: pd.DataFrame) -> dict:
    """Detects an input that is NOT a clean gross export (costs already baked into exits)."""
    stops = df[df["exit_reason"].astype(str).str.lower().str.contains("stop")]
    s = {"n_stop_exits": int(len(stops))}
    if len(stops):
        s["stop_exits_gross_r_median"] = float(stops["r_gross"].median())
        s["share_stop_exits_worse_than_minus_1_05R"] = float((stops["r_gross"] < -1.05).mean())
    return s


def bootstrap_ci(r, n_boot=5000, seed=1, alpha=0.05):
    r = np.asarray(r, dtype=float)
    rng = np.random.default_rng(seed)
    means = rng.choice(r, size=(n_boot, r.size), replace=True).mean(axis=1) if r.size * n_boot <= 5e7 \
        else np.array([rng.choice(r, r.size).mean() for _ in range(n_boot)])
    return float(np.quantile(means, alpha / 2)), float(np.quantile(means, 1 - alpha / 2))


def verdict(overall: dict, ci_gross: tuple, baseline_all: dict | None) -> dict:
    ge, ne = overall["gross"]["expectancy_r"], overall["full_net"]["expectancy_r"]
    cost = overall["costs_r"]["per_trade"]
    if ge <= 0:
        code, text = "NO_PROVEN_GROSS_EDGE", "Gross expectancy <= 0: no gross edge even before costs."
    elif ci_gross[0] <= 0:
        code, text = "GROSS_POSITIVE_NOT_SIGNIFICANT", "Gross > 0 but the 95% bootstrap CI includes 0."
    elif ne <= 0:
        code, text = "GROSS_POSITIVE_NET_NEGATIVE", "Gross edge appears real but costs erase it."
    else:
        code, text = "NET_POSITIVE_UNVERIFIED", "Net > 0 in-sample. Needs out-of-sample + paper before any live use."
    v = {"code": code, "text": text, "gross_expectancy_r": ge, "net_expectancy_r": ne,
         "cost_per_trade_r": cost, "gross_expectancy_ci95": list(ci_gross),
         "share_of_net_loss_explained_by_costs": (cost / -ne) if ne < 0 else None}
    if baseline_all:
        v["gross_p_value_vs_random"] = baseline_all["gross"]["p_value_ge_actual"]
        v["net_p_value_vs_random"] = baseline_all["net"]["p_value_ge_actual"]
    return v


def clean(o):
    """Make report JSON-safe (numpy -> python, NaN/inf -> None)."""
    if isinstance(o, dict):
        return {str(k): clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, np.generic):
        o = o.item()
    if isinstance(o, float) and (math.isnan(o) or math.isinf(o)):
        return None
    return o
