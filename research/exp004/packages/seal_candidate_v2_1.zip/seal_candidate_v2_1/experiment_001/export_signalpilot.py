"""Exporter: runs SignalPilot's own decision loop (copied from signals_v3/pilot_replay.py as pasted by the owner)
and records every FILLED / REJECTED proposal in the Experiment-001 schema. Research only; the engine is NOT edited.

How it stays non-invasive
  * The loop below is a line-by-line copy of the pasted loop; every repo function is INJECTED via `Hooks`.
  * The Zero-Cost run changes costs by temporarily overriding the keyword-only defaults of `replay`
    (replay.__kwdefaults__), restored afterwards, and passes funding_rate_total=0.0. After each trade the exporter
    INFERS the costs actually applied from the engine's own result and aborts (ExportError) if they differ from the
    requested ones - a silently ineffective override can never produce a fake "zero-cost" file.
  * ReplayResult has no gross_r / exit_ref / slippage_r. They are reconstructed from the bars with find_exit and the
    engine formulas, and every reconstruction is verified against the engine's own exit_reason / bars_held /
    exit_fill (mismatch -> `reconstruction_error` column, which fails a gate).
Assumptions to confirm in the real repo: Candle has open_ms, available_at_ms, open, high, low, close; Hypothesis has
direction ("LONG"/"SHORT"), stop_reference, target_reference and a strategy name attribute; DataRejected is raised by
guarded_replay (pass the real class in Hooks.rejected_exceptions).
"""
from __future__ import annotations

import bisect
import importlib.util
import json
import os
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Callable

import numpy as np
import pandas as pd

from .engine_model import find_exit


class ExportError(RuntimeError):
    pass


def default_strategy_of(p) -> str:
    for a in ("strategy", "strategy_name", "name"):
        if hasattr(p, a):
            return str(getattr(p, a))
    raise ExportError("Hypothesis has no strategy/strategy_name/name attribute; pass Hooks.strategy_of")


@dataclass
class Hooks:
    eligible: Callable
    candidates: Callable
    replay_hypothesis: Callable
    guarded_replay: Callable
    replay_core: Callable                    # signals_v2.replay.replay (its __kwdefaults__ carry the costs)
    rejected_exceptions: tuple = ()
    strategy_of: Callable = default_strategy_of


def engine_cost_defaults(replay_core) -> dict:
    kw = replay_core.__kwdefaults__
    if not kw or "fee_rate_per_side" not in kw or "slippage_rate_per_side" not in kw:
        raise ExportError("replay_core.__kwdefaults__ lacks fee/slippage defaults; cannot read or override costs")
    return {"fee": kw["fee_rate_per_side"], "slip": kw["slippage_rate_per_side"]}


@contextmanager
def engine_costs(replay_core, fee: float, slip: float):
    kw = replay_core.__kwdefaults__
    if not kw:
        raise ExportError("replay_core has no keyword-only defaults")
    old = dict(kw)
    kw["fee_rate_per_side"], kw["slippage_rate_per_side"] = fee, slip
    try:
        yield
    finally:
        kw.clear()
        kw.update(old)


def make_trade_id(symbol, decision_ms, strategy, direction) -> str:
    """Stable across runs: derived from decision data, never from row order."""
    return f"{symbol}|{int(decision_ms)}|{strategy}|{str(direction).upper()}"


def _ts(ms):
    return pd.to_datetime(int(ms), unit="ms", utc=True)


def _filled_row(base, proposal, future, result, side, fee, slip, rate, decision, actual_end, max_bars):
    stop, target = proposal.stop_reference, proposal.target_reference
    entry_open = future[0].open
    bars = future[:max_bars]
    reason, exit_ref, held = find_exit(side, np.array([b.open for b in bars], float), np.array([b.high for b in bars], float),
                                       np.array([b.low for b in bars], float), np.array([b.close for b in bars], float),
                                       stop, target)
    slip_inf = (result.entry_fill / entry_open - 1.0) * side
    risk = abs(result.entry_fill - stop)
    denom = result.entry_fill + result.exit_fill
    fee_inf = result.fee_r * risk / denom if denom else 0.0
    if abs(slip_inf - slip) > 1e-12 or abs(fee_inf - fee) > 1e-12:
        raise ExportError(f"cost override ineffective: requested fee={fee} slip={slip}; engine applied "
                          f"fee~{fee_inf:.3e} slip~{slip_inf:.3e} ({base['trade_id']})")
    errs = []
    if reason != str(result.exit_reason).upper():
        errs.append(f"exit_reason bars={reason} engine={result.exit_reason}")
    if held != result.bars_held:
        errs.append(f"held bars={held} engine={result.bars_held}")
    if not np.isclose(result.exit_fill, exit_ref * (1 - side * slip), rtol=1e-12, atol=0):
        errs.append(f"exit_fill engine={result.exit_fill} reconstructed={exit_ref * (1 - side * slip)}")
    last = future[result.bars_held - 1]
    return {**base, "status": "FILLED", "reject_reason": "", "entry_open": entry_open,
            "exit_time": _ts(last.open_ms), "exit_available_ms": int(last.available_at_ms),
            "exit_ref": exit_ref, "exit_reason": str(result.exit_reason).upper(), "held_bars": int(result.bars_held),
            "funding_rate_total": rate, "engine_entry_fill": result.entry_fill, "engine_exit_fill": result.exit_fill,
            "engine_gross_r": result.net_r + result.fee_r + result.funding_r, "engine_fee_r": result.fee_r,
            "engine_funding_r": result.funding_r, "engine_net_r": result.net_r,
            "reconstruction_error": "; ".join(errs)}


def export_symbol(symbol, five, one, one_times, funding, intervals, hooks: Hooks, *, stride: int, fee: float, slip: float,
                  funding_enabled: bool, max_bars: int = 48, min_stop_pct: float | None = None) -> list[dict]:
    """min_stop_pct (arm V1): causal filter on DECISION-TIME fields only, applied inside the sequential loop:
    a filtered signal is exported as status FILTERED and does NOT set next_allowed (the timeline is released)."""
    fund_times = [x[0] for x in funding]
    next_allowed, rows = float("-inf"), []
    with engine_costs(hooks.replay_core, fee, slip):
        for i in range(63, len(five) - 48, stride):
            decision = five[i].available_at_ms
            if decision < next_allowed:
                continue
            j = bisect.bisect_right(one_times, decision)
            if j < 45:
                continue
            history = tuple(five[i - 63:i + 1])
            micro = tuple(one[j - 45:j])
            future = tuple(five[i + 1:i + 49])
            ok, _reason = hooks.eligible(intervals, symbol, history[0].open_ms, future[0].open_ms, future[-1].available_at_ms)
            if not ok:
                continue
            proposals = hooks.candidates(symbol, history, micro, decision)
            if not proposals:
                continue
            proposal = hooks.replay_hypothesis(proposals[0])
            side = 1 if proposal.direction == "LONG" else -1
            strategy = hooks.strategy_of(proposal)
            base = {"trade_id": make_trade_id(symbol, decision, strategy, proposal.direction), "symbol": symbol,
                    "strategy": strategy, "direction": proposal.direction, "signal_time": _ts(decision),
                    "entry_time": _ts(future[0].open_ms), "entry_open": future[0].open, "stop": proposal.stop_reference,
                    "target": proposal.target_reference, "horizon_bars": len(future),
                    "fee_rate_per_side": fee, "slippage_rate_per_side": slip}
            if min_stop_pct is not None:
                stop_pct = abs(proposal.entry_reference - proposal.stop_reference) / proposal.entry_reference
                if stop_pct < min_stop_pct:
                    rows.append({**base, "status": "FILTERED", "funding_rate_total": 0.0,
                                 "reject_reason": f"V1_min_stop_pct: {stop_pct:.6f} < {min_stop_pct}"})
                    continue
            try:
                provisional = hooks.guarded_replay(proposal, history, future, intervals, max_bars=max_bars)
                actual_end = future[provisional.bars_held - 1].available_at_ms
                rate = 0.0
                if funding_enabled:
                    start = bisect.bisect_right(fund_times, future[0].open_ms)
                    end = bisect.bisect_right(fund_times, actual_end)
                    rate = sum(x[1] for x in funding[start:end])
                result = hooks.guarded_replay(proposal, history, future, intervals, max_bars=max_bars,
                                              funding_rate_total=rate)
            except hooks.rejected_exceptions as e:       # rejected proposals are exported; next_allowed untouched
                rows.append({**base, "status": "REJECTED", "reject_reason": f"{type(e).__name__}: {e}",
                             "funding_rate_total": 0.0})
                continue
            rows.append(_filled_row(base, proposal, future, result, side, fee, slip, rate, decision, actual_end, max_bars))
            next_allowed = actual_end
    return rows


def summarize_reference(df: pd.DataFrame) -> dict:
    f = df[df["status"] == "FILLED"]
    return {"n_trades": int(len(f)), "net_r_sum": float(f["engine_net_r"].sum()),
            "by_strategy": {k: {"n": int(len(g)), "net_r_sum": float(g["engine_net_r"].sum())} for k, g in f.groupby("strategy")}}


def load_plugin(path):
    spec = importlib.util.spec_from_file_location("signalpilot_plugin", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def main(argv=None):
    """Plugin file must define: SYMBOLS (list), STRIDE (int), hooks() -> Hooks,
    load(symbol) -> (five, one, one_times, funding, intervals), the SAME inputs the original loop uses."""
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--plugin", required=True)
    ap.add_argument("--out", default="experiment_001_inputs")
    a = ap.parse_args(argv)
    plug = load_plugin(a.plugin)
    hooks = plug.hooks()
    orig = engine_cost_defaults(hooks.replay_core)
    os.makedirs(a.out, exist_ok=True)
    runs = {"reference": (orig["fee"], orig["slip"], True), "zero_cost": (0.0, 0.0, False)}
    for name, (fee, slip, fund_on) in runs.items():
        rows = []
        for sym in plug.SYMBOLS:
            five, one, one_times, funding, intervals = plug.load(sym)
            rows += export_symbol(sym, five, one, one_times, funding, intervals, hooks, stride=plug.STRIDE,
                                  fee=fee, slip=slip, funding_enabled=fund_on)
        df = pd.DataFrame(rows)
        df.to_csv(os.path.join(a.out, f"{name}.csv"), index=False)
        if name == "reference":
            json.dump(summarize_reference(df), open(os.path.join(a.out, "reference_summary.json"), "w"), indent=2)
        print(name, "rows:", len(df), "filled:", int((df["status"] == "FILLED").sum()))
    print("Compare reference_summary.json with the ORIGINAL pilot summary, save the original as expected.json, then run "
          "python -m experiment_001.run --reference ... --zero-cost ... --expected expected.json")


if __name__ == "__main__":
    main()
