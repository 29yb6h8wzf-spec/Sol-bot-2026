"""Experiment 001 - Gross vs Net decomposition + random-entry baseline (research only)."""
