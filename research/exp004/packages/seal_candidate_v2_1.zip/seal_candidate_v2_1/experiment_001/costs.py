"""Cost overlay: converts a FIXED set of trades into Gross / Fees / Fees+Slip / Full-Net R.

Design rule: trade paths (entry, stop, target, exit time, exit price) are taken
from the GROSS replay and never change. Costs are applied afterwards, in R units.
Anything the cost model could change about the PATH (e.g. slippage pushing a
stop/target trigger) is explicitly NOT modeled here; see README "Path caveat".

R definition: 1R = qty * |entry - stop|  (the planned risk in quote currency).
  gross_R   = direction * (exit - entry) / |entry - stop|
  fee_R     = fee_rate * (entry + exit)  / |entry - stop|      (both legs, notional/qty)
  slip_R    = slip_rate * (entry + exit) / |entry - stop|
  funding_R = direction * sum(funding_rate in (entry_time, exit_time]) * entry / |entry - stop|
              (positive funding rate => longs pay; cost is positive when paid.
               Notional approximated by entry price; mark-price drift ignored.)
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

REQUIRED_COLUMNS = [
    "symbol", "strategy", "direction", "entry_time", "exit_time",
    "entry", "stop", "target", "exit_price", "exit_reason",
]


@dataclass(frozen=True)
class CostModel:
    fee_per_side: float = 0.0005       # 0.05%
    slippage_per_side: float = 0.0002  # 0.02%


def to_ns(values) -> np.ndarray:
    """Any datetime-like -> int64 nanoseconds since epoch (UTC), independent of pandas unit."""
    idx = pd.DatetimeIndex(pd.to_datetime(values, utc=True))
    return idx.as_unit("ns").asi8


def gross_r(direction, entry, exit_, risk_dist):
    return direction * (exit_ - entry) / risk_dist


def fee_r(entry, exit_, risk_dist, rate):
    return rate * (entry + exit_) / risk_dist


class FundingIndex:
    """Cumulative-sum index of funding rates for one symbol. sum_between is over (t0, t1]."""

    def __init__(self, times, rates):
        ns = to_ns(times)
        r = np.asarray(rates, dtype=float)
        order = np.argsort(ns, kind="stable")
        self.ns = ns[order]
        self.cum = np.concatenate([[0.0], np.cumsum(r[order])])

    def sum_between(self, t0_ns, t1_ns):
        a = np.searchsorted(self.ns, t0_ns, side="right")
        b = np.searchsorted(self.ns, t1_ns, side="right")
        return self.cum[b] - self.cum[a]


def normalize_direction(s: pd.Series) -> pd.Series:
    m = {"long": 1, "buy": 1, "1": 1, "1.0": 1, "short": -1, "sell": -1, "-1": -1, "-1.0": -1}
    out = s.astype(str).str.strip().str.lower().map(m)
    if out.isna().any():
        bad = s[out.isna()].unique()[:5]
        raise ValueError(f"Unrecognized direction values: {bad}")
    return out.astype(int)


def validate_trades(df: pd.DataFrame) -> None:
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    if (df["entry"] == df["stop"]).any():
        raise ValueError("Trade with entry == stop (zero risk distance)")
    if (pd.to_datetime(df["exit_time"], utc=True) < pd.to_datetime(df["entry_time"], utc=True)).any():
        raise ValueError("Trade with exit_time before entry_time")


def apply_costs(trades: pd.DataFrame, funding: dict | None = None,
                cm: CostModel = CostModel()) -> pd.DataFrame:
    """Return a copy of `trades` with cost columns and the four mode columns.
    Row count and all path columns are untouched by construction."""
    validate_trades(trades)
    df = trades.copy().reset_index(drop=True)
    df["entry_time"] = pd.to_datetime(df["entry_time"], utc=True)
    df["exit_time"] = pd.to_datetime(df["exit_time"], utc=True)
    d = normalize_direction(df["direction"]).to_numpy()
    df["direction"] = d
    entry = df["entry"].to_numpy(float)
    exit_ = df["exit_price"].to_numpy(float)
    risk = np.abs(entry - df["stop"].to_numpy(float))

    df["stop_dist_pct"] = risk / entry
    df["gross_r"] = gross_r(d, entry, exit_, risk)
    df["fee_r"] = fee_r(entry, exit_, risk, cm.fee_per_side)
    df["slippage_r"] = fee_r(entry, exit_, risk, cm.slippage_per_side)

    fund = np.zeros(len(df))
    if funding:
        t0 = to_ns(df["entry_time"])
        t1 = to_ns(df["exit_time"])
        for sym, idx in funding.items():
            m = (df["symbol"] == sym).to_numpy()
            if m.any():
                fund[m] = d[m] * idx.sum_between(t0[m], t1[m]) * entry[m] / risk[m]
    if not funding and "funding_rate_total" in df.columns:
        fund = d * df["funding_rate_total"].to_numpy(float) * entry / risk
    df["funding_r"] = fund  # cost convention: positive = paid

    df["r_gross"] = df["gross_r"]
    df["r_fees"] = df["gross_r"] - df["fee_r"]
    df["r_fees_slip"] = df["r_fees"] - df["slippage_r"]
    df["r_full"] = df["r_fees_slip"] - df["funding_r"]
    df["net_r"] = df["r_full"]
    return df
