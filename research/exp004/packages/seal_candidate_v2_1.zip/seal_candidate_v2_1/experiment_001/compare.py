"""Reconciliation, fixed-path decomposition, overlay-model comparison, zero-cost run matching."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .costs import CostModel, apply_costs
from .engine_model import fill_prices, levels_valid, r_components, zero_cost_gross
from .records import ENGINE_COLS

FP_MODES = {"gross_fixed_path": "r_gross", "after_slippage": "r_after_slip",
            "after_fees": "r_after_fees", "net_reference_formula": "r_full"}


def _rel_bad(a, b, tol):
    return np.abs(a - b) > tol * np.maximum(1.0, np.maximum(np.abs(a), np.abs(b)))


def reconcile(filled: pd.DataFrame, tol: float = 1e-9) -> tuple[dict, pd.DataFrame]:
    """Trade-by-trade check: exported REAL-engine numbers vs the replica formulas."""
    if not all(c in filled.columns for c in ENGINE_COLS) or filled[ENGINE_COLS].isna().any().any():
        return {"checked": False, "passed": False, "reason": "engine output columns missing/NaN in export"}, pd.DataFrame()
    side = filled["side"].to_numpy()
    entry, exit_fill = fill_prices(side, filled["entry_open"].to_numpy(), filled["exit_ref"].to_numpy(),
                                   filled["slippage_rate_per_side"].to_numpy())
    g, fee, fund, net, risk = r_components(side, entry, exit_fill, filled["stop"].to_numpy(),
                                           filled["fee_rate_per_side"].to_numpy(),
                                           filled["funding_rate_total"].to_numpy())
    pairs = {"entry_fill": (entry, "engine_entry_fill"), "exit_fill": (exit_fill, "engine_exit_fill"),
             "gross_r": (g, "engine_gross_r"),
             "fee_r": (fee, "engine_fee_r"), "funding_r": (fund, "engine_funding_r"), "net_r": (net, "engine_net_r")}
    out = pd.DataFrame({"trade_id": filled["trade_id"].to_numpy()})
    bad_any = np.zeros(len(filled), bool)
    per = {}
    for k, (mine, col) in pairs.items():
        eng = filled[col].to_numpy()
        out[f"{k}_replica"], out[f"{k}_engine"] = mine, eng
        bad = _rel_bad(mine, eng, tol)
        bad_any |= bad
        per[k] = {"max_abs_diff": float(np.abs(mine - eng).max()) if len(eng) else 0.0, "n_mismatch": int(bad.sum())}
    invalid = ~levels_valid(side, entry, filled["stop"].to_numpy(), filled["target"].to_numpy())
    out["mismatch"] = bad_any | invalid
    rep = {"checked": True, "tolerance": tol, "n": int(len(filled)), "per_field": per,
           "n_filled_but_invalid_levels_at_fill": int(invalid.sum()),
           "n_trades_with_any_mismatch": int(out["mismatch"].sum())}
    rep["passed"] = rep["n_trades_with_any_mismatch"] == 0
    return rep, out


def decompose_fixed_path(filled: pd.DataFrame) -> pd.DataFrame:
    """Same reference trades; zero-cost view and engine-formula cost decomposition (sequential: slip -> fee -> funding)."""
    df = filled.copy()
    side = df["side"].to_numpy()
    entry, exit_fill = fill_prices(side, df["entry_open"].to_numpy(), df["exit_ref"].to_numpy(),
                                   df["slippage_rate_per_side"].to_numpy())
    g_slip, fee, fund, net, _ = r_components(side, entry, exit_fill, df["stop"].to_numpy(),
                                             df["fee_rate_per_side"].to_numpy(), df["funding_rate_total"].to_numpy())
    g0 = zero_cost_gross(side, df["entry_open"].to_numpy(), df["exit_ref"].to_numpy(),
                         df["stop"].to_numpy(), df["target"].to_numpy())
    df["r_gross"], df["r_after_slip"] = g0, g_slip
    df["r_after_fees"], df["r_full"] = g_slip - fee, net
    df["slippage_r"], df["fee_r"], df["funding_r"] = g0 - g_slip, fee, fund
    df["identity_err"] = np.abs(g0 - df["slippage_r"] - fee - fund - net)
    df["stop_dist_pct"] = np.abs(df["entry_open"] - df["stop"]) / df["entry_open"]
    return df


def overlay_comparison(fp: pd.DataFrame, tol_mean=0.005, tol_max=0.05) -> dict:
    """Engine-formula components vs the independent overlay model (costs.apply_costs). Reported, never merged."""
    rates = fp[["fee_rate_per_side", "slippage_rate_per_side"]].drop_duplicates()
    if len(rates) != 1:
        return {"compared": False, "reason": "non-uniform fee/slippage rates across trades"}
    cm = CostModel(float(rates.iloc[0, 0]), float(rates.iloc[0, 1]))
    t = pd.DataFrame({"symbol": fp["symbol"], "strategy": fp["strategy"], "direction": fp["side"],
                      "entry_time": fp["entry_time"], "exit_time": fp["exit_time"], "entry": fp["entry_open"],
                      "stop": fp["stop"], "target": fp["target"], "exit_price": fp["exit_ref"],
                      "exit_reason": fp["exit_reason"], "funding_rate_total": fp["funding_rate_total"]})
    ov = apply_costs(t, None, cm)
    comp = {}
    for name, a, b in (("slippage_r", ov["slippage_r"].to_numpy(), fp["slippage_r"].to_numpy()),
                       ("fee_r", ov["fee_r"].to_numpy(), fp["fee_r"].to_numpy()),
                       ("funding_r", ov["funding_r"].to_numpy(), fp["funding_r"].to_numpy()),
                       ("net_r", ov["r_full"].to_numpy(), fp["r_full"].to_numpy())):
        d = a - b
        comp[name] = {"overlay_mean": float(a.mean()), "engine_formula_mean": float(b.mean()),
                      "mean_diff": float(d.mean()), "max_abs_diff": float(np.abs(d).max())}
    mism = abs(comp["net_r"]["mean_diff"]) > tol_mean or comp["net_r"]["max_abs_diff"] > tol_max
    return {"compared": True, "components": comp, "model_mismatch": bool(mism),
            "thresholds": {"mean": tol_mean, "max_abs": tol_max}}


def funding_convention_check(filled: pd.DataFrame, fidx, interval_ns: int, tol=1e-12) -> dict:
    """Which funding window convention reproduces the engine's funding_rate_total?"""
    from .costs import to_ns
    t0 = to_ns(filled["entry_time"])
    if "exit_available_ms" in filled.columns and filled["exit_available_ms"].notna().all():
        t1 = filled["exit_available_ms"].to_numpy(np.int64) * 1_000_000   # engine's actual_end (available_at_ms)
    else:
        t1 = to_ns(filled["exit_time"]) + interval_ns   # exit_time = open time of last held bar
    res = {}
    for name, a, b in (("(t0,t1]", fidx.sum_between(t0, t1), None),
                       ("[t0,t1)", fidx.sum_between(t0 - 1, t1 - 1), None)):
        d = np.abs(a - filled["funding_rate_total"].to_numpy())
        res[name] = {"match_share": float((d <= tol + 1e-9).mean()), "max_abs_diff": float(d.max())}
    best = max(res, key=lambda k: res[k]["match_share"])
    return {"conventions": res, "best": best, "ok": res[best]["match_share"] >= 0.99}


def match_zero_cost(ref: pd.DataFrame, zero: pd.DataFrame, fp: pd.DataFrame, tol=1e-9) -> tuple[dict, pd.DataFrame]:
    """Compare the reference run with a SEPARATE zero-cost re-run of the real engine. Reported separately, never merged."""
    zr = zero[["fee_rate_per_side", "slippage_rate_per_side", "funding_rate_total"]].fillna(0.0)
    is_zero = bool((zr.abs().to_numpy() == 0).all())
    m = ref.merge(zero, on="trade_id", how="outer", suffixes=("_ref", "_zero"), indicator=True)
    st_r, st_z = m["status_ref"].fillna("ABSENT"), m["status_zero"].fillna("ABSENT")
    both = (st_r == "FILLED") & (st_z == "FILLED")
    same = lambda a: (m[f"{a}_ref"] == m[f"{a}_zero"])
    close = lambda a: np.isclose(m[f"{a}_ref"].astype(float), m[f"{a}_zero"].astype(float), rtol=1e-12, atol=0)
    m["path_identical"] = both & same("entry_time") & same("exit_time") & same("exit_reason") & \
        close("stop") & close("target") & close("entry_open") & close("exit_ref") & close("held_bars")
    m["transition"] = st_r + "->" + st_z
    g0 = fp.set_index("trade_id")["r_gross"]
    m["ref_fixed_path_gross"] = m["trade_id"].map(g0)
    zr_net = m["engine_net_r_zero"] if "engine_net_r_zero" in m else np.nan
    m["r_diff"] = (zr_net - m["ref_fixed_path_gross"]) if "engine_net_r_zero" in m else np.nan
    n_ref_filled = int((st_r == "FILLED").sum())
    trans = m["transition"].value_counts().to_dict()
    changed = int((both & ~m["path_identical"]).sum())
    lost = int(((st_r == "FILLED") & (st_z != "FILLED")).sum())
    gained = int(((st_r != "FILLED") & (st_z == "FILLED")).sum())
    rd = m.loc[both & m["path_identical"], "r_diff"].dropna()
    rep = {"zero_run_has_zero_costs": is_zero, "transitions": trans, "n_ref_filled": n_ref_filled,
           "n_path_identical": int(m["path_identical"].sum()), "n_both_filled_path_changed": changed,
           "n_filled_in_ref_not_in_zero": lost, "n_filled_in_zero_not_in_ref": gained,
           "path_changed_share_of_ref_filled": float((changed + lost) / max(n_ref_filled, 1)),
           "newly_filled_share_of_ref_filled": float(gained / max(n_ref_filled, 1)),
           "r_diff_on_identical_paths": {"max_abs": float(rd.abs().max()) if len(rd) else None,
                                         "n_above_tol": int((rd.abs() > tol).sum())},
           "zero_run_own_stats": {"n_filled": int((st_z == "FILLED").sum()),
                                  "expectancy_r": float(zero.loc[zero["status"] == "FILLED", "engine_net_r"].mean())
                                  if "engine_net_r" in zero and (zero["status"] == "FILLED").any() else None}}
    cols = ["trade_id", "transition", "path_identical", "r_diff"]
    return rep, m.loc[~m["path_identical"] | (m["r_diff"].abs() > tol), cols]


def funding_exit_candle_uncertainty(filled: pd.DataFrame, fidx, interval_ns: int) -> dict:
    """B7. The engine charges every funding payment with entry_open < t <= actual_end (actual_end = available_at of the exit
    candle). For STOP/TARGET exits the true fill happens somewhere INSIDE the exit candle, so a payment inside
    (exit_candle_open, exit_candle_available] may or may not have been paid. Returns the R-size of that ambiguity
    (upper bound on the funding error from this source). TIMEOUT exits fill at the candle close: no ambiguity."""
    from .costs import to_ns
    t_open = to_ns(filled["exit_time"])
    t_av = (filled["exit_available_ms"].to_numpy(np.int64) * 1_000_000
            if "exit_available_ms" in filled.columns and filled["exit_available_ms"].notna().all() else t_open + interval_ns)
    side = filled["side"].to_numpy()
    entry = filled["entry_open"].to_numpy() * (1 + side * filled["slippage_rate_per_side"].to_numpy())
    risk = np.abs(entry - filled["stop"].to_numpy())
    rate_in_candle = fidx.sum_between(t_open, t_av)
    ambiguous = filled["exit_reason"].astype(str).str.upper().isin(["STOP", "TARGET"]).to_numpy() & (rate_in_candle != 0)
    r = np.where(ambiguous, np.abs(side * rate_in_candle * entry / risk), 0.0)
    return {"n_trades": int(len(filled)), "n_ambiguous": int(ambiguous.sum()), "max_abs_r": float(r.max()) if len(r) else 0.0,
            "sum_abs_r": float(r.sum()), "mean_abs_r_per_trade": float(r.mean()) if len(r) else 0.0}
