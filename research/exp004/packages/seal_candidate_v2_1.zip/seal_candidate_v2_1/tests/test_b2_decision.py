"""B2 - boundary fixtures for the decision function."""
import unittest

from experiment_001.decision import DecisionConfig, alpha_for_family, decide_arm, decide_family

CFG = DecisionConfig(n_min=500, min_blocks=24, alpha=0.025)
GATES = {"g1": True, "g2": True}


def ci(lo, hi, level=0.95):
    return {"lo": lo, "hi": hi, "level": level}


def run(arm="V1", gates=GATES, n=600, blocks=26, gross=None, net=None, p=0.01, cfg=CFG):
    return decide_arm(arm, gates, n, blocks, gross or ci(0.2, 0.6), net or ci(0.1, 0.5), p, cfg)["state"]


class Boundaries(unittest.TestCase):
    def test_family_alpha(self):
        self.assertAlmostEqual(alpha_for_family(0.05, 2), 0.025)

    def test_n_boundary(self):
        self.assertEqual(run(n=499), "INCONCLUSIVE_INSUFFICIENT")
        self.assertEqual(run(n=500), "EDGE_NET_SUPPORTED")
        self.assertEqual(run(blocks=23), "INCONCLUSIVE_INSUFFICIENT")
        self.assertEqual(run(blocks=24), "EDGE_NET_SUPPORTED")

    def test_ci_endpoint_exactly_zero_is_not_rejection(self):
        self.assertNotEqual(run(gross=ci(0.0, 0.6)), "EDGE_NET_SUPPORTED")
        self.assertEqual(run(gross=ci(0.0, 0.6)), "INCONCLUSIVE_POWER")
        self.assertEqual(run(gross=ci(1e-12, 0.6)), "EDGE_NET_SUPPORTED")

    def test_p_exactly_at_cutoff_is_not_rejection(self):
        self.assertEqual(run(p=0.025), "INCONCLUSIVE_POWER")
        self.assertEqual(run(p=0.0249999), "EDGE_NET_SUPPORTED")

    def test_net_stage_fixed_sequence(self):
        self.assertEqual(run(net=ci(0.0, 0.5)), "COSTS_ERASE_EDGE")
        self.assertEqual(run(net=ci(-0.3, 0.1)), "COSTS_ERASE_EDGE")

    def test_retire_boundary_uses_mei_strictly(self):
        self.assertEqual(run(arm="V1", gross=ci(-0.2, 0.35), p=0.5), "INCONCLUSIVE_POWER")      # hi == MEI
        self.assertEqual(run(arm="V1", gross=ci(-0.2, 0.3499), p=0.5), "RETIRE")
        self.assertEqual(run(arm="BASE", gross=ci(-0.2, 0.5499), p=0.5), "RETIRE")
        self.assertEqual(run(arm="BASE", gross=ci(-0.2, 0.55), p=0.5), "INCONCLUSIVE_POWER")

    def test_retire_not_allowed_when_insufficient(self):
        self.assertEqual(run(n=100, gross=ci(-0.2, 0.1), p=0.5), "INCONCLUSIVE_INSUFFICIENT")

    def test_failed_gate_dominates_everything(self):
        self.assertEqual(run(gates={"a": True, "b": False}), "INVALID")
        self.assertEqual(run(gates={"a": False}, n=10, gross=ci(-1, -0.5)), "INVALID")

    def test_nonfinite_and_level_mismatch_invalid(self):
        self.assertEqual(run(gross=ci(float("nan"), 0.6)), "INVALID")
        self.assertEqual(run(p=float("nan")), "INVALID")
        self.assertEqual(run(gross=ci(0.2, 0.6, level=0.90)), "INVALID")

    def test_family_applies_same_alpha_to_each_arm(self):
        arms = {"BASE": dict(gates=GATES, n_trades=600, n_blocks=26, gross=ci(-0.2, 0.3), net=ci(-0.5, 0.0), null_p_gross=0.5),
                "V1": dict(gates=GATES, n_trades=600, n_blocks=26, gross=ci(0.2, 0.6), net=ci(0.1, 0.5), null_p_gross=0.01)}
        out = decide_family(arms, CFG)
        self.assertEqual((out["BASE"]["state"], out["V1"]["state"]), ("RETIRE", "EDGE_NET_SUPPORTED"))

    def test_n_min_has_no_default(self):
        with self.assertRaises(TypeError):
            DecisionConfig(min_blocks=24)


if __name__ == "__main__":
    unittest.main()
