"""B6 - look-ahead invariance and availability-timestamp tests against the REAL signal modules (synthetic bars only).
Set SIGNALPILOT_SRC to a directory containing signals_v2/ and signals_v3/ (default /tmp/pkg); skipped if absent."""
import bisect
import dataclasses
import os
import sys
import unittest

import numpy as np

SRC = os.environ.get("SIGNALPILOT_SRC", "/tmp/pkg")
if os.path.isdir(os.path.join(SRC, "signals_v3")):
    sys.path.append(SRC)                 # appended: this repo's experiment_001 must win over any bundled copy
    from signals_v2.contracts import Candle, DataRejected
    from signals_v3.router import candidates
    from signals_v3.trend_pullback import trend_pullback
    from signals_v3.volatility_breakout import volatility_breakout
    from signals_v3.liquidity_reversal import liquidity_reversal
    HAVE = True
else:
    HAVE = False

T0 = 1_735_689_600_000


def make_series(n5=1500, seed=3, trend_p=0.985, burst=0.03):
    """Regime-switching synthetic 1m series (persistent drifts, volume/volatility bursts) so the REAL specialists fire."""
    rng = np.random.default_rng(seed)
    n1 = n5 * 5
    drift, d = np.zeros(n1), 0.0
    for k in range(n1):
        if rng.random() > trend_p:
            d = rng.choice([-1, 0, 1]) * 0.0004
        drift[k] = d
    ret = drift + rng.normal(0, 0.0007, n1) * (1 + 4 * (rng.random(n1) < burst))
    close = 100 * np.exp(np.cumsum(ret))
    open_ = np.concatenate([[100.0], close[:-1]])
    high = np.maximum(open_, close) * (1 + np.abs(rng.normal(0, 0.0003, n1)))
    low = np.minimum(open_, close) * (1 - np.abs(rng.normal(0, 0.0003, n1)))
    vol = rng.uniform(50, 150, n1) * (1 + 2.5 * (rng.random(n1) < 0.15))
    f = float
    one = [Candle(T0 + k * 60_000, f(open_[k]), f(high[k]), f(low[k]), f(close[k]), f(vol[k]), T0 + (k + 1) * 60_000)
           for k in range(n1)]
    five = []
    for k in range(n5):
        s = slice(5 * k, 5 * k + 5)
        five.append(Candle(T0 + k * 300_000, f(open_[5 * k]), f(high[s].max()), f(low[s].min()), f(close[5 * k + 4]),
                           f(vol[s].sum()), T0 + (k + 1) * 300_000))
    return five, one


def corrupt_after(bars, decision, rng):
    out = []
    for b in bars:
        if b.available_at_ms > decision:
            p = float(100 * rng.uniform(0.2, 5))
            out.append(Candle(b.open_ms, p, p * 1.9, p * 0.1, float(p * rng.uniform(0.2, 1.8)), 999999.0, b.available_at_ms))
        else:
            out.append(b)
    return out


def loop_inputs(five, one, one_times, i):
    decision = five[i].available_at_ms
    j = bisect.bisect_right(one_times, decision)
    return decision, tuple(five[i - 63:i + 1]), tuple(one[j - 45:j])


@unittest.skipUnless(HAVE, "signals_v2/signals_v3 sources not found (set SIGNALPILOT_SRC)")
class Lookahead(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.five, cls.one = make_series()
        cls.one_times = [b.available_at_ms for b in cls.one]

    def test_loop_slices_contain_no_bar_available_after_decision(self):
        for i in range(63, len(self.five) - 48, 7):
            decision, history, micro = loop_inputs(self.five, self.one, self.one_times, i)
            self.assertLessEqual(max(b.available_at_ms for b in history), decision)
            self.assertLessEqual(max(b.available_at_ms for b in micro), decision)
            self.assertEqual(history[-1].available_at_ms, decision)

    def test_candidates_invariant_to_corrupted_future_bars(self):
        rng = np.random.default_rng(9)
        nonempty = checked = 0
        for i in range(63, len(self.five) - 48, 3):
            decision, h1, m1 = loop_inputs(self.five, self.one, self.one_times, i)
            five2, one2 = corrupt_after(self.five, decision, rng), corrupt_after(self.one, decision, rng)
            _, h2, m2 = loop_inputs(five2, one2, [b.available_at_ms for b in one2], i)
            try:
                a = candidates("SOLUSDT", h1, m1, decision)
            except DataRejected as e:
                a = ("rejected", str(e))
            try:
                b = candidates("SOLUSDT", h2, m2, decision)
            except DataRejected as e:
                b = ("rejected", str(e))
            self.assertEqual(a, b, f"decision {decision}")
            checked += 1
            nonempty += bool(a) and a[0] != "rejected"
        self.assertGreater(checked, 100)
        self.assertGreater(nonempty, 0, "test would be vacuous: no signals produced by the synthetic series")

    def test_bar_available_just_after_decision_is_rejected_by_every_specialist(self):
        for i in (200, 300, 400):
            decision, history, micro = loop_inputs(self.five, self.one, self.one_times, i)
            late5 = history[:-1] + (dataclasses.replace(history[-1], available_at_ms=decision + 1),)
            late1 = micro[:-1] + (dataclasses.replace(micro[-1], available_at_ms=decision + 1),)
            for fn in (trend_pullback, volatility_breakout, liquidity_reversal):
                with self.assertRaises(DataRejected, msg=f"{fn.__name__} five"):
                    fn("SOLUSDT", late5, micro, decision)
                with self.assertRaises(DataRejected, msg=f"{fn.__name__} one"):
                    fn("SOLUSDT", history, late1, decision)
            with self.assertRaises(DataRejected):
                candidates("SOLUSDT", late5, micro, decision)

    def test_exact_boundary_availability_is_accepted(self):
        decision, history, micro = loop_inputs(self.five, self.one, self.one_times, 250)
        candidates("SOLUSDT", history, micro, decision)          # must not raise: available_at == decision is allowed


class ExporterSlicing(unittest.TestCase):
    def test_exporter_never_passes_future_bars_to_candidates(self):
        from experiment_001.export_signalpilot import Hooks, export_symbol
        from test_exporter import Candle as FC, DataRejected as FDR, guarded_replay, make_five, replay
        five = make_five(1500, seed=4)
        one = list(five)
        seen = []

        def candidates(symbol, history, micro, decision):
            seen.append((decision, max(b.available_at_ms for b in history), max(b.available_at_ms for b in micro)))
            return []
        hooks = Hooks(eligible=lambda *a: (True, ""), candidates=candidates, replay_hypothesis=lambda p: p,
                      guarded_replay=guarded_replay, replay_core=replay, rejected_exceptions=(FDR,))
        export_symbol("SOLUSDT", five, one, [b.available_at_ms for b in one], [], None, hooks, stride=3, fee=0.0005,
                      slip=0.0002, funding_enabled=False)
        self.assertGreater(len(seen), 100)
        self.assertTrue(all(h <= d and m <= d for d, h, m in seen))


if __name__ == "__main__":
    unittest.main()
