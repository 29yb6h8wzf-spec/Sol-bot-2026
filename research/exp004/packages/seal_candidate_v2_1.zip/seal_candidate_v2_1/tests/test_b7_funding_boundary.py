"""B7 - funding window boundaries: payment exactly at entry, exactly at exit, inside the exit candle."""
import unittest

import numpy as np
import pandas as pd

from experiment_001.compare import funding_convention_check, funding_exit_candle_uncertainty
from experiment_001.costs import FundingIndex
from experiment_001.export_signalpilot import Hooks, export_symbol
from experiment_001.records import load_records
from test_b5_v1_filter import STEP, T0, flat_five
from test_exporter import Candle, DataRejected, FEE, SLIP, Hypothesis, guarded_replay, replay

D_IDX = 100                       # decision bar; entry bar = 101; flat market -> TIMEOUT after 48 bars
E = T0 + 101 * STEP               # entry open_ms
A = T0 + (101 + 48) * STEP        # actual_end of the TIMEOUT trade = available_at of bar 148


def hooks_one(side="LONG", sp=0.01):
    def candidates(symbol, history, micro, decision):
        if decision != T0 + (D_IDX + 1) * STEP:
            return []
        s = 1 if side == "LONG" else -1
        return [Hypothesis("trend_pullback", side, 100 * (1 - s * sp), 100 * (1 + s * 2 * sp), 100.0)]
    return Hooks(eligible=lambda *a: (True, ""), candidates=candidates, replay_hypothesis=lambda p: p,
                 guarded_replay=guarded_replay, replay_core=replay, rejected_exceptions=(DataRejected,))


def export(five, payments, side="LONG"):
    one = list(five)
    rows = export_symbol("SOLUSDT", five, one, [c.available_at_ms for c in one], payments, None, hooks_one(side), stride=1,
                         fee=FEE, slip=SLIP, funding_enabled=True)
    return load_records(pd.DataFrame(rows))


def fidx_of(payments):
    return FundingIndex(pd.to_datetime([t for t, _ in payments], unit="ms", utc=True), [r for _, r in payments])


class Boundaries(unittest.TestCase):
    def test_engine_window_is_open_at_entry_and_closed_at_exit(self):
        pay = [(E - 1, 0.001), (E, 0.002), (E + 10 * STEP, 0.004), (A, 0.008), (A + 1, 0.016)]
        ref = export(flat_five(), pay)
        f = ref[ref.status == "FILLED"].iloc[0]
        self.assertEqual((f.exit_reason, f.held_bars), ("TIMEOUT", 48))
        self.assertEqual(int(f.exit_available_ms), A)
        # payment AT entry open excluded; AT actual_end included; one ms after excluded
        self.assertAlmostEqual(f.funding_rate_total, 0.004 + 0.008, places=15)

    def test_boundary_payments_identify_the_convention_september_could_not(self):
        pay = [(E, 0.002), (E + 10 * STEP, 0.004), (A, 0.008)]
        ref = export(flat_five(), pay)
        res = funding_convention_check(ref[ref.status == "FILLED"], fidx_of(pay), STEP * 1_000_000)
        self.assertEqual(res["best"], "(t0,t1]")
        self.assertEqual(res["conventions"]["(t0,t1]"]["match_share"], 1.0)
        self.assertLess(res["conventions"]["[t0,t1)"]["match_share"], 1.0)

    def test_without_boundary_payments_conventions_are_indistinguishable(self):
        pay = [(E + 10 * STEP, 0.004)]
        ref = export(flat_five(), pay)
        res = funding_convention_check(ref[ref.status == "FILLED"], fidx_of(pay), STEP * 1_000_000)
        self.assertEqual(res["conventions"]["(t0,t1]"]["match_share"], res["conventions"]["[t0,t1)"]["match_share"])

    def test_short_receives_positive_funding(self):
        pay = [(E + 10 * STEP, 0.004)]
        ref = export(flat_five(), pay, side="SHORT")
        f = ref[ref.status == "FILLED"].iloc[0]
        self.assertGreater(f.funding_rate_total, 0)
        self.assertLess(f.engine_funding_r, 0)               # short receives: negative cost


class ExitCandle(unittest.TestCase):
    def stop_hit_five(self):
        five = flat_five()
        c = five[110]
        five[110] = Candle(c.open_ms, c.available_at_ms, 100.0, 100.01, 98.9, 99.2)      # pierces the 99.0 stop
        return five

    def test_payment_inside_exit_candle_is_flagged_with_its_r_size(self):
        inside = T0 + 110 * STEP + STEP // 2
        pay = [(inside, 0.003)]
        ref = export(self.stop_hit_five(), pay)
        f = ref[ref.status == "FILLED"]
        self.assertEqual((f.exit_reason.iloc[0], int(f.held_bars.iloc[0])), ("STOP", 10))
        self.assertAlmostEqual(f.funding_rate_total.iloc[0], 0.003, places=15)           # engine charges it (<= actual_end)
        u = funding_exit_candle_uncertainty(f, fidx_of(pay), STEP)
        self.assertEqual(u["n_ambiguous"], 1)
        entry = 100 * (1 + SLIP)
        self.assertAlmostEqual(u["max_abs_r"], 0.003 * entry / abs(entry - 99.0), places=12)

    def test_timeout_exit_has_no_ambiguity(self):
        inside = A - STEP // 2
        pay = [(inside, 0.003)]
        ref = export(flat_five(), pay)
        u = funding_exit_candle_uncertainty(ref[ref.status == "FILLED"], fidx_of(pay), STEP)
        self.assertEqual(u["n_ambiguous"], 0)

    def test_no_payment_in_exit_candle_no_ambiguity(self):
        pay = [(E + 3 * STEP, 0.003)]
        ref = export(self.stop_hit_five(), pay)
        u = funding_exit_candle_uncertainty(ref[ref.status == "FILLED"], fidx_of(pay), STEP)
        self.assertEqual((u["n_ambiguous"], u["max_abs_r"]), (0, 0.0))


if __name__ == "__main__":
    unittest.main()
