"""B1 - injection tests for the strict reproduction gate (synthetic data only)."""
import copy
import unittest

import pandas as pd

from experiment_001.records import load_records
from experiment_001.strict_repro import check_reproduction, validate_expected_schema
from test_engine_experiment import FEE, SLIP, candles, funding_idx, make_proposals, run_engine


def build():
    c = candles(n=9000, seed=31)
    fidx = funding_idx(c)
    ref = load_records(run_engine(c, make_proposals(c, 80, seed=2), FEE, SLIP, fidx))
    f = ref[ref.status == "FILLED"].reset_index(drop=True)
    exp = {"n_trades": int(len(f)), "net_r_sum": float(f.engine_net_r.sum()),
           "by_strategy": {k: {"n": int(len(g)), "net_r_sum": float(g.engine_net_r.sum())} for k, g in f.groupby("strategy")}}
    rows = [{"trade_id": r.trade_id, "net_r": float(r.engine_net_r), "entry_time": r.entry_time.isoformat(),
             "exit_time": r.exit_time.isoformat(), "exit_reason": r.exit_reason} for r in f.itertuples()]
    return f, exp, rows


class StrictReproduction(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.f, cls.exp, cls.rows = build()

    def test_clean_passes_grouped_and_row_level(self):
        self.assertTrue(check_reproduction(self.f, self.exp)["passed"])
        r = check_reproduction(self.f, {**self.exp, "trades": self.rows})
        self.assertTrue(r["passed"])
        self.assertEqual(r["level"], "row_level")

    def test_misspelled_key_fails(self):                       # v1 gate would have PASSED this
        bad = copy.deepcopy(self.exp)
        bad["net_r_sums"] = bad.pop("net_r_sum")
        r = check_reproduction(self.f, bad)
        self.assertFalse(r["passed"])
        self.assertTrue(any("net_r_sums" in e and "did you mean" in e for e in r["schema_errors"]))

    def test_unknown_extra_key_and_garbage_fail(self):
        self.assertFalse(check_reproduction(self.f, {**self.exp, "bonus": 1})["passed"])
        self.assertFalse(check_reproduction(self.f, {"anything": 1})["passed"])
        self.assertFalse(check_reproduction(self.f, {})["passed"])
        self.assertFalse(check_reproduction(self.f, None)["passed"])

    def test_missing_or_extra_group_fails(self):
        bad = copy.deepcopy(self.exp)
        name = sorted(bad["by_strategy"])[0]
        removed = bad["by_strategy"].pop(name)
        bad["n_trades"] -= removed["n"]; bad["net_r_sum"] -= removed["net_r_sum"]
        self.assertFalse(check_reproduction(self.f, bad)["passed"])
        extra = copy.deepcopy(self.exp)
        extra["by_strategy"]["ghost"] = {"n": 0, "net_r_sum": 0.0}
        self.assertFalse(check_reproduction(self.f, extra)["passed"])

    def test_inconsistent_expected_file_fails(self):
        bad = copy.deepcopy(self.exp)
        bad["net_r_sum"] += 5.0
        r = check_reproduction(self.f, bad)
        self.assertFalse(r["passed"])
        self.assertTrue(any("inconsistent" in d for d in r["differences"]))

    def test_swapped_outcomes_across_groups_caught_by_grouped(self):
        g = self.f.copy()
        a = g.index[g.strategy == "trend_pullback"][0]
        b = g.index[g.strategy == "vol_breakout"][0]
        g.loc[a, "engine_net_r"], g.loc[b, "engine_net_r"] = g.loc[b, "engine_net_r"], g.loc[a, "engine_net_r"]
        self.assertFalse(check_reproduction(g, self.exp)["passed"])

    def test_swapped_outcomes_within_group_is_a_grouped_blind_spot_but_row_level_catches_it(self):
        g = self.f.copy()
        idx = list(g.index[g.strategy == "trend_pullback"][:2])
        g.loc[idx[0], "engine_net_r"], g.loc[idx[1], "engine_net_r"] = g.loc[idx[1], "engine_net_r"], g.loc[idx[0], "engine_net_r"]
        self.assertTrue(check_reproduction(g, self.exp)["passed"])                       # documented limit
        r = check_reproduction(g, {**self.exp, "trades": self.rows})
        self.assertFalse(r["passed"])

    def test_shifted_timestamp_caught_row_level(self):
        g = self.f.copy()
        g.loc[5, "entry_time"] = g.loc[5, "entry_time"] + pd.Timedelta("5min")
        self.assertFalse(check_reproduction(g, {**self.exp, "trades": self.rows})["passed"])

    def test_wrong_funding_sign_changes_totals_and_fails(self):
        g = self.f.copy()
        self.assertGreater(g.engine_funding_r.abs().sum(), 0)
        g["engine_net_r"] = g["engine_net_r"] + 2 * g["engine_funding_r"]               # sign flipped
        self.assertFalse(check_reproduction(g, self.exp)["passed"])

    def test_row_level_id_set_and_digest(self):
        r = check_reproduction(self.f, {**self.exp, "trades": self.rows[:-1]})
        self.assertFalse(r["passed"])
        self.assertFalse(check_reproduction(self.f, {**self.exp, "source_digest": "abc"})["passed"])           # cannot verify
        self.assertFalse(check_reproduction(self.f, {**self.exp, "source_digest": "abc"}, source_digest="xyz")["passed"])
        self.assertTrue(check_reproduction(self.f, {**self.exp, "source_digest": "abc"}, source_digest="abc")["passed"])

    def test_schema_types(self):
        self.assertTrue(validate_expected_schema({**self.exp, "n_trades": True}))
        self.assertTrue(validate_expected_schema({**self.exp, "net_r_sum": float("nan")}))


if __name__ == "__main__":
    unittest.main()
