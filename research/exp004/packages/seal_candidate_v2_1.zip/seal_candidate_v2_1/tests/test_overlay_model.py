import json
import unittest

import numpy as np
import pandas as pd

from experiment_001.costs import CostModel, FundingIndex, apply_costs
from experiment_001.metrics import max_drawdown, profit_factor, summarize, bootstrap_ci, verdict


def trade(**kw):
    base = dict(symbol="SOLUSDT", strategy="trend_pullback", direction="long",
                entry_time="2025-01-01 00:10", exit_time="2025-01-01 01:10",
                entry=100.0, stop=99.0, target=102.0, exit_price=102.0, exit_reason="target")
    base.update(kw)
    return base


def walk_candles(n=6000, seed=3, start="2025-01-01", drift=0.0):
    rng = np.random.default_rng(seed)
    ret = rng.normal(drift, 0.002, n)
    close = 100 * np.exp(np.cumsum(ret))
    open_ = np.concatenate([[100.0], close[:-1]])
    spread = np.abs(rng.normal(0, 0.001, n))
    return pd.DataFrame({
        "time": pd.date_range(start, periods=n, freq="5min", tz="UTC"),
        "open": open_, "high": np.maximum(open_, close) * (1 + spread),
        "low": np.minimum(open_, close) * (1 - spread), "close": close})


class CostTests(unittest.TestCase):
    def test_long_winner_exact_numbers(self):
        f = {"SOLUSDT": FundingIndex(["2025-01-01 01:00"], [0.0001])}
        df = apply_costs(pd.DataFrame([trade()]), f, CostModel(0.0005, 0.0002))
        r = df.iloc[0]
        self.assertAlmostEqual(r.gross_r, 2.0)
        self.assertAlmostEqual(r.fee_r, 0.0005 * 202 / 1.0)
        self.assertAlmostEqual(r.slippage_r, 0.0002 * 202 / 1.0)
        self.assertAlmostEqual(r.funding_r, 0.0001 * 100 / 1.0)
        self.assertAlmostEqual(r.r_full, 2 - 0.101 - 0.0404 - 0.01)

    def test_short_receives_positive_funding(self):
        f = {"SOLUSDT": FundingIndex(["2025-01-01 01:00"], [0.0001])}
        t = trade(direction="short", stop=101.0, target=98.0, exit_price=98.0)
        r = apply_costs(pd.DataFrame([t]), f).iloc[0]
        self.assertAlmostEqual(r.gross_r, 2.0)
        self.assertLess(r.funding_r, 0)

    def test_funding_window_is_open_closed(self):
        f = {"SOLUSDT": FundingIndex(["2025-01-01 00:10", "2025-01-01 01:10"], [0.001, 0.001])}
        r = apply_costs(pd.DataFrame([trade()]), f).iloc[0]
        self.assertAlmostEqual(r.funding_r, 0.001 * 100)  # only the payment at exit time counts

    def test_paths_identical_across_modes(self):
        rows = [trade(), trade(exit_price=99.0, exit_reason="stop"), trade(direction="short", stop=101, target=98, exit_price=101, exit_reason="stop")]
        raw = pd.DataFrame(rows)
        df = apply_costs(raw)
        self.assertEqual(len(df), len(raw))
        for c in ("entry", "stop", "target", "exit_price"):
            np.testing.assert_array_equal(df[c].to_numpy(), raw[c].to_numpy())
        np.testing.assert_allclose(df.r_full, df.r_gross - df.fee_r - df.slippage_r - df.funding_r)
        self.assertTrue((df.r_gross >= df.r_fees).all() and (df.r_fees >= df.r_fees_slip).all())

    def test_bad_input_rejected(self):
        with self.assertRaises(ValueError):
            apply_costs(pd.DataFrame([trade(stop=100.0)]))
        with self.assertRaises(ValueError):
            apply_costs(pd.DataFrame([trade(direction="sideways")]))
        with self.assertRaises(ValueError):
            apply_costs(pd.DataFrame([trade()]).drop(columns=["target"]))


class MetricTests(unittest.TestCase):
    def test_drawdown_and_pf(self):
        self.assertAlmostEqual(max_drawdown([1, -2, -1, 3]), 3.0)
        self.assertEqual(max_drawdown([]), 0.0)
        self.assertAlmostEqual(profit_factor([2, -1, -1]), 1.0)
        self.assertIsNone(profit_factor([1, 2]))

    def test_flip_rate(self):
        # gross +0.05R winner with ~0.14R cost flips; 2R winner does not
        rows = [trade(exit_price=100.05, exit_reason="timeout"), trade()]
        s = summarize(apply_costs(pd.DataFrame(rows)))
        self.assertEqual(s["gross_winners_flipped_to_losers"]["count"], 1)
        self.assertEqual(s["gross_winners_flipped_to_losers"]["of_gross_winners"], 2)

    def test_verdict_codes(self):
        neg = summarize(apply_costs(pd.DataFrame([trade(exit_price=99.0, exit_reason="stop")] * 5)))
        self.assertEqual(verdict(neg, bootstrap_ci([-1] * 5), None)["code"], "NO_PROVEN_GROSS_EDGE")



if __name__ == "__main__":
    unittest.main()
