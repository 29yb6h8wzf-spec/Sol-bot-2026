import unittest
from dataclasses import dataclass

import numpy as np
import pandas as pd

from experiment_001.export_signalpilot import (ExportError, Hooks, engine_cost_defaults, engine_costs,
                                               export_symbol, summarize_reference)
from experiment_001.run import run_experiment

FEE, SLIP = 0.0005, 0.0002


class DataRejected(Exception):
    pass


@dataclass(frozen=True)
class Candle:
    open_ms: int
    available_at_ms: int
    open: float
    high: float
    low: float
    close: float


@dataclass(frozen=True)
class Hypothesis:
    strategy: str
    direction: str
    stop_reference: float
    target_reference: float
    entry_reference: float = 0.0


@dataclass(frozen=True)
class ReplayResult:
    exit_reason: str
    bars_held: int
    entry_fill: float
    exit_fill: float
    net_r: float
    fee_r: float
    funding_r: float
    research_only: bool = True


def replay(proposal, future_bars, *, fee_rate_per_side=FEE, slippage_rate_per_side=SLIP, funding_rate_total=0.0,
           max_bars=48):
    """Same math as the pasted signals_v2/replay.py (independent literal copy)."""
    side = 1 if proposal.direction == "LONG" else -1
    future_bars = future_bars[:max_bars]
    entry = future_bars[0].open * (1 + side * slippage_rate_per_side)
    stop, target = proposal.stop_reference, proposal.target_reference
    if side == 1 and not stop < entry < target:
        raise DataRejected("invalid_long_levels_at_fill")
    if side == -1 and not target < entry < stop:
        raise DataRejected("invalid_short_levels_at_fill")
    risk = abs(entry - stop)
    reason, exit_ref, held = "TIMEOUT", future_bars[-1].close, len(future_bars)
    for i, bar in enumerate(future_bars, 1):
        stop_hit = bar.low <= stop if side == 1 else bar.high >= stop
        target_hit = bar.high >= target if side == 1 else bar.low <= target
        if stop_hit:
            reason, exit_ref, held = "STOP", min(stop, bar.open) if side == 1 else max(stop, bar.open), i
            break
        if target_hit:
            reason, exit_ref, held = "TARGET", target, i
            break
    exit_fill = exit_ref * (1 - side * slippage_rate_per_side)
    gross_r = side * (exit_fill - entry) / risk
    fee_r = fee_rate_per_side * (entry + exit_fill) / risk
    funding_r = side * funding_rate_total * entry / risk
    return ReplayResult(reason, held, entry, exit_fill, gross_r - fee_r - funding_r, fee_r, funding_r)


def guarded_replay(proposal, history, future, intervals, max_bars=48, funding_rate_total=0.0):
    return replay(proposal, future, funding_rate_total=funding_rate_total, max_bars=max_bars)   # uses cost DEFAULTS


def guarded_replay_ignoring_overrides(proposal, history, future, intervals, max_bars=48, funding_rate_total=0.0):
    return replay(proposal, future, fee_rate_per_side=FEE, slippage_rate_per_side=SLIP,
                  funding_rate_total=funding_rate_total, max_bars=max_bars)


def make_five(n=4000, seed=1):
    rng = np.random.default_rng(seed)
    close = 100 * np.exp(np.cumsum(rng.normal(0, 0.002, n)))
    open_ = np.concatenate([[100.0], close[:-1]]) * (1 + rng.normal(0, 0.0007, n))
    sp = np.abs(rng.normal(0, 0.001, n))
    hi, lo = np.maximum(open_, close) * (1 + sp), np.minimum(open_, close) * (1 - sp)
    step = 300_000
    t0 = 1_735_689_600_000
    return [Candle(t0 + k * step, t0 + (k + 1) * step, open_[k], hi[k], lo[k], close[k]) for k in range(n)]


def candidates_factory(five, force_tight_at=None):
    rng = np.random.default_rng(5)
    plan = {}
    for i in range(63, len(five) - 48):
        if rng.random() < 0.04:
            side = "LONG" if rng.random() < .5 else "SHORT"
            sp = float(rng.uniform(0.003, 0.012))
            plan[five[i].available_at_ms] = (["trend_pullback", "vol_breakout"][int(rng.random() < .5)], side, sp)

    def candidates(symbol, history, micro, decision):
        if decision not in plan:
            return []
        name, side, sp = plan[decision]
        o = history[-1].close            # proposal references are fixed at decision time
        s = 1 if side == "LONG" else -1
        stop, target = o * (1 - s * sp), o * (1 + s * sp * 2)
        if force_tight_at and decision == force_tight_at:
            stop, target = o * 0.99, o * 1.0001        # valid only at zero slippage if next open ~ o
        return [Hypothesis(name, side, stop, target, o)]
    return candidates, plan


def hooks_for(candidates, guarded=guarded_replay):
    return Hooks(eligible=lambda *a: (True, ""), candidates=candidates, replay_hypothesis=lambda p: p,
                 guarded_replay=guarded, replay_core=replay, rejected_exceptions=(DataRejected,))


def funding_for(five):
    t0, tN = five[0].open_ms, five[-1].available_at_ms
    return [(t, 0.0001) for t in range(t0 + 8 * 3600_000, tN, 8 * 3600_000)]


class ExporterTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.five = make_five()
        cls.one = [Candle(c.open_ms, c.available_at_ms, c.open, c.high, c.low, c.close) for c in cls.five]
        cls.one_times = [c.available_at_ms for c in cls.one]
        cls.funding = funding_for(cls.five)
        cands, cls.plan = candidates_factory(cls.five)
        cls.cands = staticmethod(cands)
        cls.hooks = hooks_for(cands)

    def run_export(self, fee, slip, fund, hooks=None, five=None):
        five = five or self.five
        return pd.DataFrame(export_symbol("SOLUSDT", five, self.one, self.one_times, self.funding, None,
                                          hooks or self.hooks, stride=1, fee=fee, slip=slip, funding_enabled=fund))

    def test_defaults_restored_and_readable(self):
        before = dict(replay.__kwdefaults__)
        self.assertEqual(engine_cost_defaults(replay), {"fee": FEE, "slip": SLIP})
        with engine_costs(replay, 0.0, 0.0):
            self.assertEqual(replay.__kwdefaults__["fee_rate_per_side"], 0.0)
        self.assertEqual(replay.__kwdefaults__, before)

    def test_reference_export_reconstruction_and_stable_ids(self):
        ref = self.run_export(FEE, SLIP, True)
        f = ref[ref.status == "FILLED"]
        self.assertGreater(len(f), 30)
        self.assertTrue((f.reconstruction_error == "").all() or f.reconstruction_error.isna().all())
        self.assertTrue(ref.trade_id.is_unique)
        self.assertTrue(ref.trade_id.str.contains(r"\|\d{13}\|").all())          # decision-ms based ids
        self.assertGreater(f.funding_rate_total.abs().sum(), 0)
        again = self.run_export(FEE, SLIP, True)
        self.assertEqual(list(ref.trade_id), list(again.trade_id))                 # deterministic

    def test_end_to_end_experiment_passes_gates_when_paths_are_stable(self):
        ref, zero = self.run_export(FEE, SLIP, True), self.run_export(0.0, 0.0, False)
        c = pd.DataFrame({"time": pd.to_datetime([x.open_ms for x in self.five], unit="ms", utc=True),
                          "open": [x.open for x in self.five], "high": [x.high for x in self.five],
                          "low": [x.low for x in self.five], "close": [x.close for x in self.five]})
        from experiment_001.costs import FundingIndex
        fidx = FundingIndex(pd.to_datetime([t for t, _ in self.funding], unit="ms", utc=True), [r for _, r in self.funding])
        rep, _ = run_experiment(ref, zero, {"SOLUSDT": c}, {"SOLUSDT": fidx}, n_runs=15, seed=3,
                                expected=summarize_reference(ref))
        for k in ("reproduces_original_reference", "exit_reconstruction_ok", "reconciliation_vs_engine", "cost_identity",
                  "zero_cost_run_is_actually_zero"):
            self.assertTrue(rep["gates"][k], k)
        self.assertEqual(rep["funding_convention_check"]["SOLUSDT"]["best"], "(t0,t1]")
        self.assertTrue(rep["funding_convention_check"]["SOLUSDT"]["ok"])

    def test_ineffective_cost_override_aborts(self):
        bad = hooks_for(self.cands, guarded_replay_ignoring_overrides)
        with self.assertRaises(ExportError):
            self.run_export(0.0, 0.0, False, hooks=bad)

    def test_rejected_proposals_exported_and_do_not_occupy_timeline(self):
        # tight target valid at zero slippage only -> REJECTED in reference, FILLED in zero run (cascade possible)
        decision = [d for d in sorted(self.plan) if self.plan[d][1] == "LONG"][10]
        cands, _ = candidates_factory(self.five, force_tight_at=decision)
        h = hooks_for(cands)
        i = next(k for k, c in enumerate(self.five) if c.available_at_ms == decision)
        # force next open to be slightly above the proposal reference so the LONG tight levels are valid only w/o slip
        five = list(self.five)
        o = five[i].close
        five[i + 1] = Candle(five[i + 1].open_ms, five[i + 1].available_at_ms, o, max(five[i + 1].high, o), min(five[i + 1].low, o * 0.995), five[i + 1].close)
        ref = pd.DataFrame(export_symbol("SOLUSDT", five, self.one, self.one_times, self.funding, None, h, stride=1,
                                         fee=FEE, slip=SLIP, funding_enabled=True))
        zero = pd.DataFrame(export_symbol("SOLUSDT", five, self.one, self.one_times, self.funding, None, h, stride=1,
                                          fee=0.0, slip=0.0, funding_enabled=False))
        tid = f"SOLUSDT|{decision}|" + cands("SOLUSDT", (five[i],), (), decision)[0].strategy + "|LONG"
        self.assertEqual(ref.set_index("trade_id").loc[tid, "status"], "REJECTED")
        self.assertIn("DataRejected", ref.set_index("trade_id").loc[tid, "reject_reason"])
        self.assertEqual(zero.set_index("trade_id").loc[tid, "status"], "FILLED")
        rep, tables = run_experiment(ref, zero, None, None)
        self.assertIn("REJECTED->FILLED", rep["zero_cost_counterfactual"]["transitions"])
        self.assertEqual(rep["meta"]["n_rejected"], int((ref.status == "REJECTED").sum()))


if __name__ == "__main__":
    unittest.main()
