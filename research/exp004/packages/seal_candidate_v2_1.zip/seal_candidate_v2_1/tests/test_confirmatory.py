"""End-to-end tier C analysis on SYNTHETIC records (no real data)."""
import json
import unittest

import numpy as np
import pandas as pd

from experiment_001.confirmatory import analyze_arm, analyze_family
from experiment_001.decision import DecisionConfig
from experiment_001.engine_model import fill_prices, r_components
from experiment_001.synth import market, real_run

FEE, SLIP = 0.0005, 0.0002


def to_records(fp, fee, slip):
    rows = []
    for k, r in enumerate(fp.itertuples()):
        side = int(r.side)
        entry, exit_fill = fill_prices(side, r.entry_open, r.exit_ref, slip)
        g, f, fund, net, _ = r_components(side, entry, exit_fill, r.stop, fee, 0.0)
        rows.append(dict(trade_id=f"{r.symbol}|{k}|{r.strategy}", symbol=r.symbol, strategy=r.strategy,
                         direction="LONG" if side == 1 else "SHORT", status="FILLED", entry_time=r.entry_time,
                         exit_time=r.exit_time, entry_open=r.entry_open, stop=r.stop, target=r.target, exit_ref=r.exit_ref,
                         exit_reason=r.exit_reason, held_bars=r.held_bars, horizon_bars=r.horizon_bars,
                         fee_rate_per_side=fee, slippage_rate_per_side=slip, funding_rate_total=0.0,
                         engine_entry_fill=entry, engine_exit_fill=exit_fill, engine_gross_r=g, engine_fee_r=f,
                         engine_funding_r=fund, engine_net_r=net, reconstruction_error=""))
    return pd.DataFrame(rows)


class Tier(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.candles = {"SOLUSDT": market(14 * 2016, 71), "XRPUSDT": market(14 * 2016, 72)}
        fp = real_run(cls.candles, np.random.default_rng(3), fire_prob=0.08)
        cls.ref, cls.zero = to_records(fp, FEE, SLIP), to_records(fp, 0.0, 0.0)

    def run_arm(self, cfg, **kw):
        return analyze_arm("V1", self.ref, self.zero, self.candles, None, cfg, window_days=98, B_boot=499, n_null=99, seed=5, **kw)

    def test_zero_edge_world_is_not_declared_an_edge_and_report_is_json_safe(self):
        cfg = DecisionConfig(n_min=100, min_blocks=10)
        out = self.run_arm(cfg)
        self.assertNotIn(out["decision"]["state"], ("EDGE_NET_SUPPORTED", "COSTS_ERASE_EDGE"))
        self.assertNotIn("reproduces_original_reference", out["gates"])                         # not applicable in tier C
        self.assertTrue(all(out["gates"].values()))
        self.assertEqual(out["gross_ci"]["level"], 0.95)
        self.assertEqual(set(out["block_sensitivity"]["gross"]), {"7", "14", "1"})
        self.assertEqual(out["experiment_report"]["commission_check"]["status"], "MISSING")
        json.dumps(out["decision"])

    def test_insufficient_sample_is_reported_as_such(self):
        out = self.run_arm(DecisionConfig(n_min=10_000, min_blocks=10))
        self.assertEqual(out["decision"]["state"], "INCONCLUSIVE_INSUFFICIENT")

    def test_failed_gate_makes_state_invalid(self):
        bad = self.ref.copy()
        bad.loc[3, "engine_fee_r"] += 0.05
        out = analyze_arm("V1", bad, self.zero, self.candles, None, DecisionConfig(n_min=100, min_blocks=10),
                          window_days=98, B_boot=299, n_null=49, seed=5)
        self.assertEqual(out["decision"]["state"], "INVALID")

    def test_family_uses_one_alpha_for_all_arms(self):
        cfg = DecisionConfig(n_min=100, min_blocks=10)
        fam = analyze_family({"BASE": {"ref": self.ref, "zero": self.zero}, "V1": {"ref": self.ref, "zero": self.zero}},
                             self.candles, None, cfg, window_days=98, B_boot=299, n_null=49, seed=5)
        self.assertEqual({a["gross_ci"]["alpha_one_sided"] for a in fam.values()}, {0.025})


if __name__ == "__main__":
    unittest.main()
