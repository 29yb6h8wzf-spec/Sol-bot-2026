import json
import os
import unittest
from datetime import datetime, timedelta, timezone

from experiment_001.commission import check_fee_scenario, parse_records

NOW = datetime(2027, 6, 1, tzinfo=timezone.utc)
SYMS = ["SOLUSDT", "XRPUSDT"]


def rec(sym, maker="0.000200", taker="0.000500", when=None, source="GET /fapi/v1/commissionRate"):
    return {"symbol": sym, "makerCommissionRate": maker, "takerCommissionRate": taker,
            "retrieved_at": (when or NOW - timedelta(days=2)).isoformat(), "source": source}


class Commission(unittest.TestCase):
    def test_verified(self):
        r = check_fee_scenario([rec(s) for s in SYMS], SYMS, now=NOW)
        self.assertEqual(r["status"], "VERIFIED")

    def test_missing_symbol_and_none(self):
        self.assertEqual(check_fee_scenario([rec("SOLUSDT")], SYMS, now=NOW)["status"], "MISSING")
        self.assertEqual(check_fee_scenario(None, SYMS, now=NOW)["status"], "MISSING")

    def test_mismatch_taker_or_maker(self):
        self.assertEqual(check_fee_scenario([rec("SOLUSDT", taker="0.000450"), rec("XRPUSDT")], SYMS, now=NOW)["status"], "MISMATCH")
        self.assertEqual(check_fee_scenario([rec("SOLUSDT", maker="0.000180"), rec("XRPUSDT")], SYMS, now=NOW)["status"], "MISMATCH")

    def test_stale_record(self):
        old = NOW - timedelta(days=90)
        self.assertEqual(check_fee_scenario([rec(s, when=old) for s in SYMS], SYMS, now=NOW)["status"], "STALE")

    def test_malformed_never_raises_and_reports(self):
        r = check_fee_scenario([rec("SOLUSDT", taker=None), {"symbol": "XRPUSDT"}], SYMS, now=NOW)
        self.assertEqual(r["status"], "MISSING")
        self.assertEqual(len(r["parse_errors"]), 2)
        self.assertEqual(parse_records("{}")[1], ["commission records must be a JSON list"])

    def test_template_is_not_accepted_as_a_record(self):
        here = os.path.dirname(os.path.abspath(__file__))
        with open(os.path.join(here, "..", "commission_records_TEMPLATE.json")) as fh:
            tpl = json.load(fh)
        self.assertEqual(check_fee_scenario(tpl, SYMS, now=NOW)["status"], "MISSING")

    def test_worst_status_wins(self):
        r = check_fee_scenario([rec("SOLUSDT", taker="0.001"), rec("XRPUSDT", when=NOW - timedelta(days=90))], SYMS, now=NOW)
        self.assertEqual(r["status"], "MISMATCH")


if __name__ == "__main__":
    unittest.main()
