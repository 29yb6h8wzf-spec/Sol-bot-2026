"""Guards against drift: the frozen config must equal the parameters approved by the owner (items 1-7 + V1 option C)."""
import json
import unittest
from datetime import date

import numpy as np

from experiment_001.config import decision_config, load_config
from experiment_001.confirmatory import analyze_protocol
from experiment_001.decision import decide_arm
from experiment_001.month_sets import assert_month_sets
from experiment_001.synth import market, real_run
from test_confirmatory import FEE, SLIP, to_records


class Config(unittest.TestCase):
    def test_values_equal_the_approved_parameters(self):
        c = load_config()
        self.assertEqual(c["protocol_version"], "2.1")
        self.assertEqual((c["confirmatory_arms"], c["exploratory_arms"], c["v1_option"]), (["BASE"], ["V1"], "C"))
        self.assertEqual((c["alpha_one_sided_per_arm"], c["alpha_total"], c["interval_level"]), (0.05, 0.05, 0.90))
        self.assertEqual((c["n_min"], c["min_blocks"], c["block_days"], c["bootstrap_B"], c["null_runs"], c["seed"]),
                         (500, 24, 7, 10000, 10000, 20261111))
        self.assertEqual(c["mei_gross"], {"BASE": 0.55, "V1": 0.35})
        self.assertEqual((c["stride_5m_bars"], c["first_entry_bar"], c["horizon_bars"]), (12, 64, 48))
        self.assertEqual((c["tier_c_start_utc"], c["tier_c_end_utc"], c["window_days"]),
                         ("2026-12-01T00:00:00Z", "2027-05-31T23:59:59Z", 182))
        self.assertEqual((c["extension_step_weeks"], c["funding_convention"], c["forbidden_before"]), (13, "(t0,t1]", "2027-06-01"))
        self.assertEqual(c["cost_scenario"], {"fee_per_side": 0.0005, "slippage_per_side": 0.0002, "maker_assumed": 0.0002})

    def test_internal_consistency_rules(self):
        c = load_config()
        bad = json.dumps({**c, "interval_level": 0.95})
        with open("/tmp/_bad_cfg.json", "w") as fh:
            fh.write(bad)
        with self.assertRaises(ValueError):
            load_config("/tmp/_bad_cfg.json")

    def test_decision_config_matches_and_level_guard_blocks_stale_intervals(self):
        dc = decision_config(load_config())
        gates = {"g": True}
        ok = {"lo": 0.1, "hi": 0.9, "level": 0.90}
        self.assertEqual(decide_arm("BASE", gates, 600, 26, ok, ok, 0.01, dc)["state"], "EDGE_NET_SUPPORTED")
        stale = {"lo": 0.1, "hi": 0.9, "level": 0.95}                    # a 0.025-era interval must be refused
        self.assertEqual(decide_arm("BASE", gates, 600, 26, stale, ok, 0.01, dc)["state"], "INVALID")

    def test_month_sets_and_seal_deadline(self):
        self.assertTrue(assert_month_sets(date(2026, 11, 30)))


class Protocol(unittest.TestCase):
    def test_base_decided_v1_exploratory(self):
        c = load_config()
        c.update(bootstrap_B=299, null_runs=49, window_days=98, n_min=100, min_blocks=10)
        candles = {"SOLUSDT": market(14 * 2016, 91), "XRPUSDT": market(14 * 2016, 92)}
        fp = real_run(candles, np.random.default_rng(4), fire_prob=0.08)
        data = {a: {"ref": to_records(fp, FEE, SLIP), "zero": to_records(fp, 0.0, 0.0)} for a in ("BASE", "V1")}
        out = analyze_protocol(c, data, candles, None)
        self.assertEqual(out["V1"]["decision"]["state"], "EXPLORATORY_NO_DECISION")
        self.assertNotEqual(out["BASE"]["decision"]["state"], "EXPLORATORY_NO_DECISION")
        self.assertEqual(out["BASE"]["gross_ci"]["level"], 0.90)
        self.assertEqual(out["V1"]["gross_ci"]["level"], 0.90)           # same estimator reported for the exploratory arm


if __name__ == "__main__":
    unittest.main()
