"""B3 - calibration of the block bootstrap under correlated zero-mean synthetic returns."""
import unittest

import numpy as np
import pandas as pd

from experiment_001.block_bootstrap import (analyze, block_ids, naive_trade_bootstrap_lower, sensitivity,
                                            studentized_block_bootstrap)


def simulate(rng, weeks=26, rate=28, sd2=2.0, icc=0.25, mean=0.0):
    ms = np.maximum(rng.poisson(rate, weeks), 1)
    f = rng.normal(0, np.sqrt(sd2 * icc), weeks)
    vals = [mean + f[w] + rng.normal(0, np.sqrt(sd2 * (1 - icc)), m) for w, m in enumerate(ms)]
    return np.concatenate(vals), np.concatenate([np.full(m, w) for w, m in enumerate(ms)])


class BlockIds(unittest.TestCase):
    def test_weeks_are_monday_aligned_and_symbol_synchronized(self):
        t = pd.to_datetime(["2026-12-06 23:59", "2026-12-07 00:00", "2026-12-13 23:59", "2026-12-14 00:00"], utc=True)  # Sun, Mon, Sun, Mon
        b = block_ids(t)
        self.assertEqual(b[0] + 1, b[1]); self.assertEqual(b[1], b[2]); self.assertEqual(b[2] + 1, b[3])
        # month boundary does not split a week
        m = block_ids(pd.to_datetime(["2026-12-31 12:00", "2027-01-01 12:00"], utc=True))
        self.assertEqual(m[0], m[1])

    def test_unit_choices(self):
        t = pd.to_datetime(["2026-12-07", "2026-12-08", "2026-12-21"], utc=True)
        self.assertEqual(len(set(block_ids(t, 1))), 3)
        self.assertEqual(len(set(block_ids(t, 14))), 2)


class Behaviour(unittest.TestCase):
    def test_deterministic_given_seed(self):
        v, b = simulate(np.random.default_rng(1))
        a = studentized_block_bootstrap(v, b, B=999, seed=5)
        c = studentized_block_bootstrap(v, b, B=999, seed=5)
        self.assertEqual((a["lo"], a["hi"]), (c["lo"], c["hi"]))
        self.assertLess(a["lo"], a["point"]); self.assertGreater(a["hi"], a["point"])

    def test_empty_weeks_counted_and_too_few_blocks_flagged(self):
        v = np.array([1.0, -1.0, 2.0, 0.5])
        out = studentized_block_bootstrap(v, np.array([0, 0, 5, 5]), window_blocks=26, B=200)
        self.assertEqual((out["n_blocks"], out["n_empty_blocks"]), (2, 24))
        self.assertTrue(np.isnan(out["lo"]))

    def test_analyze_and_sensitivity_run(self):
        t = pd.date_range("2026-12-01", periods=300, freq="11h", tz="UTC")
        v = np.random.default_rng(2).normal(0, 1, 300)
        s = sensitivity(v, t, window_days=140, B=300)
        self.assertEqual(set(s), {"7", "14", "1"})
        self.assertEqual(analyze(v, t, window_days=140, B=300)["block_days"], 7)

    def test_rejects_nonfinite(self):
        with self.assertRaises(ValueError):
            studentized_block_bootstrap(np.array([1.0, np.nan, 2.0, 3.0]), np.array([0, 1, 2, 3]))


class Calibration(unittest.TestCase):
    """Size at one-sided alpha=0.025 with 26 weekly blocks, correlated zero-mean returns."""
    def test_size_is_near_nominal_while_naive_is_not(self):
        rng = np.random.default_rng(11)
        R, rej_block, rej_naive = 500, 0, 0
        for r in range(R):
            v, b = simulate(rng, icc=0.25)
            rej_block += studentized_block_bootstrap(v, b, B=499, seed=r)["lo"] > 0
            rej_naive += naive_trade_bootstrap_lower(v, B=300, seed=r) > 0
        size_block, size_naive = rej_block / R, rej_naive / R
        self.assertLessEqual(size_block, 0.045)          # nominal 0.025, MC SE ~0.007
        self.assertGreater(size_naive, 0.10)             # the problem the audit flagged

    def test_power_and_coverage_with_true_effect(self):
        rng = np.random.default_rng(12)
        R, cover, rej = 300, 0, 0
        for r in range(R):
            v, b = simulate(rng, icc=0.10, mean=0.35)
            o = studentized_block_bootstrap(v, b, B=499, seed=r)
            cover += o["lo"] <= 0.35 <= o["hi"]
            rej += o["lo"] > 0
        self.assertGreater(cover / R, 0.90)
        self.assertGreater(rej / R, 0.5)


if __name__ == "__main__":
    unittest.main()
