import json
import unittest
from collections import namedtuple

import numpy as np
import pandas as pd

from experiment_001.costs import FundingIndex, to_ns
from experiment_001.compare import decompose_fixed_path, funding_convention_check
from experiment_001.engine_model import DataRejected, find_exit
from experiment_001.records import load_records, make_trade_id
from experiment_001.run import run_experiment, results_markdown, Thresholds

Bar = namedtuple("Bar", "time open high low close")
FEE, SLIP = 0.0005, 0.0002


def candles(n=12000, seed=3, drift=0.0, start="2025-01-01"):
    rng = np.random.default_rng(seed)
    close = 100 * np.exp(np.cumsum(rng.normal(drift, 0.002, n)))
    open_ = np.concatenate([[100.0], close[:-1]]) * (1 + rng.normal(0, 0.0007, n))   # gaps
    sp = np.abs(rng.normal(0, 0.001, n))
    return pd.DataFrame({"time": pd.date_range(start, periods=n, freq="5min", tz="UTC"), "open": open_,
                         "high": np.maximum(open_, close) * (1 + sp), "low": np.minimum(open_, close) * (1 - sp),
                         "close": close})


def engine_literal(side, bars, stop, target, fee, slip, funding_total):
    """Line-by-line copy of the pasted signals_v2/replay.py logic (independent oracle)."""
    entry = bars[0].open * (1 + side * slip)
    if side == 1 and not stop < entry < target:
        raise DataRejected("invalid_long_levels_at_fill")
    if side == -1 and not target < entry < stop:
        raise DataRejected("invalid_short_levels_at_fill")
    risk = abs(entry - stop)
    reason, exit_ref, held = "TIMEOUT", bars[-1].close, len(bars)
    for i, bar in enumerate(bars, 1):
        stop_hit = bar.low <= stop if side == 1 else bar.high >= stop
        target_hit = bar.high >= target if side == 1 else bar.low <= target
        if stop_hit:
            reason, exit_ref, held = "STOP", min(stop, bar.open) if side == 1 else max(stop, bar.open), i
            break
        if target_hit:
            reason, exit_ref, held = "TARGET", target, i
            break
    exit_fill = exit_ref * (1 - side * slip)
    gross_r = side * (exit_fill - entry) / risk
    fee_r = fee * (entry + exit_fill) / risk
    funding_r = side * funding_total * entry / risk
    return dict(entry=entry, exit_fill=exit_fill, risk=risk, gross_r=gross_r, fee_r=fee_r, funding_r=funding_r,
                net_r=gross_r - fee_r - funding_r, reason=reason, exit_ref=exit_ref, held=held)


def make_proposals(c, n, seed, horizon=24, picker=None):
    rng = np.random.default_rng(seed)
    out, idx = [], 400
    while len(out) < n and idx < len(c) - horizon - 2:
        i = idx if picker is None else picker(idx)
        idx += int(rng.integers(30, 60))
        if i is None:
            continue
        side = 1 if rng.random() < 0.5 else -1
        o, sp = c.open[i], float(rng.uniform(0.003, 0.012))
        out.append(dict(i=i, side=side, stop=o * (1 - side * sp), target=o * (1 + side * sp * 2), h=horizon,
                        strategy=["trend_pullback", "vol_breakout"][len(out) % 2]))
    return out


def run_engine(c, props, fee, slip, fidx=None, interval=pd.Timedelta("5min")):
    rows = []
    for k, p in enumerate(props):
        bars = [Bar(c.time[j], c.open[j], c.high[j], c.low[j], c.close[j]) for j in range(p["i"], p["i"] + p["h"])]
        tid = make_trade_id("SOLUSDT", p["strategy"], c.time[p["i"] - 1], "LONG" if p["side"] == 1 else "SHORT")
        base = dict(trade_id=tid, symbol="SOLUSDT", strategy=p["strategy"], direction="LONG" if p["side"] == 1 else "SHORT",
                    entry_time=bars[0].time, entry_open=bars[0].open, stop=p["stop"], target=p["target"],
                    fee_rate_per_side=fee, slippage_rate_per_side=slip, horizon_bars=p["h"])
        try:
            # pilot-style: first pass without funding to learn the duration, second pass with funding
            held = engine_literal(p["side"], bars, p["stop"], p["target"], fee, slip, 0.0)["held"]
            exit_time = bars[held - 1].time
            fund = 0.0 if (fidx is None or slip == 0 and fee == 0) else float(fidx.sum_between(
                to_ns([bars[0].time])[0], to_ns([exit_time + interval])[0]))
            r = engine_literal(p["side"], bars, p["stop"], p["target"], fee, slip, fund)
            rows.append({**base, "status": "FILLED", "exit_time": exit_time, "exit_ref": r["exit_ref"],
                         "exit_reason": r["reason"], "held_bars": r["held"], "funding_rate_total": fund,
                         "engine_entry_fill": r["entry"], "engine_exit_fill": r["exit_fill"], "engine_risk": r["risk"],
                         "engine_gross_r": r["gross_r"], "engine_fee_r": r["fee_r"], "engine_funding_r": r["funding_r"],
                         "engine_net_r": r["net_r"], "reconstruction_error": ""})
        except DataRejected as e:
            rows.append({**base, "status": "REJECTED", "reject_reason": str(e), "funding_rate_total": 0.0})
    return pd.DataFrame(rows)


def expected_of(ref):
    f = ref[ref.status == "FILLED"]
    return {"n_trades": int(len(f)), "net_r_sum": float(f.engine_net_r.sum()),
            "by_strategy": {k: {"n": int(len(g)), "net_r_sum": float(g.engine_net_r.sum())} for k, g in f.groupby("strategy")}}


def funding_idx(c):
    ft = pd.date_range(c.time.iloc[0], c.time.iloc[-1], freq="8h", tz="UTC")
    rng = np.random.default_rng(1)
    return FundingIndex(ft, rng.normal(0.0001, 0.0001, len(ft)))


class EngineEquivalence(unittest.TestCase):
    def test_vectorized_exit_equals_literal_loop(self):
        c = candles(n=3000, seed=5)
        rng = np.random.default_rng(2)
        for _ in range(1500):
            i, h = int(rng.integers(10, 2900)), int(rng.integers(3, 40))
            side = 1 if rng.random() < .5 else -1
            o, sp = c.open[i], rng.uniform(0.001, 0.02)
            stop, target = o * (1 - side * sp), o * (1 + side * sp * rng.uniform(.5, 3))
            bars = [Bar(0, c.open[j], c.high[j], c.low[j], c.close[j]) for j in range(i, i + h)]
            try:
                lit = engine_literal(side, bars, stop, target, 0, 0, 0)
            except DataRejected:
                continue
            reason, ref, held = find_exit(side, c.open[i:i + h].to_numpy(), c.high[i:i + h].to_numpy(),
                                          c.low[i:i + h].to_numpy(), c.close[i:i + h].to_numpy(), stop, target)
            self.assertEqual((reason, held), (lit["reason"], lit["held"]))
            self.assertAlmostEqual(ref, lit["exit_ref"], places=12)


class Pipeline(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.c = candles()
        cls.fidx = funding_idx(cls.c)
        cls.props = make_proposals(cls.c, 150, seed=7)
        cls.ref = run_engine(cls.c, cls.props, FEE, SLIP, cls.fidx)
        cls.zero = run_engine(cls.c, cls.props, 0.0, 0.0, cls.fidx)

    def test_decomposition_identity_and_reconciliation(self):
        f = load_records(self.ref)
        f = f[f.status == "FILLED"]
        fp = decompose_fixed_path(f.reset_index(drop=True))
        self.assertLess(fp.identity_err.max(), 1e-12)
        np.testing.assert_allclose(fp.r_full, f.engine_net_r.to_numpy(), atol=1e-12)
        np.testing.assert_allclose(fp.r_gross - fp.slippage_r - fp.fee_r - fp.funding_r, fp.r_full, atol=1e-12)

    def test_fixed_path_gross_equals_true_zero_cost_engine_run(self):
        rep, tables = run_experiment(self.ref, self.zero, None, None, th=Thresholds())
        z = rep["zero_cost_counterfactual"]
        self.assertTrue(z["zero_run_has_zero_costs"])
        self.assertEqual(z["n_both_filled_path_changed"], 0)
        self.assertLess(z["r_diff_on_identical_paths"]["max_abs"], 1e-9)

    def test_full_run_passes_gates_and_is_json_safe(self):
        cd = {"SOLUSDT": self.c}
        rep, _ = run_experiment(self.ref, self.zero, cd, {"SOLUSDT": self.fidx}, n_runs=20, seed=4, warmup_bars=300,
                                expected=expected_of(self.ref))
        for k, v in rep["gates"].items():
            self.assertTrue(v, k)
        self.assertNotEqual(rep["verdict"]["code"], "INCONCLUSIVE_GATES_FAILED")
        bad, _ = run_experiment(self.ref, self.zero, None, None, expected={"n_trades": 999, "net_r_sum": 1.0, "by_strategy": {"x": {"n": 999, "net_r_sum": 1.0}}})
        self.assertFalse(bad["gates"]["reproduces_original_reference"])
        self.assertTrue(bad["reference_reproduction"]["differences"])
        self.assertEqual(bad["verdict"]["code"], "INCONCLUSIVE_GATES_FAILED")
        self.assertEqual(rep["funding_convention_check"]["SOLUSDT"]["best"], "(t0,t1]")
        self.assertIn("random_baseline", rep)
        json.dumps(rep)
        self.assertIn("Verdict", results_markdown(rep))

    def test_random_vs_random_is_not_extreme(self):
        rep, _ = run_experiment(self.ref, self.zero, {"SOLUSDT": self.c}, {"SOLUSDT": self.fidx}, n_runs=60, seed=8)
        b = rep["random_baseline"]["ALL"]
        self.assertGreater(b["gross"]["p_value_ge_actual"], 0.01)
        self.assertGreater(b["net"]["p_value_ge_actual"], 0.01)
        self.assertLess(b["net"]["random_mean"], b["gross"]["random_mean"])   # costs hurt

    def test_tampering_blocks_conclusion(self):
        bad = self.ref.copy()
        j = bad.index[bad.status == "FILLED"][3]
        bad.loc[j, "engine_fee_r"] += 0.01
        rep, _ = run_experiment(bad, self.zero, None, None)
        self.assertFalse(rep["gates"]["reconciliation_vs_engine"])
        self.assertEqual(rep["verdict"]["code"], "INCONCLUSIVE_GATES_FAILED")

    def test_missing_engine_columns_blocks_conclusion(self):
        rep, _ = run_experiment(self.ref.drop(columns=["engine_net_r"]), self.zero, None, None)
        self.assertEqual(rep["verdict"]["code"], "INCONCLUSIVE_GATES_FAILED")

    def test_zero_run_that_is_not_zero_is_flagged(self):
        rep, _ = run_experiment(self.ref, self.ref, None, None)
        self.assertFalse(rep["gates"]["zero_cost_run_is_actually_zero"])
        self.assertEqual(rep["verdict"]["code"], "INCONCLUSIVE_GATES_FAILED")

    def test_missing_zero_run_blocks_conclusion(self):
        rep, _ = run_experiment(self.ref, None, None, None)
        self.assertFalse(rep["gates"]["zero_cost_run_provided"])
        self.assertEqual(rep["verdict"]["code"], "INCONCLUSIVE_GATES_FAILED")


class PathChange(unittest.TestCase):
    def test_slippage_rejection_is_visible_as_path_change(self):
        c = candles(n=2000, seed=9)
        i = 500
        o = c.open[i]
        # target only 1bp above open: valid at zero slippage, invalid after 2bp adverse slippage
        props = [dict(i=i, side=1, stop=o * 0.99, target=o * 1.0001, h=12, strategy="trend_pullback")]
        ref, zero = run_engine(c, props, FEE, SLIP), run_engine(c, props, 0.0, 0.0)
        self.assertEqual(ref.status.iloc[0], "REJECTED")
        self.assertEqual(zero.status.iloc[0], "FILLED")
        rep, tables = run_experiment(pd.concat([ref, run_engine(c, make_proposals(c, 60, 3), FEE, SLIP)], ignore_index=True)
                                     .drop_duplicates("trade_id"),
                                     pd.concat([zero, run_engine(c, make_proposals(c, 60, 3), 0.0, 0.0)], ignore_index=True)
                                     .drop_duplicates("trade_id"), None, None)
        self.assertEqual(rep["zero_cost_counterfactual"]["n_filled_in_zero_not_in_ref"], 1)
        self.assertIn("REJECTED->FILLED", rep["zero_cost_counterfactual"]["transitions"])
        self.assertEqual(rep["meta"]["n_rejected"], 1)
        self.assertEqual(len(tables["path_changes"]), 1)


class FundingConvention(unittest.TestCase):
    def test_detects_convention(self):
        c = candles(n=3000, seed=2)
        fidx = funding_idx(c)
        ref = load_records(run_engine(c, make_proposals(c, 40, 1), FEE, SLIP, fidx))
        f = ref[ref.status == "FILLED"]
        res = funding_convention_check(f, fidx, int(pd.Timedelta("5min").value))
        self.assertEqual(res["best"], "(t0,t1]")
        self.assertTrue(res["ok"])


class EdgeDetection(unittest.TestCase):
    def test_hindsight_edge_is_detected(self):
        c = candles(n=12000, seed=12, drift=0.0003)
        fidx = funding_idx(c)
        picker = lambda i: i if c.close[i + 12] > c.open[i] * 1.004 else None      # test-only lookahead
        props = make_proposals(c, 120, seed=3, picker=picker)
        ref, zero = run_engine(c, props, FEE, SLIP, fidx), run_engine(c, props, 0.0, 0.0, fidx)
        rep, _ = run_experiment(ref, zero, {"SOLUSDT": c}, {"SOLUSDT": fidx}, n_runs=60, seed=5)
        self.assertGreater(rep["fixed_path_gross"]["overall"]["gross_fixed_path"]["expectancy_r"], 0.2)
        self.assertLess(rep["random_baseline"]["ALL"]["gross"]["p_value_ge_actual"], 0.05)


if __name__ == "__main__":
    unittest.main()
