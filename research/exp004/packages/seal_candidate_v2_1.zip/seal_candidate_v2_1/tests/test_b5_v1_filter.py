"""B5 - V1 (min stop distance) is causal and runs inside the sequential replay; skips release the timeline."""
import unittest

import pandas as pd

from experiment_001.export_signalpilot import Hooks, export_symbol
from experiment_001.run import run_experiment
from test_exporter import (Candle, DataRejected, FEE, SLIP, Hypothesis, guarded_replay, replay)

STEP = 300_000
T0 = 1_735_689_600_000


def flat_five(n=400, price=100.0):
    return [Candle(T0 + k * STEP, T0 + (k + 1) * STEP, price, price + 0.01, price - 0.01, price) for k in range(n)]


def hooks_two_signals(d1, d2, entry=100.0):
    plan = {d1: ("trend_pullback", "LONG", 0.002),         # 0.20% stop  -> below the 0.40% V1 threshold
            d2: ("volatility_breakout", "LONG", 0.010)}    # 1.00% stop  -> passes V1

    def candidates(symbol, history, micro, decision):
        if decision not in plan:
            return []
        name, side, sp = plan[decision]
        return [Hypothesis(name, side, entry * (1 - sp), entry * (1 + 2 * sp), entry)]
    return Hooks(eligible=lambda *a: (True, ""), candidates=candidates, replay_hypothesis=lambda p: p,
                 guarded_replay=guarded_replay, replay_core=replay, rejected_exceptions=(DataRejected,))


def run(five, hooks, min_stop_pct):
    one = list(five)
    return pd.DataFrame(export_symbol("SOLUSDT", five, one, [c.available_at_ms for c in one], [], None, hooks, stride=1,
                                      fee=FEE, slip=SLIP, funding_enabled=False, min_stop_pct=min_stop_pct))


class V1Filter(unittest.TestCase):
    def setUp(self):
        self.five = flat_five()
        self.d1 = self.five[100].available_at_ms
        self.d2 = self.five[112].available_at_ms            # 12 bars later: inside d1's 48-bar TIMEOUT hold
        self.hooks = hooks_two_signals(self.d1, self.d2)

    def test_without_filter_first_trade_blocks_second(self):
        df = run(self.five, self.hooks, None)
        self.assertEqual(list(df.status), ["FILLED"])
        self.assertEqual(df.exit_reason.iloc[0], "TIMEOUT")
        self.assertEqual(df.held_bars.iloc[0], 48)

    def test_filtered_signal_releases_timeline(self):
        df = run(self.five, self.hooks, 0.004)
        self.assertEqual(list(df.status), ["FILTERED", "FILLED"])
        self.assertTrue(df.reject_reason.iloc[0].startswith("V1_min_stop_pct"))
        self.assertEqual(df.strategy.iloc[1], "volatility_breakout")        # d2 executed because d1 was skipped

    def test_threshold_boundary_is_strict_less_than(self):
        self.assertEqual(list(run(self.five, self.hooks, 0.002).status), ["FILLED"])            # 0.20% is not < 0.20%
        self.assertEqual(run(self.five, self.hooks, 0.0021).status.iloc[0], "FILTERED")

    def test_filter_uses_decision_time_data_only(self):
        corrupted = list(self.five)
        i = 101                                                  # first bar after d1's decision bar (index 100)
        for k in range(i, 130):
            c = corrupted[k]
            corrupted[k] = Candle(c.open_ms, c.available_at_ms, c.open * 1.5, c.high * 1.6, c.low * 0.5, c.close * 1.4)
        a = run(self.five, self.hooks, 0.004)
        b = run(corrupted, self.hooks, 0.004)
        self.assertEqual(a.status.iloc[0], b.status.iloc[0])
        self.assertEqual(a.trade_id.iloc[0], b.trade_id.iloc[0])
        self.assertEqual(a.reject_reason.iloc[0], b.reject_reason.iloc[0])

    def test_filtered_rows_flow_through_the_experiment_loader(self):
        ref = run(self.five, self.hooks, 0.004)
        zero = run(self.five, self.hooks, None)
        for fr in (ref, zero):
            fr["fee_rate_per_side"] = fr["fee_rate_per_side"].fillna(FEE)
        rep, _ = run_experiment(ref, zero, None, None)
        self.assertEqual(rep["meta"]["n_proposals"], 2)
        self.assertEqual(rep["meta"]["n_filled"], 1)


if __name__ == "__main__":
    unittest.main()
