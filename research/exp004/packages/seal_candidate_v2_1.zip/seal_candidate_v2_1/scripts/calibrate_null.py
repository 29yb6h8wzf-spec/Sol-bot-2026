"""B4 calibration: size under a zero-edge world and power under a look-ahead edge world (synthetic only)."""
import json
import sys
import time

import numpy as np

sys.path.insert(0, ".")
from experiment_001.null_model import run_conditional_null
from experiment_001.synth import market, real_run

WEEKS, REPS, B = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
out = {"weeks": WEEKS, "reps": REPS, "B": B, "scenarios": {}}
for name, foresight in (("zero_edge", 0.0), ("lookahead_edge", 0.15)):
    ps_g, ps_n, gross_actual, n_trades, short, ident = [], [], [], [], [], []
    t0 = time.time()
    for rep in range(REPS):
        rng = np.random.default_rng([99, rep, int(foresight * 100)])
        c = {"SOLUSDT": market(WEEKS * 2016, 1000 + rep), "XRPUSDT": market(WEEKS * 2016, 5000 + rep)}
        fp = real_run(c, rng, fire_prob=0.08, foresight=foresight)
        s, _ = run_conditional_null(fp, c, None, n_runs=B, seed=rep)
        a = s["ALL"]
        ps_g.append(a["gross"]["p"]); ps_n.append(a["net"]["p"]); gross_actual.append(a["gross"]["actual"])
        n_trades.append(a["n_actual"]); short.append(a["shortfall_share"]); ident.append(a["paired_flags_identical_share"])
    ps_g = np.array(ps_g)
    res = {"seconds": round(time.time() - t0), "mean_trades": float(np.mean(n_trades)), "mean_actual_gross_R": float(np.mean(gross_actual)),
           "reject_rate_p_lt_0.025": float((ps_g < 0.025).mean()), "reject_rate_p_lt_0.05": float((ps_g < 0.05).mean()),
           "reject_rate_p_lt_0.10": float((ps_g < 0.10).mean()), "mean_p": float(ps_g.mean()),
           "p_quartiles": [float(x) for x in np.quantile(ps_g, [.25, .5, .75])],
           "mean_shortfall_share": float(np.mean(short)), "mean_paired_flag_agreement": float(np.mean(ident)),
           "mc_se_of_rate_at_0.025": float(np.sqrt(0.025 * 0.975 / REPS))}
    out["scenarios"][name] = res
    print(name, json.dumps(res), flush=True)
json.dump(out, open("results/null_calibration.json", "w"), indent=2)
