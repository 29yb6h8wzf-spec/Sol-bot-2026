"""Seal candidate manifest: SHA-256 of every protocol/code/test/config file + a root hash. --verify re-checks.
Publishing the root hash (before 2026-12-01) is what makes the seal; this script only computes."""
import hashlib
import os
import platform
import sys
from datetime import datetime, timezone

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SKIP_DIRS = {"__pycache__", ".git"}
SKIP_FILES = {"SEAL_MANIFEST.sha256", "SEAL_ROOT.txt"}


def files():
    out = []
    for d, dirs, fs in os.walk(ROOT):
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS)
        for f in sorted(fs):
            if f in SKIP_FILES or f.endswith(".pyc"):
                continue
            out.append(os.path.relpath(os.path.join(d, f), ROOT).replace(os.sep, "/"))
    return sorted(out)


def sha(path):
    h = hashlib.sha256()
    with open(os.path.join(ROOT, path), "rb") as fh:
        h.update(fh.read())
    return h.hexdigest()


def build():
    return "".join(f"{sha(p)}  {p}\n" for p in files())


if __name__ == "__main__":
    manifest = build()
    root_hash = hashlib.sha256(manifest.encode()).hexdigest()
    if "--verify" in sys.argv:
        ok = (open(os.path.join(ROOT, "SEAL_MANIFEST.sha256")).read() == manifest)
        print("VERIFIED" if ok else "MISMATCH", root_hash)
        sys.exit(0 if ok else 1)
    open(os.path.join(ROOT, "SEAL_MANIFEST.sha256"), "w").write(manifest)
    import numpy, pandas
    open(os.path.join(ROOT, "SEAL_ROOT.txt"), "w").write(
        f"root_sha256 {root_hash}\nfiles {len(manifest.splitlines())}\ngenerated_utc {datetime.now(timezone.utc).isoformat()}\n"
        f"python {platform.python_version()} pandas {pandas.__version__} numpy {numpy.__version__}\n"
        "STATUS: CANDIDATE - binding only after the owner publishes this root hash before 2026-12-01\n")
    print(root_hash, len(manifest.splitlines()), "files")
