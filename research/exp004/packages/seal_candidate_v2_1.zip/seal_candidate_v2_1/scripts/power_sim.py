"""B8 / S-1: size, power and retirement-power of the registered block-bootstrap decision, on SYNTHETIC data.
Planning inputs that come from exposed data (flagged): trade SD ~1.42R (September pilot), trade pace (September: ~120/month).
Everything else is a grid. No historical outcome file is read by this script."""
import json
import sys
import time

import numpy as np

sys.path.insert(0, ".")
from experiment_001.block_bootstrap import studentized_block_bootstrap

SIMS, B, WEEKS, ALPHA = int(sys.argv[1]), int(sys.argv[2]), 26, 0.025
MEI = {"BASE": 0.55, "V1": 0.35}


def sim(rng, n_total, sd, icc, mean):
    lam = n_total / WEEKS
    ms = np.maximum(rng.poisson(lam, WEEKS), 1)
    f = rng.normal(0, sd * np.sqrt(icc), WEEKS)
    vals = np.concatenate([mean + f[w] + rng.normal(0, sd * np.sqrt(1 - icc), m) for w, m in enumerate(ms)])
    blocks = np.concatenate([np.full(m, w) for w, m in enumerate(ms)])
    return vals, blocks


def cell(n_total, sd, icc, effect, seed):
    rng = np.random.default_rng(seed)
    rej = ret_v1 = ret_base = 0
    for r in range(SIMS):
        v, b = sim(rng, n_total, sd, icc, effect)
        o = studentized_block_bootstrap(v, b, alpha_one_sided=ALPHA, B=B, seed=r)
        rej += o["lo"] > 0
        ret_v1 += o["hi"] < MEI["V1"]
        ret_base += o["hi"] < MEI["BASE"]
    return {"p_lower_gt_0": rej / SIMS, "p_hi_lt_MEI_V1": ret_v1 / SIMS, "p_hi_lt_MEI_BASE": ret_base / SIMS}


t0 = time.time()
out = {"sims": SIMS, "B": B, "weeks": WEEKS, "alpha_one_sided": ALPHA, "MEI": MEI, "sd_planning_input_EXPOSED": 1.42, "grid": []}
Ns = [150, 200, 300, 400, 500, 600, 800, 1000]
for icc in (0.0, 0.05, 0.10, 0.15):
    for n in Ns:
        for eff in (0.0, 0.20, 0.35, 0.55):
            row = {"icc": icc, "n_trades": n, "sd": 1.42, "true_gross_effect": eff,
                   **cell(n, 1.42, icc, eff, seed=int(1000 * icc) + n + int(100 * eff))}
            out["grid"].append(row)
    print("icc", icc, "done", round(time.time() - t0), "s", flush=True)
for sd in (1.2, 1.7):                                      # sensitivity of the planning SD
    for n in Ns:
        for eff in (0.0, 0.35):
            out["grid"].append({"icc": 0.10, "n_trades": n, "sd": sd, "true_gross_effect": eff,
                                **cell(n, sd, 0.10, eff, seed=77 + n + int(100 * eff) + int(sd * 10))})
json.dump(out, open("results/power_sim.json", "w"), indent=1)
print("saved", round(time.time() - t0), "s")
