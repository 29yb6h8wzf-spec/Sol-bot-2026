# Pre-registration v2.1 - Experiment 002 (SEAL CANDIDATE; supersedes v2 and the void v1)
Research / paper only. Nothing here authorizes trading. Becomes binding only when the owner publishes the root hash (section 9).

## 1. Two tiers, never mixed
- Tier H (historical replication): 24 months 2024-11..2026-10 (SOLUSDT, XRPUSDT) incl. the 2026-09 pilot. EXPOSED data (monthly V3 outcomes
  from run 42856413197, aggregate 42856799813 published 2026-11-10, before the draft). Descriptive only; strict reproduction gate; no confirmatory claim.
- Tier C (confirmatory): UTC 2026-12-01 00:00:00 .. 2027-05-31 23:59:59 (26 weeks / 182 days). Data that did not exist at drafting.
  2026-11 is an unused buffer. Not opened, not run, not previewed before 2027-06-01.

## 2. Frozen configuration (protocol_config_v2_1.json is the single source of truth; tests guard drift)
Code: commit 76b6aca strategies/router/replay + this package. Stride 12 5m bars, first entry bar 64, horizon 48 bars, SOLUSDT+XRPUSDT.
Costs scenario: taker 5 bp/side, slippage 2 bp/side, historical funding, convention (t0,t1]; maker 2 bp only as a stated assumption.
Account commission record (GET /fapi/v1/commissionRate) attached or reported as MISSING/STALE/MISMATCH.

## 3. Arms (V1 option C, chosen by the owner's delegation; rationale in section 8)
- BASE: the only confirmatory arm. One-sided alpha 0.05 (family of one), interval level 0.90.
- V1 (skip signals with |entry_ref - stop_ref| / entry_ref < 0.40%, decision-time data only, inside the sequential loop, skip releases the timeline):
  EXPLORATORY. Same estimator and gates, full report, NO decision state. Promotion needs a new pre-registration on new unseen data.
- V2 (maker entries): exploratory, no maker model.

## 4. Estimand and tests (BASE)
Mean gross R and mean net R per executed trade (engine formulas, fixed path), pooled SOL+XRP.
Stage G then Stage N (fixed sequence, no extra alpha). Inference: 7-day Monday-aligned UTC blocks by exit time, SOL and XRP in the same block,
studentized bootstrap B=10,000, seed 20261111 (same code for gross and net); 14-day and 1-day blocks are sensitivity only.
Null: conditional random-entry null, 10,000 runs, same grid/masks/overlap rule (per symbol across strategies), week strata, paired exceedance flags kept, p=(1+k)/(1+B).
States (first match): INVALID (any gate fails / non-finite / interval level != 1-2*alpha) -> INCONCLUSIVE_INSUFFICIENT (trades < 500 or non-empty weeks < 24)
-> Stage G rejects iff lower bound > 0 AND null p < 0.05 (strict) -> EDGE_NET_SUPPORTED (net lower > 0) or COSTS_ERASE_EDGE
-> RETIRE (gross upper bound < MEI_BASE = 0.55R, strict) -> INCONCLUSIVE_POWER. "Not rejected" never means "zero edge".
Gates: the eight Experiment-001 gates (strict reproduction applies to tier H only).
No interim outcome analysis. Counts-only extension in 13-week steps if trades/blocks are short (never decided from outcomes).

## 5. What the simulations showed (synthetic; planning inputs from September are EXPOSED and flagged)
Block CI size (alpha 0.025 grid): 0.01-0.043; at alpha 0.05: 0.045-0.052 for ICC <= 0.10, 0.060-0.068 at ICC 0.15 (mild inflation, disclosed).
BASE (MEI 0.55R, SD 1.42R): power and retire power >= 0.99 at 500-730 trades (ICC <= 0.10), >= 0.99 at ICC 0.15.
Null: zero-edge reject rate 0.023 at 0.025 (MC SE 0.009), 0.057 at 0.05; detects a +0.065R look-ahead edge in 19% at alpha 0.025.
N_min = 500 was sized at alpha 0.025 for the V1 MEI (power 0.90 at ICC 0.10); it is conservative for BASE.

## 6. Mandatory reporting
Gates; excluded opportunities by month/symbol/reason; conflicts/collisions; ambiguous candles; per-block table; cost sensitivity (slippage 0/2/5 bp, fee 4/5 bp);
funding sensitivity and exit-candle ambiguity; with/without historical exclusion masks (not deployable foresight); V1 exploratory results; slices < 30 trades descriptive only.
Scope: SOL/XRP only; no generalization.

## 7. Implementation status (all verified on synthetic data only)
B1 strict reproduction, B2 decision rule, B3 block bootstrap, B4 conditional null, B5 V1 inside the sequential loop, B6 look-ahead tests against the real signal modules,
B7 funding boundaries, B8 power simulation, B9 commission record: done; 88 tests pass in the build environment (Python 3.12.3, pandas 3.0.6, numpy 2.5.4).
NOT verified: the owner's pinned environment (Python 3.12.14, pandas 2.2.3, numpy 2.3.5); real guarded_replay/eligible with the real manifest in B5/B7 tests;
schema of the 24 monthly expected.json files (never opened).

## 8. Why option C
V1 keeps ~24% of trades (September stop distances: p75 = 0.387%) -> ~175 trades per 26 weeks vs N_min 500: a confirmatory V1 would almost surely be INCONCLUSIVE_INSUFFICIENT
and need ~70 weeks. V1 only lowers costs; it cannot create gross edge, so if BASE shows no gross edge V1 has little left to confirm. If BASE supports an edge, V1 gets a fresh registration.

## 9. Seal procedure (owner actions; the assistant cannot publish)
1. Run `python -m unittest discover -s tests` in the pinned environment; all tests must pass.
2. Commit this package to the research branch; run `python scripts/make_seal_manifest.py` (writes SEAL_MANIFEST.sha256 and SEAL_ROOT.txt); verify with `--verify`.
3. Tag and publish the root hash (commit message/issue/gist) BEFORE 2026-12-01. Any later change = new protocol version, and no Tier C data may have been processed.
4. Record the exposure log (which outcome files were opened, by whom/what, when).

## 10. Forbidden
Opening/running Tier C before 2027-06-01; tuning on Tier C; changing thresholds after results; real orders; changing live risk limits; merge/deploy.
Even EDGE_NET_SUPPORTED permits forward paper trading only.
