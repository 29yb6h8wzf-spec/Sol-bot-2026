# Experiment 001 v3 - SignalPilot reference run, exporter, Gross vs Net (research / paper only)

All numbers in tests/demos are SYNTHETIC. Nothing here edits the engine, places orders, merges or deploys.

## Workflow
1. Fill signalpilot_plugin_TEMPLATE.py (4 TODOs) inside the research branch.
2. python -m experiment_001.export_signalpilot --plugin signalpilot_plugin.py --out inputs
   -> inputs/reference.csv (original costs), inputs/zero_cost.csv (fee=slip=funding=0, separate real-engine run),
      inputs/reference_summary.json
3. Put the ORIGINAL pilot totals in expected.json: {"n_trades": N, "net_r_sum": X, "by_strategy": {"s": {"n":..,"net_r_sum":..}}}
4. python -m experiment_001.run --reference inputs/reference.csv --zero-cost inputs/zero_cost.csv \
     --expected expected.json --klines-dir <5m zips> --funding-dir <funding csvs> --out out --runs 1000
   (--expected-abs-tol 0.005 only if the original summary is rounded to 2 decimals)
5. python -m unittest discover -s tests

## What the exporter guarantees
* Loop copied from pilot_replay.py; repo functions injected via Hooks.
* Stable trade_id = symbol|decision_ms|strategy|direction (never the row number).
* REJECTED proposals exported with reject_reason; next_allowed is not updated by them.
* Zero-cost run: replay.__kwdefaults__ overridden temporarily + funding 0; costs INFERRED from the engine result and
  compared to the request -> ExportError if the override did not take effect.
* gross_r/exit_ref/slippage are reconstructed from bars + formulas and verified vs the engine's exit_reason, bars_held,
  exit_fill (column reconstruction_error).

## Gates (any failure => INCONCLUSIVE_GATES_FAILED, numbers shown for inspection only)
reproduces_original_reference, exit_reconstruction_ok, reconciliation_vs_engine, cost_identity, gross_defined_share_ok,
zero_cost_run_provided, zero_cost_run_is_actually_zero, path_stable_under_zero_cost (thresholds in run.Thresholds).
Trade counts are NOT assumed equal between runs: they are matched by trade_id and reported (transitions, cascades).

## Random baseline
Priced with the engine's accounting; no-overlap per SYMBOL shared across strategies (next entry bar >= entry bar + held);
rejected fills do not occupy the timeline; stop% / RR / horizon sampled jointly from real trades; fixed seeds.

## Unverified (cannot be checked without the real repo/data)
* Candle / Hypothesis attribute names, DataRejected being raised by guarded_replay, initial value of next_allowed.
* Whether guarded_replay forwards cost kwargs or relies on replay's defaults (the override check covers both).
* Kline/funding file loaders on real Binance files; 'available_at_ms' semantics for funding windows
  (report.funding_convention_check compares conventions against the reference).
* Slippage cost in R includes the risk-denominator effect; cost order slip->fee->funding is a convention.
