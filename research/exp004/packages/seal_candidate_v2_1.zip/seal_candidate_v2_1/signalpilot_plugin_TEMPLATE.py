"""Glue between experiment_001.export_signalpilot and the SignalPilot repo. COPY into the repo (research branch),
rename, and fill the 4 TODOs. Nothing here changes the engine.

    python -m experiment_001.export_signalpilot --plugin signalpilot_plugin.py --out experiment_001_inputs
"""
from experiment_001.export_signalpilot import Hooks

# TODO 1: real imports (names as in the pasted loop / signals_v2)
# from signals_v2.replay import replay, DataRejected
# from signals_v2.guarded_replay import guarded_replay
# from signals_v3.pilot_replay import eligible, candidates, replay_hypothesis   # wherever they actually live

SYMBOLS = []        # TODO 2: exactly the symbols of the original pilot run
STRIDE = 1          # TODO 3: the SAME stride the original run used


def hooks() -> Hooks:
    return Hooks(eligible=eligible, candidates=candidates, replay_hypothesis=replay_hypothesis,
                 guarded_replay=guarded_replay, replay_core=replay, rejected_exceptions=(DataRejected,))


def load(symbol):
    """TODO 4: return exactly what the original loop has in scope for this symbol:
    five (5m Candle list), one (1m Candle list), one_times (the list used by bisect on `one`),
    funding (list of (time_ms, rate)), intervals (what eligible()/guarded_replay() receive)."""
    raise NotImplementedError
