# B1-B9 implementation report (pre-registration v2) - for approval BEFORE any seal
Scope respected: code + tests on SYNTHETIC data only. No monthly results file was opened (Monthly_references.zip entries were not read),
no 2024-2026 historical analysis, no seal/hash, no merge/deploy. Planning inputs taken from the already-seen September pilot are flagged (EXPOSED).

## Test status: 83 tests, all pass (python -m unittest discover -s tests)
| Item | What was built | Tests |
|---|---|---|
| B1 | strict_repro.py: exact schema, unknown/misspelled keys fail, exact group sets, internal consistency, optional digest + row-level check | misspelled key, unknown key, garbage/None, missing/extra group, inconsistent file, swapped outcomes across groups (caught), within group (grouped blind spot documented; row-level catches), shifted timestamp (row-level), wrong funding sign (caught), digest/ID-set |
| B2 | decision.py: 5 states, strict inequalities, gates dominate, level must equal 1-2*alpha, n_min has no default | n=499/500, blocks 23/24, CI lower exactly 0, p exactly 0.025, hi exactly MEI (V1, BASE), failed gate dominates, NaN/level mismatch, family alpha |
| B3 | block_bootstrap.py: synchronized 7-day Monday-aligned blocks, studentized, same code for gross and net, 14d/1d sensitivity | size under correlated zero-mean data: block 0.02 vs naive trade-level 0.14-0.27 (nominal 0.025); coverage and power; empty weeks counted; month boundary |
| B4 | null_model.py: conditional null on the real grid (64+12k), masks, per-symbol overlap across strategies, week strata, paired exceedance flags | calibration (300 reps x 199 runs, 12 weeks, ~316 trades): zero-edge reject rate 0.023 at alpha 0.025 (MC SE 0.009), 0.057 at 0.05, 0.103 at 0.10; look-ahead edge world (+0.065R gross) rejects 19.3% -> detects, low power for a tiny edge; shortfall 0%; paired gross/net flags agree in 95.8-97.3% of runs |
| B5 | export_symbol(min_stop_pct): V1 causal filter on decision-time fields inside the sequential loop; status FILTERED releases the timeline | filter vs no filter changes which signal executes; strict < boundary; invariant to corrupted future bars; flows through the experiment loader |
| B6 | tests against the REAL signals_v3 modules with synthetic bars | candidates invariant to corrupted post-decision bars (>100 decisions, non-vacuous), bar available_at = decision+1 rejected by every specialist (5m and 1m), exact-boundary accepted, exporter slices contain no future bar |
| B7 | funding_exit_candle_uncertainty + boundary tests | payment at entry excluded, at actual_end included, 1 ms after excluded; boundary payments make the two conventions distinguishable (September could not); STOP exit inside candle flagged with its R size; TIMEOUT no ambiguity |
| B8 | scripts/power_sim.py (400 sims/cell, B=499) | see below |
| B9 | commission.py + template + wiring (report["commission_check"]) | VERIFIED / MISMATCH / STALE / MISSING, malformed never raises, template rejected |
Also: tier flag in run_experiment (strict reproduction only in tier H), confirmatory.py (gates -> block CIs -> null p -> decision), end-to-end synthetic tests.

## S-1 power simulation (26 weekly blocks, SD 1.42R EXPOSED, ICC planning 0.10)
Type I of the block CI (delta=0): 0.01-0.043 across the grid (nominal 0.025). Slightly high (0.04) at ICC 0.15, n 400-600 - noted, not corrected.
Power P(lower bound > 0) at the V1 MEI (true gross 0.35R) / retire power P(upper < 0.35 | delta=0):
| trades | ICC 0.05 | ICC 0.10 | ICC 0.15 |
|---|---|---|---|
| 300 | 0.88 / 0.89 | 0.76 / 0.79 | 0.68 / 0.70 |
| 400 | 0.93 / 0.94 | 0.83 / 0.82 | 0.73 / 0.72 |
| 500 | 0.97 / 0.95 | 0.90 / 0.87 | 0.76 / 0.71 |
| 600 | 0.98 / 0.96 | 0.87 / 0.92 | 0.80 / 0.77 |
| 800 | 0.98 / 0.98 | 0.91 / 0.91 | 0.77 / 0.81 |
BASE arm (MEI 0.55): power and retire power >= 0.96 already at 300 trades for ICC <= 0.10. SD sensitivity (ICC 0.10, n=500): SD 1.2 -> 0.97, 1.42 -> 0.90, 1.7 -> 0.74.
The conditional-null p-value is an additional requirement of Stage G, so N_min is set with a margin (target 0.90 block power).

## Proposed final parameters (NOT sealed - need your approval)
- alpha one-sided per arm 0.025 (family of 2), interval level 0.95, fixed-sequence gross -> net. [unchanged]
- Blocks: 7-day Monday-aligned UTC, SOL+XRP synchronized, by exit time; studentized bootstrap B=10,000, seed 20261111; 14d and 1d as sensitivity. [new, from B3]
- N_min = 500 trades per arm (ICC 0.10 planning: power 0.90 at 0.35R, retire power 0.87). [from S-1]
- min_blocks = 24 of 26 weeks (allows 2 empty weeks). [CHANGE vs v2 text "26" - needs approval]
- MEI gross: BASE 0.55R, V1 0.35R. [unchanged]
- Null: 10,000 runs, seed 20261111, stride 12, first entry bar 64, per-symbol overlap across strategies. [from B4]
- Horizon 2026-12-01 .. 2027-05-31 (26 weeks); counts-only extension in 13-week steps. [step length proposed]
- Funding convention (t0,t1], exit-candle ambiguity reported; commission record attached or status reported.

## Decision needed: V1 cannot reach N_min in 26 weeks at September's pace (EXPOSED planning input)
September stop distances: p75 = 0.387%, p90 = 0.605% (already reported), so only ~24% of trades have stop >= 0.40%.
At ~730 trades per 26 weeks (September pace x 6; one month only!) BASE gets ~730, V1 about 175 -> expected state INCONCLUSIVE_INSUFFICIENT.
Options: (A) keep V1, pre-register the expectation, extend by counts only (about 70 weeks to reach 500); (B) lower the V1 threshold (0.30% keeps ~38%, ~280 trades;
0.25% keeps ~50%) - but any threshold was chosen after seeing exposed data; (C) drop V1 from the confirmatory family (BASE alone gets alpha 0.05, V1 becomes exploratory);
(D) set a smaller N_min for V1 (300: power 0.76 at ICC 0.10 - weaker). I recommend (A) or (C); this is your call, and it must be fixed before the seal.

## Limits (be aware)
- B5/B7 tests use a fake engine that is a literal copy of replay.py math; B6 uses the real signal modules; the real guarded_replay/eligible were not exercised (needs the intervals manifest).
- I did not open the 24 monthly expected.json files; the strict gate accepts the September format (n_trades, net_r_sum, by_strategy{n, net_r_sum}); if the monthly files differ it will fail loudly, which is intended.
- Null approximation (first c_w feasible points of a random subset per week) is disclosed and passed the size test on synthetic data, not on real markets.
- All power numbers depend on SD, ICC and pace, none of which is known for the future period.
