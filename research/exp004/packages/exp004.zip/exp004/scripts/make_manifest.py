"""SHA-256 manifest of Experiment 004 code/config/registration (results/ and data/ excluded)."""
import hashlib
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SKIP_DIRS = {"__pycache__", "results", "data", ".git"}
SKIP_FILES = {"REGISTRATION_SEAL.txt", "MANIFEST.sha256"}


def build():
    out = []
    for d, dirs, fs in os.walk(ROOT):
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS)
        for f in sorted(fs):
            if f in SKIP_FILES or f.endswith(".pyc"):
                continue
            p = os.path.relpath(os.path.join(d, f), ROOT).replace(os.sep, "/")
            out.append(f"{hashlib.sha256(open(os.path.join(ROOT, p), 'rb').read()).hexdigest()}  {p}\n")
    text = "".join(sorted(out, key=lambda x: x.split('  ')[1]))
    return text, hashlib.sha256(text.encode()).hexdigest()


if __name__ == "__main__":
    text, root = build()
    if "--verify" in sys.argv:
        ok = open(os.path.join(ROOT, "MANIFEST.sha256")).read() == text
        print("VERIFIED" if ok else "MISMATCH", root)
        sys.exit(0 if ok else 1)
    open(os.path.join(ROOT, "MANIFEST.sha256"), "w").write(text)
    open(os.path.join(ROOT, "REGISTRATION_SEAL.txt"), "w").write(f"root_sha256 {root}\nfiles {len(text.splitlines())}\n")
    print(root, len(text.splitlines()), "files")
