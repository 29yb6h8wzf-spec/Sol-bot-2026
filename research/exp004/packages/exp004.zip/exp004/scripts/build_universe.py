"""python scripts/build_universe.py exchangeInfo.json [delisted.txt] > universe.json
exchangeInfo.json = response of GET /fapi/v1/exchangeInfo (USD-M futures). delisted.txt = one symbol per line (perpetuals that existed
in the window but no longer trade; take them from the public archive directory listing) - strongly recommended against survivorship bias."""
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from exp004.universe import select_symbols  # noqa: E402

info = json.load(open(sys.argv[1]))
delisted = [x.strip() for x in open(sys.argv[2]) if x.strip()] if len(sys.argv) > 2 else None
print(json.dumps(select_symbols(info, delisted), indent=1))
