import os
import sys
import unittest

import numpy as np
import pandas as pd

sys.path.insert(0, os.environ.get("EXP003_PATH", "/home/claude/exp003"))
from exp003 import config as C3                                  # noqa: E402
from exp003.strategies import run_strategy as run_strategy_003    # noqa: E402

from exp004 import config as C                                    # noqa: E402
from exp004.fetch_archives import months, urls                    # noqa: E402
from exp004.replicate import analyze_universe, decide, entry_ok_mask, run_t4   # noqa: E402
from exp004.universe import select_symbols                        # noqa: E402


def trend_series(n_bars=60 * 288, seed=1, price0=10.0, vol=1.5e5, drift=3e-5, start="2025-01-01"):
    rng = np.random.default_rng(seed)
    d, drifts = 0.0, np.zeros(n_bars)
    for i in range(n_bars):
        if i % 1700 == 0:
            d = rng.choice([-1, 0, 1]) * drift
        drifts[i] = d
    ret = drifts + rng.normal(0, 6e-4, n_bars)
    close = price0 * np.exp(np.cumsum(ret))
    open_ = np.concatenate([[price0], close[:-1]])
    high = np.maximum(open_, close) * (1 + np.abs(rng.normal(0, 2e-4, n_bars)))
    low = np.minimum(open_, close) * (1 - np.abs(rng.normal(0, 2e-4, n_bars)))
    return pd.DataFrame({"time": pd.date_range(start, periods=n_bars, freq="5min", tz="UTC"), "open": open_, "high": high,
                         "low": low, "close": close, "volume": vol, "filled": False})


class FakeFidx:
    def sum_between(self, a, b):
        return 0.0 * (np.asarray(b) - np.asarray(a))


def sym_data(bars, months_n=12, missing_funding=()):
    km = [f"2025-{i:02d}" for i in range(1, months_n + 1)]
    return {"bars": bars, "fidx": FakeFidx(), "kline_months": km, "funding_months": [m for m in km if m not in missing_funding],
            "missing_funding_months": list(missing_funding)}


class Config(unittest.TestCase):
    def test_t4_and_costs_equal_experiment_003(self):
        self.assertEqual(C.T4, C3.TREND["T4"])
        self.assertEqual(C.COSTS, C3.COSTS)
        self.assertEqual((C.BOOT, C.NULL), (C3.BOOT, C3.NULL))
        self.assertEqual(C.PRICE_BAND, (0.99, 150.0))


class Universe(unittest.TestCase):
    INFO = {"symbols": [
        {"symbol": "ADAUSDT", "contractType": "PERPETUAL", "quoteAsset": "USDT", "baseAsset": "ADA", "underlyingType": "COIN"},
        {"symbol": "SOLUSDT", "contractType": "PERPETUAL", "quoteAsset": "USDT", "baseAsset": "SOL", "underlyingType": "COIN"},
        {"symbol": "XRPUSDT", "contractType": "PERPETUAL", "quoteAsset": "USDT", "baseAsset": "XRP", "underlyingType": "COIN"},
        {"symbol": "BTCUSDT_250627", "contractType": "CURRENT_QUARTER", "quoteAsset": "USDT", "baseAsset": "BTC", "underlyingType": "COIN"},
        {"symbol": "BTCDOMUSDT", "contractType": "PERPETUAL", "quoteAsset": "USDT", "baseAsset": "BTCDOM", "underlyingType": "INDEX"},
        {"symbol": "USDCUSDT", "contractType": "PERPETUAL", "quoteAsset": "USDT", "baseAsset": "USDC", "underlyingType": "COIN"},
        {"symbol": "ETHUSDC", "contractType": "PERPETUAL", "quoteAsset": "USDC", "baseAsset": "ETH", "underlyingType": "COIN"},
        {"symbol": "LINKUSDT", "contractType": "PERPETUAL", "quoteAsset": "USDT", "baseAsset": "LINK", "underlyingType": "COIN"}]}

    def test_filters_and_survivorship_warning(self):
        r = select_symbols(self.INFO)
        self.assertEqual(r["selected"], ["ADAUSDT", "LINKUSDT"])
        self.assertEqual(r["excluded"]["SOLUSDT"], "already_used_in_experiments_001_003")
        self.assertEqual(r["excluded"]["BTCDOMUSDT"], "underlying_INDEX")
        self.assertEqual(r["excluded"]["USDCUSDT"], "stable_or_pegged")
        self.assertEqual(r["excluded"]["BTCUSDT_250627"], "not_perpetual")
        self.assertEqual(r["excluded"]["ETHUSDC"], "quote_not_usdt")
        self.assertIn("survivors only", r["survivorship_warning"])

    def test_delisted_symbols_are_added(self):
        r = select_symbols(self.INFO, delisted=["LUNAUSDT", "ADAUSDT"])
        self.assertIn("LUNAUSDT", r["selected"])
        self.assertEqual(r["n_delisted_included"], 1)
        self.assertIsNone(r["survivorship_warning"])


class Fetch(unittest.TestCase):
    def test_months_and_urls(self):
        ms = months()
        self.assertEqual((len(ms), ms[0], ms[-1]), (24, "2024-11", "2026-10"))
        u = urls("ADAUSDT", "2025-03")
        self.assertTrue(u["5m"].endswith("klines/ADAUSDT/5m/ADAUSDT-5m-2025-03.zip"))
        self.assertTrue(u["fundingRate"].endswith("fundingRate/ADAUSDT/ADAUSDT-fundingRate-2025-03.zip"))


class Masks(unittest.TestCase):
    def test_price_band_is_inclusive_and_causal(self):
        b = trend_series(n_bars=40 * 288)
        b.loc[:, "open"] = 0.98; b.loc[100:200, "open"] = 0.99; b.loc[300:400, "open"] = 150.0; b.loc[500:600, "open"] = 150.01
        m = entry_ok_mask(b, liq=None)
        self.assertFalse(m[:100].any()); self.assertTrue(m[100:201].all()); self.assertTrue(m[300:401].all()); self.assertFalse(m[500:601].any())

    def test_liquidity_uses_only_trailing_bars_and_skips_first_30_days(self):
        b = trend_series(n_bars=60 * 288, vol=1.5e5)
        m = entry_ok_mask(b, band=None)
        self.assertFalse(m[: 30 * 288].any())
        self.assertTrue(m[30 * 288 + 10])
        low = b.copy(); low["volume"] = 1.0
        self.assertFalse(entry_ok_mask(low, band=None).any())
        spike = b.copy(); spike.loc[45 * 288:, "volume"] = 1.0           # future liquidity collapse must not affect earlier bars
        a, c = entry_ok_mask(b, band=None), entry_ok_mask(spike, band=None)
        np.testing.assert_array_equal(a[: 45 * 288], c[: 45 * 288])


class Replication(unittest.TestCase):
    def test_run_t4_equals_experiment_003_when_unfiltered(self):
        b = trend_series(n_bars=120 * 288, seed=4)
        mine = run_t4(b, None, C.COSTS, "ADAUSDT", None)
        ref = run_strategy_003(b, "T4", C3.TREND["T4"], None, C3.COSTS, symbol="ADAUSDT")
        self.assertGreater(len(ref), 3)
        pd.testing.assert_frame_equal(mine.reset_index(drop=True), ref.reset_index(drop=True))

    def test_filtered_signal_releases_timeline_and_trades_do_not_overlap(self):
        b = trend_series(n_bars=120 * 288, seed=4)
        base = run_t4(b, None, C.COSTS, "ADAUSDT", None)
        ok = np.ones(len(b), bool)
        first_entry = int(b.index[b.time == base.iloc[0].entry_time][0])
        ok[first_entry] = False
        alt = run_t4(b, None, C.COSTS, "ADAUSDT", ok)
        self.assertNotEqual(base.iloc[0].entry_time, alt.iloc[0].entry_time)
        self.assertTrue((alt["entry_time"].to_numpy()[1:] > alt["exit_time"].to_numpy()[:-1]).all())

    def test_decide_boundaries(self):
        self.assertEqual(decide(300, 10, 0.01, 0.049, 0.01)["state"], "REPLICATION_SUPPORTED")
        self.assertEqual(decide(299, 10, 0.01, 0.01, 0.01)["state"], "INCONCLUSIVE_INSUFFICIENT")
        self.assertEqual(decide(300, 9, 0.01, 0.01, 0.01)["state"], "INCONCLUSIVE_INSUFFICIENT")
        self.assertEqual(decide(300, 10, 0.0, 0.01, 0.01)["state"], "REPLICATION_NOT_SUPPORTED")
        self.assertEqual(decide(300, 10, 0.01, 0.05, 0.01)["state"], "REPLICATION_NOT_SUPPORTED")
        self.assertEqual(decide(300, 10, 0.01, 0.01, 0.0)["state"], "REPLICATION_NOT_SUPPORTED")

    def test_universe_analysis_drops_bad_symbols_and_is_json_safe(self):
        import json
        data = {f"S{i}USDT": sym_data(trend_series(n_bars=200 * 288, seed=10 + i, price0=5.0 + i)) for i in range(4)}
        data["HIGHUSDT"] = sym_data(trend_series(n_bars=200 * 288, seed=99, price0=500.0))          # entirely above the band
        data["SHORTUSDT"] = sym_data(trend_series(n_bars=200 * 288, seed=98), months_n=3)
        data["NOFUNDUSDT"] = sym_data(trend_series(n_bars=200 * 288, seed=97), missing_funding=("2025-02",))
        data["NODATAUSDT"] = {"error": "no_kline_files"}
        rep, fp = analyze_universe(data, n_null=39)
        self.assertEqual(rep["symbols_dropped"], {"SHORTUSDT": "fewer_than_6_months", "NOFUNDUSDT": "missing_funding_months",
                                                  "NODATAUSDT": "no_kline_files"})
        self.assertNotIn("HIGHUSDT", set(fp["symbol"]))                    # band removes every trade of a 500-USD coin
        self.assertTrue(set(fp["symbol"]) <= {f"S{i}USDT" for i in range(4)})
        self.assertIn(rep["decision"]["state"], ("INCONCLUSIVE_INSUFFICIENT", "REPLICATION_SUPPORTED", "REPLICATION_NOT_SUPPORTED"))
        self.assertEqual(rep["gross_ci"]["level"], 0.90)
        self.assertEqual(set(rep["robustness_reported_only"]["slippage_sensitivity"]), {"0.0005", "0.001"})
        json.dumps(rep)

    def test_empty_universe_is_inconclusive(self):
        rep, fp = analyze_universe({"A": {"error": "no_kline_files"}}, n_null=9)
        self.assertEqual(rep["decision"]["state"], "INCONCLUSIVE_INSUFFICIENT")


if __name__ == "__main__":
    unittest.main()
