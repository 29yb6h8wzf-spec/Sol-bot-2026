"""Point-in-time-honest universe selection from a user-supplied exchangeInfo snapshot (GET /fapi/v1/exchangeInfo).
Survivorship: a snapshot lists symbols that trade NOW. Delisted perpetuals (still in the public archive) must be supplied via
`delisted` to avoid survivorship bias; if none are supplied the report says so."""
from __future__ import annotations

from . import config as C


def select_symbols(exchange_info: dict, delisted: list[str] | None = None) -> dict:
    selected, excluded = [], {}
    rows = {s["symbol"]: s for s in exchange_info.get("symbols", [])}
    for sym in (delisted or []):
        rows.setdefault(sym, {"symbol": sym, "contractType": "PERPETUAL", "quoteAsset": "USDT", "underlyingType": "COIN",
                              "baseAsset": sym[:-4] if sym.endswith("USDT") else sym, "_delisted": True})
    for sym, s in sorted(rows.items()):
        base = s.get("baseAsset", "")
        if s.get("contractType") != "PERPETUAL":
            excluded[sym] = "not_perpetual"
        elif s.get("quoteAsset") != "USDT":
            excluded[sym] = "quote_not_usdt"
        elif s.get("underlyingType", "COIN") != "COIN":
            excluded[sym] = f"underlying_{s.get('underlyingType')}"
        elif sym in C.EXCLUDE_ALREADY_USED:
            excluded[sym] = "already_used_in_experiments_001_003"
        elif base.upper() in C.STABLE_OR_PEGGED_BASES:
            excluded[sym] = "stable_or_pegged"
        else:
            selected.append(sym)
    n_del = sum(1 for s in selected if rows[s].get("_delisted"))
    return {"selected": selected, "excluded": excluded, "n_delisted_included": n_del,
            "survivorship_warning": None if n_del else "NO delisted symbols supplied: universe contains survivors only"}
