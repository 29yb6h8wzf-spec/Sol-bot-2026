"""Frozen configuration for Experiment 004. T4 rules are copied from Experiment 003 and must not change."""
WINDOW_START = "2024-11-01T00:00:00Z"
WINDOW_END = "2026-11-01T00:00:00Z"           # exclusive
EXCLUDE_ALREADY_USED = ("SOLUSDT", "XRPUSDT")
STABLE_OR_PEGGED_BASES = ("USDC", "FDUSD", "TUSD", "USDP", "BUSD", "DAI", "USDE", "USD1", "EUR", "AEUR", "XUSD")
PRICE_BAND = (0.99, 150.0)                    # applied to each trade's ENTRY price (causal, point in time), inclusive
LIQUIDITY = {"trailing_days": 30, "min_avg_daily_turnover_usdt": 20_000_000}   # trailing, ending before the entry bar
MIN_MONTHS_WITH_DATA = 6
COSTS = {"fee_per_side": 0.0005, "slippage_per_side": 0.0002}
SLIPPAGE_SENSITIVITY = (0.0005, 0.0010)       # reported only
T4 = {"agg_minutes": 240, "donchian_n": 20, "atr_n": 14, "stop_atr": 2.0, "target_atr": 4.0, "max_hold_agg_bars": 42}
DECISION = {"alpha_one_sided": 0.05, "min_trades": 300, "min_symbols_with_5_trades": 10}
BOOT = {"B": 10000, "seed": 20261111, "block_days": 7}
NULL = {"runs": 2000, "seed": 20261111}
BARS_PER_DAY = 288
