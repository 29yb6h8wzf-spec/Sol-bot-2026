"""Experiment 004 analysis. Frozen T4 rules + causal entry filters (price band, trailing liquidity). Single run, no tuning."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys

import numpy as np
import pandas as pd

from . import config as C
from .data import load_symbol

sys.path.insert(0, os.environ.get("EXP003_PATH", "/home/claude/exp003"))
sys.path.insert(0, os.environ.get("EXP001_PATH", "/home/claude/exp001"))
from exp003.strategies import aggregate, eligible_mask, signals                         # noqa: E402
from experiment_001.block_bootstrap import analyze                                         # noqa: E402
from experiment_001.costs import to_ns                                                     # noqa: E402
from experiment_001.engine_model import find_exit, fill_prices, levels_valid, r_components, zero_cost_gross   # noqa: E402
from experiment_001.metrics import clean, max_drawdown, profit_factor                       # noqa: E402
from experiment_001.null_model import run_conditional_null                                 # noqa: E402

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def entry_ok_mask(bars: pd.DataFrame, band=C.PRICE_BAND, liq=C.LIQUIDITY) -> np.ndarray:
    """Causal per-bar eligibility of an ENTRY at bar index e: open price inside the band and trailing turnover (bars before e) >= threshold."""
    o = bars["open"].to_numpy(float)
    ok = np.ones(len(o), bool)
    if band is not None:
        ok &= (o >= band[0]) & (o <= band[1])
    if liq is not None:
        w = liq["trailing_days"] * C.BARS_PER_DAY
        turn = bars["close"].to_numpy(float) * bars["volume"].to_numpy(float)
        cum = np.concatenate([[0.0], np.cumsum(turn)])
        e = np.arange(len(o))
        avg_daily = np.full(len(o), -1.0)
        has = e >= w
        avg_daily[has] = (cum[e[has]] - cum[e[has] - w]) / liq["trailing_days"]
        ok &= avg_daily >= liq["min_avg_daily_turnover_usdt"]
    return ok


def run_t4(bars: pd.DataFrame, fidx, costs: dict, symbol: str, entry_ok: np.ndarray | None = None, spec: dict = C.T4) -> pd.DataFrame:
    """Same loop as exp003.run_strategy plus `entry_ok` (a skipped signal does not occupy the timeline). Equivalence is tested."""
    n5 = len(bars)
    m = spec["agg_minutes"] // 5
    agg = aggregate(bars, spec["agg_minutes"])
    sg = signals(agg, spec["donchian_n"], spec["atr_n"])
    H5 = spec["max_hold_agg_bars"] * m
    o, h, l, c = (bars[k].to_numpy(float) for k in ("open", "high", "low", "close"))
    t_ns = to_ns(bars["time"])
    filled_cum = np.concatenate([[0], np.cumsum(bars["filled"].to_numpy(int))])
    fee, slip = costs["fee_per_side"], costs["slippage_per_side"]
    rows, next_free = [], -1
    for k in np.flatnonzero(sg["side"] != 0):
        e = (int(k) + 1) * m
        if e < next_free or e + H5 > n5:
            continue
        if filled_cum[e + H5] - filled_cum[e] > 0:
            continue
        if entry_ok is not None and not entry_ok[e]:
            continue
        side = int(sg["side"][k])
        ref, atr = sg["C"][k], sg["atr"][k]
        stop, target = ref - side * spec["stop_atr"] * atr, ref + side * spec["target_atr"] * atr
        if stop <= 0 or not bool(levels_valid(side, o[e] * (1 + side * slip), stop, target)):
            continue
        sl = slice(e, e + H5)
        reason, exit_ref, held = find_exit(side, o[sl], h[sl], l[sl], c[sl], stop, target)
        entry, exit_fill = fill_prices(side, o[e], exit_ref, slip)
        fund = float(fidx.sum_between(t_ns[e], t_ns[e + held - 1] + 300_000_000_000)) if fidx is not None else 0.0
        _, fee_r, fund_r, net, _ = r_components(side, entry, exit_fill, stop, fee, fund)
        rows.append(dict(symbol=symbol, strategy="T4", side=side, entry_open=o[e], stop=stop, target=target, exit_ref=exit_ref,
                         exit_reason=reason, held_bars=held, horizon_bars=H5, entry_time=bars["time"].iloc[e],
                         exit_time=bars["time"].iloc[e + held - 1], fee_rate_per_side=fee, slippage_rate_per_side=slip,
                         funding_rate_total=fund, r_gross=float(zero_cost_gross(side, o[e], exit_ref, stop, target)),
                         r_full=float(net), fee_r=float(fee_r), funding_r=float(fund_r), stop_dist_pct=abs(o[e] - stop) / o[e]))
        next_free = e + held
    return pd.DataFrame(rows)


def _summ(fp: pd.DataFrame) -> dict:
    if not len(fp):
        return {"n": 0}
    r = fp.sort_values("exit_time")
    return {"n": int(len(fp)), "gross": float(fp["r_gross"].mean()), "net": float(fp["r_full"].mean()),
            "win_rate": float((fp["r_gross"] > 0).mean()), "profit_factor_net": profit_factor(r["r_full"].to_numpy()),
            "max_drawdown_r_net": max_drawdown(r["r_full"].to_numpy()), "cost_per_trade_r": float((fp["r_gross"] - fp["r_full"]).mean()),
            "median_stop_pct": float(fp["stop_dist_pct"].median())}


def decide(n_trades, n_symbols_5, gross_lo, null_p, net_lo, rule=C.DECISION) -> dict:
    checks = {"n_trades": n_trades >= rule["min_trades"], "breadth": n_symbols_5 >= rule["min_symbols_with_5_trades"],
              "gross_lower_gt_0": gross_lo > 0, "null_p_lt_alpha": null_p < rule["alpha_one_sided"], "net_lower_gt_0": net_lo > 0}
    if not (checks["n_trades"] and checks["breadth"]):
        state = "INCONCLUSIVE_INSUFFICIENT"
    elif all(checks.values()):
        state = "REPLICATION_SUPPORTED"
    else:
        state = "REPLICATION_NOT_SUPPORTED"
    return {"state": state, "checks": checks}


def _verify_frozen():
    seal = open(os.path.join(ROOT, "REGISTRATION_SEAL.txt")).read().split()[1]
    r = subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "make_manifest.py"), "--verify"], capture_output=True, text=True)
    if r.returncode != 0 or seal not in r.stdout:
        raise SystemExit("ABORT: code/config/registration changed after the registration hash was recorded")
    return seal


def analyze_universe(symbol_data: dict, universe_info: dict | None = None, n_null: int = C.NULL["runs"], frozen_seal=None) -> tuple[dict, pd.DataFrame]:
    used, dropped, trades, masks, bars_map, fidx_map = [], {}, [], {}, {}, {}
    for sym, d in symbol_data.items():
        if "error" in d:
            dropped[sym] = d["error"]; continue
        if len(d["kline_months"]) < C.MIN_MONTHS_WITH_DATA:
            dropped[sym] = f"fewer_than_{C.MIN_MONTHS_WITH_DATA}_months"; continue
        if d["missing_funding_months"] or d["fidx"] is None:
            dropped[sym] = "missing_funding_months"; continue
        ok = entry_ok_mask(d["bars"])
        tr = run_t4(d["bars"], d["fidx"], C.COSTS, sym, ok)
        used.append(sym); bars_map[sym] = d["bars"]; fidx_map[sym] = d["fidx"]
        masks[sym] = eligible_mask(d["bars"], C.T4["max_hold_agg_bars"] * (C.T4["agg_minutes"] // 5)) & ok
        trades.append(tr)
    fp = pd.concat([t for t in trades if len(t)], ignore_index=True) if any(len(t) for t in trades) else pd.DataFrame()
    rep = {"experiment": "004", "frozen_manifest_root": frozen_seal, "window": [C.WINDOW_START, C.WINDOW_END],
           "universe": universe_info or {}, "symbols_used": used, "symbols_dropped": dropped, "pooled": _summ(fp)}
    if not len(fp):
        rep["decision"] = {"state": "INCONCLUSIVE_INSUFFICIENT", "checks": {}}
        return clean(rep), fp
    per = {s: _summ(g) for s, g in fp.groupby("symbol")}
    rep["per_symbol"] = per
    days = int((pd.Timestamp(C.WINDOW_END) - pd.Timestamp(C.WINDOW_START)).days)
    kw = dict(block_days=C.BOOT["block_days"], window_days=days, alpha_one_sided=C.DECISION["alpha_one_sided"], B=C.BOOT["B"], seed=C.BOOT["seed"])
    gci = analyze(fp["r_gross"].to_numpy(), fp["exit_time"], **kw)
    nci = analyze(fp["r_full"].to_numpy(), fp["exit_time"], **kw)
    first_entry = (max(C.T4["donchian_n"], C.T4["atr_n"]) + 1) * (C.T4["agg_minutes"] // 5)
    null, _ = run_conditional_null(fp, bars_map, fidx_map, n_runs=n_null, seed=C.NULL["seed"], stride=C.T4["agg_minutes"] // 5,
                                   first_entry=first_entry, horizon_bars=C.T4["max_hold_agg_bars"] * (C.T4["agg_minutes"] // 5), masks=masks)
    n5 = int(sum(1 for s in per.values() if s["n"] >= 5))
    rep.update(gross_ci=gci, net_ci=nci, null=null["ALL"], n_symbols_with_5_trades=n5)
    rep["decision"] = decide(len(fp), n5, gci["lo"], null["ALL"]["gross"]["p"], nci["lo"])
    # robustness (reported only)
    rob = {}
    syms = sorted(per)
    rob["leave_one_symbol_out"] = {s: _summ(fp[fp["symbol"] != s]) for s in syms}
    rob["equal_weight_symbol_mean_gross"] = float(np.mean([per[s]["gross"] for s in syms]))
    rob["equal_weight_symbol_mean_net"] = float(np.mean([per[s]["net"] for s in syms]))
    rob["share_symbols_positive_net"] = float(np.mean([per[s]["net"] > 0 for s in syms]))
    rob["long"], rob["short"] = _summ(fp[fp["side"] == 1]), _summ(fp[fp["side"] == -1])
    rob["by_quarter"] = {str(q): _summ(g) for q, g in fp.groupby(fp["exit_time"].dt.to_period("Q"))}
    sens = {}
    for slip in C.SLIPPAGE_SENSITIVITY:
        alt = pd.concat([run_t4(bars_map[s], fidx_map[s], dict(C.COSTS, slippage_per_side=slip), s, entry_ok_mask(bars_map[s])) for s in used], ignore_index=True)
        sens[str(slip)] = _summ(alt)
    rob["slippage_sensitivity"] = sens
    rep["robustness_reported_only"] = rob
    return clean(rep), fp


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--universe", required=True, help="JSON from universe.select_symbols")
    ap.add_argument("--out", default=os.path.join(ROOT, "results"))
    a = ap.parse_args(argv)
    seal = _verify_frozen()
    uni = json.load(open(a.universe))
    data = {s: load_symbol(s, a.data) for s in uni["selected"]}
    rep, fp = analyze_universe(data, {k: uni[k] for k in ("n_delisted_included", "survivorship_warning") if k in uni}, frozen_seal=seal)
    rep["registration_sha256"] = hashlib.sha256(open(os.path.join(ROOT, "PREREGISTRATION_Experiment_004.md"), "rb").read()).hexdigest()
    os.makedirs(a.out, exist_ok=True)
    json.dump(rep, open(os.path.join(a.out, "replication_report.json"), "w"), indent=1)
    fp.to_csv(os.path.join(a.out, "replication_trades.csv"), index=False)
    print(json.dumps({k: rep.get(k) for k in ("decision", "pooled", "n_symbols_with_5_trades", "symbols_dropped")}, indent=1))


if __name__ == "__main__":
    main()
