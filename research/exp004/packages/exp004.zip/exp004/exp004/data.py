from __future__ import annotations

import glob
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.environ.get("EXP001_PATH", "/home/claude/exp001"))
from experiment_001.costs import FundingIndex                      # noqa: E402
from experiment_001.run import load_klines                          # noqa: E402

from . import config as C                                           # noqa: E402


def load_symbol(symbol: str, data_dir: str) -> dict:
    """Whole 24-month window on a full 5m grid; bars before listing / in gaps are forward-filled and FLAGGED (never traded)."""
    k_files = sorted(glob.glob(os.path.join(data_dir, f"{symbol}-5m-*.zip")))
    f_files = sorted(glob.glob(os.path.join(data_dir, f"{symbol}-fundingRate-*.zip")))
    if not k_files:
        return {"error": "no_kline_files"}
    start, end = pd.Timestamp(C.WINDOW_START), pd.Timestamp(C.WINDOW_END)
    df = load_klines(k_files)
    df = df[(df["time"] >= start) & (df["time"] < end)]
    if df.empty:
        return {"error": "no_bars_in_window"}
    kmonths = {os.path.basename(p).split("-5m-")[1][:7] for p in k_files}
    fmonths = {os.path.basename(p).split("-fundingRate-")[1][:7] for p in f_files}
    full = pd.date_range(start, end - pd.Timedelta("5min"), freq="5min", tz="UTC")
    df = df.set_index("time").reindex(full)
    df["filled"] = df["close"].isna()
    df["close"] = df["close"].ffill().bfill()
    for c in ("open", "high", "low"):
        df[c] = df[c].fillna(df["close"])
    df["volume"] = df["volume"].fillna(0.0)
    df.index.name = "time"
    frames = []
    for p in f_files:
        x = pd.read_csv(p)
        frames.append(pd.DataFrame({"t": pd.to_datetime(x["calc_time"].astype("int64"), unit="ms", utc=True),
                                    "rate": x["last_funding_rate"].astype(float)}))
    f = pd.concat(frames).drop_duplicates("t").sort_values("t") if frames else pd.DataFrame({"t": [], "rate": []})
    return {"bars": df.reset_index(), "fidx": FundingIndex(f["t"], f["rate"]) if len(f) else None,
            "kline_months": sorted(kmonths), "funding_months": sorted(fmonths),
            "missing_funding_months": sorted(kmonths - fmonths)}
