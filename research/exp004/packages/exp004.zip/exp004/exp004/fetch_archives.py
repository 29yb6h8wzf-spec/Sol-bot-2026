"""Download official Binance public monthly archives (5m klines + fundingRate) for a symbol list.
Needs network. URL pattern follows data.binance.vision (futures/um/monthly); verify the pattern/CHECKSUM files in your environment.
Writes acquisition.json with SHA-256 of every file. Missing months are recorded, never invented."""
from __future__ import annotations

import hashlib
import json
import os
import sys
import urllib.error
import urllib.request

BASE = "https://data.binance.vision/data/futures/um/monthly"


def months(start="2024-11", end="2026-10"):
    y, m = map(int, start.split("-"))
    ey, em = map(int, end.split("-"))
    out = []
    while (y, m) <= (ey, em):
        out.append(f"{y}-{m:02d}")
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


def urls(symbol: str, month: str) -> dict:
    return {"5m": f"{BASE}/klines/{symbol}/5m/{symbol}-5m-{month}.zip",
            "fundingRate": f"{BASE}/fundingRate/{symbol}/{symbol}-fundingRate-{month}.zip"}


def _get(url: str) -> bytes | None:
    try:
        with urllib.request.urlopen(url, timeout=60) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None
        raise


def fetch(symbols, out_dir, start="2024-11", end="2026-10") -> dict:
    os.makedirs(out_dir, exist_ok=True)
    report = {"results": []}
    for sym in symbols:
        for mo in months(start, end):
            for kind, url in urls(sym, mo).items():
                path = os.path.join(out_dir, f"{sym}-{kind}-{mo}.zip")
                if os.path.exists(path):
                    status = "exists"
                else:
                    data = _get(url)
                    if data is None:
                        report["results"].append({"symbol": sym, "month": mo, "kind": kind, "status": "missing_404"})
                        continue
                    chk = _get(url + ".CHECKSUM")
                    sha = hashlib.sha256(data).hexdigest()
                    if chk is not None and chk.decode().split()[0].lower() != sha:
                        report["results"].append({"symbol": sym, "month": mo, "kind": kind, "status": "CHECKSUM_MISMATCH"})
                        continue
                    open(path, "wb").write(data)
                    status = "verified_download" if chk is not None else "downloaded_no_checksum"
                report["results"].append({"symbol": sym, "month": mo, "kind": kind, "status": status,
                                          "sha256": hashlib.sha256(open(path, "rb").read()).hexdigest()})
    json.dump(report, open(os.path.join(out_dir, "acquisition.json"), "w"), indent=1)
    return report


if __name__ == "__main__":
    syms = [s for s in sys.argv[2].split(",") if s]
    r = fetch(syms, sys.argv[1])
    bad = [x for x in r["results"] if x["status"] in ("missing_404", "CHECKSUM_MISMATCH")]
    print(len(r["results"]), "items;", len(bad), "missing/bad")
