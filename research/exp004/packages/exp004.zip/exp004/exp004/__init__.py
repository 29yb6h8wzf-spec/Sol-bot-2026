"""Experiment 004 - cross-sectional replication of the FROZEN T4 rules on other USDT-M perpetuals priced 0.99-150 USD."""
