Experiment 004 - run on a machine WITH network access (e.g. your EC2 instance). Needs: exp003 + experiment_001 (b1_b9) packages on EXP003_PATH / EXP001_PATH.
1. exchangeInfo:   curl -s https://fapi.binance.com/fapi/v1/exchangeInfo > exchangeInfo.json
2. delisted perpetuals (recommended): list them from the public archive directory listing into delisted.txt (one symbol per line)
3. python scripts/build_universe.py exchangeInfo.json delisted.txt > universe.json
4. python -c "import json;from exp004.fetch_archives import fetch;u=json.load(open('universe.json'));fetch(u['selected'],'data')"
   (check acquisition.json for missing_404 / CHECKSUM_MISMATCH; the URL pattern is unverified in the authoring sandbox)
5. python -m unittest discover -s tests && python scripts/make_manifest.py --verify     # must print VERIFIED
6. python -m exp004.replicate --data data --universe universe.json --out results       # ONE run; then send results/replication_report.json
Registration SHA-256: c7d1f1ead9524bb4e25f8349f61ddb618eb62bf52c977340f15a833718c08a8e   Frozen manifest root: 8755abd0f03357df8d7e804e13342324ea2ff1f99c810b504f211680c40249cf
Data size: roughly 0.35 MB per symbol-month (5m) -> about 170 MB for 20 symbols over 24 months.
