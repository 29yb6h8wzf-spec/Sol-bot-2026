# Pre-registration - Experiment 004: cross-sectional replication of the frozen T4 rules
Research / paper only. Nothing here authorizes live trading. Written and hashed BEFORE any T4 trade was computed on any new symbol.

## 1. Question and why this design
Experiment 003: T4 (4h Donchian-20 breakout, stop 2 ATR, target 4 ATR, 7-day max hold) advanced on SOL/XRP development data (n=278, gross +0.18R) but was NOT confirmed
on the SOL/XRP holdout (n=81, gross +0.135R, CI [-0.21, +0.71], null p 0.287). The holdout is consumed. This experiment asks whether the SAME frozen rules show a
gross edge on other perpetuals. New symbols have never been evaluated with T4, so no selection bias attaches to them. The sample is NOT independent in time: it covers the same
months and crypto assets are correlated with SOL/XRP. It can show breadth across coins; it cannot show out-of-time validity.

## 2. Universe (rule fixed here, applied mechanically)
Source: exchangeInfo snapshot supplied by the owner (+ a list of delisted perpetuals from the public archive, strongly recommended; without it the report prints a survivorship warning).
Keep: contractType PERPETUAL, quote USDT, underlyingType COIN. Exclude: SOLUSDT and XRPUSDT (already used), stable/pegged bases (USDC, FDUSD, TUSD, USDP, BUSD, DAI, USDE, USD1, EUR, AEUR, XUSD).
Price band (owner's requirement 0.99-150 USD): applied to each trade's ENTRY open price, inclusive (point-in-time, causal) - a coin may trade inside the band in some months only.
Liquidity (my addition, NOT tuned, an assumption): trailing 30-day average daily turnover (close x volume, USDT) of the bars before the entry bar >= 20,000,000; the first 30 days after a listing are ineligible.
Data: official monthly 5m klines and fundingRate archives, 2024-11 .. 2026-10. A symbol needs >= 6 months of klines and funding files for EVERY kline month, else it is dropped (reported, never imputed).
Gaps and pre-listing bars are forward-filled, flagged, and can never be touched by a signal or a hold window.

## 3. Frozen strategy and costs
T4 exactly as in Experiment 003 (a test asserts the parameters are identical): signal on a closed UTC-aligned 4h bar, close > highest high of the previous 20 bars (long) or < lowest low (short),
ATR(14) simple mean, stop = close -/+ 2 ATR, target = close +/- 4 ATR, entry at the next 5m open, max hold 42 4h bars, engine accounting (stop-first on the same 5m bar, gap-through stop fills),
one position per symbol, no overlap; a signal skipped by an entry filter does not occupy the timeline. Costs: fee 5 bp/side, slippage 2 bp/side, historical funding for the actual hold.
No parameter, rule or filter may change after the first real-data run. Only T4 is evaluated (no T1, no variants).

## 4. Primary test (single run, single hypothesis)
Pooled over all eligible trades of all used symbols. Weekly (7-day, Monday-aligned) blocks synchronized across all symbols, studentized bootstrap B=10,000, seed 20261111,
one-sided alpha 0.05 (interval level 0.90). Conditional random-entry null: 2,000 runs, same grid, per-symbol overlap, week strata, gap/price/liquidity-masked grid.
REPLICATION_SUPPORTED iff all hold (strict): trades >= 300; >= 10 symbols with >= 5 trades; gross lower bound > 0; null p < 0.05; net lower bound > 0.
Otherwise REPLICATION_NOT_SUPPORTED, except INCONCLUSIVE_INSUFFICIENT when trades < 300 or breadth < 10 symbols.

## 5. Reported only (never used to choose or rescue)
Per symbol; leave-one-symbol-out; equal-weight symbol mean; share of symbols with positive net; long vs short; by quarter; slippage 5 bp and 10 bp; survivorship status; dropped symbols and why.
Concentration warning: if the pooled result disappears when one symbol is left out, the claim is "not robust", whatever the state.

## 6. Consequences (fixed in advance)
REPLICATION_NOT_SUPPORTED or INCONCLUSIVE: T4 is retired; no further variants on this data. REPLICATION_SUPPORTED: T4 gets a NEW pre-registration for forward paper trading
(from 2026-12-01 on Binance Demo with a fresh decision rule). Even then there is no live-trading authorization; the owner's stated willingness to risk money is noted and is not a basis.

## 7. Known limits
Survivorship (current-list bias) unless delisted symbols are supplied; correlated assets reduce the effective sample (pooled n overstates independent evidence); 2 bp slippage is optimistic for smaller coins
(sensitivity reported); liquidity filter is an unvalidated assumption; one regime sequence; backtests ignore latency, depth, API limits and outages. I am not a financial advisor.
