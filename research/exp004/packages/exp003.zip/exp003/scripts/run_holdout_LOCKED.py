"""LOCKED. Do not run. Requires (1) the owner's explicit go-ahead, (2) the unlock token = registration sha256, and
(3) a single pre-registered run for the strategies listed in results/dev_report.json['advance_to_holdout']."""
import sys
raise SystemExit("holdout is locked: owner go-ahead + unlock token required (see PREREGISTRATION_Experiment_003.md section 6)")
