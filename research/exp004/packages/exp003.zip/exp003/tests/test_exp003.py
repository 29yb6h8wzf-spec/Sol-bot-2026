import os
import unittest

import numpy as np
import pandas as pd

from exp003 import config as C
from exp003.carry import hold_flags, simulate_carry
from exp003.data import load_bars
from exp003.screen import screen
from exp003.strategies import aggregate, eligible_mask, run_strategy, signals

SPEC4 = C.TREND["T4"]
COSTS = C.COSTS


def flat_then_break(n_agg=60, base=100.0, break_at=30, rise=0.04, m=48, seed=1):
    """4h bars: tight flat range with small noise, then a sustained up move starting at agg bar `break_at`."""
    rng = np.random.default_rng(seed)
    n = n_agg * m
    price = np.full(n, base) + rng.normal(0, 0.02, n)
    for i in range(break_at * m, n):
        price[i] = base * (1 + rise * (i - break_at * m) / (m * 6)) + rng.normal(0, 0.02)
    o = np.concatenate([[base], price[:-1]])
    h = np.maximum(o, price) + 0.03
    l = np.minimum(o, price) - 0.03
    return pd.DataFrame({"time": pd.date_range("2025-01-01", periods=n, freq="5min", tz="UTC"), "open": o, "high": h,
                         "low": l, "close": price, "volume": 1.0, "filled": False})


class Signals(unittest.TestCase):
    def test_breakout_long_signal_and_entry_index(self):
        df = flat_then_break()
        sg = signals(aggregate(df, 240), 20, 14)
        ks = np.flatnonzero(sg["side"] == 1)
        self.assertGreater(len(ks), 0)
        self.assertGreaterEqual(ks[0], 30)                       # nothing before the breakout
        self.assertEqual(np.flatnonzero(sg["side"] == -1).size, 0)

    def test_no_lookahead_future_bars_do_not_change_past_signals(self):
        df = flat_then_break()
        a = signals(aggregate(df, 240), 20, 14)["side"]
        df2 = df.copy()
        cut = 45 * 48                                            # corrupt everything from agg bar 45 on
        df2.loc[cut:, ["open", "high", "low", "close"]] = 500.0
        b = signals(aggregate(df2, 240), 20, 14)["side"]
        np.testing.assert_array_equal(a[:45], b[:45])

    def test_filled_bars_block_signals_in_their_window(self):
        df = flat_then_break()
        df.loc[28 * 48 + 5, "filled"] = True
        sg = signals(aggregate(df, 240), 20, 14)["side"]
        self.assertTrue((sg[28:28 + 21] == 0).all())             # span = max(N, atr_n) + 1


class Trades(unittest.TestCase):
    def test_target_trade_gross_is_about_2R_and_costs_identity(self):
        df = flat_then_break(rise=0.20, n_agg=80)
        tr = run_strategy(df, "T4", SPEC4, None, COSTS, symbol="SOLUSDT")
        self.assertGreater(len(tr), 0)
        first = tr.iloc[0]
        self.assertEqual(first.exit_reason, "TARGET")
        self.assertAlmostEqual(first.r_gross, 2.0, delta=0.15)
        self.assertLess(first.r_full, first.r_gross)
        self.assertAlmostEqual(first.r_gross - first.r_full, first.fee_r + (first.r_gross - first.r_full - first.fee_r), places=12)

    def test_non_overlap_and_horizon_inside_data(self):
        df = flat_then_break(rise=0.05, n_agg=120)
        tr = run_strategy(df, "T4", SPEC4, None, COSTS, symbol="SOLUSDT")
        ends = tr["exit_time"].to_numpy()
        starts = tr["entry_time"].to_numpy()
        self.assertTrue((starts[1:] > ends[:-1]).all())
        self.assertTrue((tr["exit_time"] <= df["time"].iloc[-1]).all())

    def test_entry_start_idx_respected(self):
        df = flat_then_break(rise=0.20, n_agg=80)
        df = flat_then_break(rise=0.20, n_agg=160)
        late = run_strategy(df, "T4", SPEC4, None, COSTS, symbol="SOLUSDT", entry_start_idx=60 * 48)
        self.assertGreater(len(late), 0)
        self.assertTrue((late["entry_time"] >= df["time"].iloc[60 * 48]).all())

    def test_gap_inside_hold_window_skips_trade(self):
        df = flat_then_break(rise=0.20, n_agg=80)
        clean = run_strategy(df, "T4", SPEC4, None, COSTS, symbol="SOLUSDT")
        g = df.copy()
        i0 = int(df.index[df.time == clean.iloc[0].entry_time][0])
        g.loc[i0 + 10, "filled"] = True
        trg = run_strategy(g, "T4", SPEC4, None, COSTS, symbol="SOLUSDT")
        self.assertNotIn(clean.iloc[0].entry_time, set(trg["entry_time"]) if len(trg) else set())
        mask = eligible_mask(g, SPEC4["max_hold_agg_bars"] * 48)
        self.assertFalse(mask[i0])


class Lock(unittest.TestCase):
    def test_holdout_requires_token(self):
        with self.assertRaises(PermissionError):
            load_bars("SOLUSDT", "holdout")

    @unittest.skipUnless(os.path.isdir(os.environ.get("EXP003_DATA", "/home/claude/exp003/data")), "no data")
    def test_dev_loader_never_returns_holdout_bars(self):
        d = load_bars("SOLUSDT", "dev")
        self.assertLess(d["time"].max(), pd.Timestamp(C.DEV_END))
        self.assertEqual(d["time"].iloc[0], pd.Timestamp(C.DEV_START))
        self.assertEqual(len(d), (pd.Timestamp(C.DEV_END) - pd.Timestamp(C.DEV_START)) // pd.Timedelta("5min"))


def funding_df(rates, start="2025-01-01"):
    t = pd.date_range(start, periods=len(rates), freq="8h", tz="UTC")
    return pd.DataFrame({"t": t, "rate": rates})


class Carry(unittest.TestCase):
    P = C.CARRY

    def test_constant_funding_earns_income_minus_one_entry_cost(self):
        f = funding_df([0.0001] * 300)
        r = simulate_carry(f, self.P)
        cost_per_switch = 0.001 + 0.0005 + 2 * 0.0002
        held = 300 - 9
        self.assertEqual(r["n_switches"], 1)
        self.assertAlmostEqual(r["gross_income_on_notional"], 0.0001 * held, places=12)
        self.assertAlmostEqual(r["costs_on_notional"], cost_per_switch, places=12)

    def test_no_lookahead_decision_ignores_the_current_and_future_payments(self):
        base = np.array([0.0001] * 40)
        spiky = base.copy(); spiky[20] = -0.05
        a, b = hold_flags(base, self.P), hold_flags(spiky, self.P)
        np.testing.assert_array_equal(a[:21], b[:21])            # hold[20] cannot depend on payment 20
        self.assertNotEqual(a[21:].tolist(), b[21:].tolist())    # but later decisions do see it

    def test_exits_when_trailing_mean_turns_negative(self):
        f = funding_df([0.0001] * 40 + [-0.0003] * 30 + [0.0001] * 40)
        r = simulate_carry(f, self.P)
        self.assertGreaterEqual(r["n_switches"], 3)
        self.assertGreater(r["share_negative_payments"], 0.2)

    def test_always_negative_never_enters(self):
        r = simulate_carry(funding_df([-0.0001] * 100), self.P)
        self.assertEqual((r["n_switches"], r["held_share"]), (0, 0.0))


class Screen(unittest.TestCase):
    R = C.SCREEN

    def test_boundaries_are_strict(self):
        self.assertTrue(screen(60, 0.01, 0.01, 0.09, self.R)["advance"])
        self.assertFalse(screen(59, 0.01, 0.01, 0.09, self.R)["advance"])
        self.assertFalse(screen(60, 0.0, 0.01, 0.09, self.R)["advance"])
        self.assertFalse(screen(60, 0.01, 0.0, 0.09, self.R)["advance"])
        self.assertFalse(screen(60, 0.01, 0.01, 0.10, self.R)["advance"])


if __name__ == "__main__":
    unittest.main()
