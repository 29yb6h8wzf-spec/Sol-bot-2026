"""Loading with a PHYSICAL lock: the dev loader never reads a bar at or after DEV_END."""
from __future__ import annotations

import glob
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.environ.get("EXP001_PATH", "/home/claude/exp001"))
from experiment_001.costs import FundingIndex                      # noqa: E402
from experiment_001.run import load_klines, load_funding           # noqa: E402

from . import config as C                                           # noqa: E402

DATA_DIR = os.environ.get("EXP003_DATA", "/home/claude/exp003/data")


def _ts(s):
    return pd.Timestamp(s)


def load_bars(symbol: str, window: str, unlock_token: str | None = None, data_dir: str | None = None) -> pd.DataFrame:
    """window 'dev': bars in [DEV_START, DEV_END). window 'holdout': bars in [HOLDOUT_START - lookback, HOLDOUT_END) and ONLY
    with the unlock token (registration hash recorded in HOLDOUT_UNLOCK.txt)."""
    d = data_dir or DATA_DIR
    if window == "dev":
        start, end = _ts(C.DEV_START), _ts(C.DEV_END)
    elif window == "holdout":
        if not unlock_token:
            raise PermissionError("holdout is locked: supply the unlock token (registration hash) after the owner's go-ahead")
        start, end = _ts(C.HOLDOUT_START) - pd.Timedelta(days=C.HOLDOUT_LOOKBACK_DAYS), _ts(C.HOLDOUT_END)
    else:
        raise ValueError("window must be 'dev' or 'holdout'")
    files = sorted(glob.glob(os.path.join(d, f"{symbol}-5m-*.zip")))
    df = load_klines(files)
    df = df[(df["time"] >= start) & (df["time"] < end)].reset_index(drop=True)
    full = pd.date_range(start, end - pd.Timedelta("5min"), freq="5min", tz="UTC")
    df = df.set_index("time").reindex(full)
    df["filled"] = df["close"].isna()
    df["close"] = df["close"].ffill().bfill()
    for c in ("open", "high", "low"):
        df[c] = df[c].fillna(df["close"])
    df["volume"] = df["volume"].fillna(0.0)
    df.index.name = "time"
    return df.reset_index()


def load_funding_index(symbol: str, window: str, data_dir: str | None = None) -> tuple[FundingIndex, pd.DataFrame]:
    d = data_dir or DATA_DIR
    files = sorted(glob.glob(os.path.join(d, f"{symbol}-fundingRate-*.zip")))
    frames = []
    for p in files:
        x = pd.read_csv(p)
        frames.append(pd.DataFrame({"t": pd.to_datetime(x["calc_time"].astype("int64"), unit="ms", utc=True),
                                    "rate": x["last_funding_rate"].astype(float)}))
    f = pd.concat(frames).drop_duplicates("t").sort_values("t").reset_index(drop=True)
    if window == "dev":
        f = f[f["t"] < _ts(C.DEV_END)]
    return FundingIndex(f["t"], f["rate"]), f
