"""Experiment 003 - DEVELOPMENT window only (2024-11-01 .. 2026-04-30). The holdout is physically not loaded."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time

import numpy as np
import pandas as pd

from . import config as C
from .carry import simulate_carry
from .data import load_bars, load_funding_index
from .screen import screen
from .strategies import eligible_mask, run_strategy

sys.path.insert(0, os.environ.get("EXP001_PATH", "/home/claude/exp001"))
from experiment_001.block_bootstrap import analyze                      # noqa: E402
from experiment_001.metrics import clean, max_drawdown, profit_factor    # noqa: E402
from experiment_001.null_model import run_conditional_null              # noqa: E402

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))


def _verify_frozen():
    seal = open(os.path.join(ROOT, "REGISTRATION_SEAL.txt")).read().split()[1]
    r = subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "make_manifest.py"), "--verify"], capture_output=True, text=True)
    if r.returncode != 0 or seal not in r.stdout:
        raise SystemExit("ABORT: code/config/registration changed after the registration hash was recorded")
    return seal


def stats(fp: pd.DataFrame, window_days: int) -> dict:
    out = {"n": int(len(fp))}
    if not len(fp):
        return out
    for name, col in (("gross", "r_gross"), ("net", "r_full")):
        r = fp.sort_values("exit_time")[col].to_numpy()
        out[name] = {"expectancy_r": float(r.mean()), "total_r": float(r.sum()), "win_rate": float((r > 0).mean()),
                     "profit_factor": profit_factor(r), "max_drawdown_r": max_drawdown(r)}
    out["cost_per_trade_r"] = float((fp["r_gross"] - fp["r_full"]).mean())
    out["median_stop_pct"] = float(fp["stop_dist_pct"].median())
    out["exit_reasons"] = fp["exit_reason"].value_counts().to_dict()
    out["by_symbol"] = {s: {"n": int(len(g)), "gross": float(g["r_gross"].mean()), "net": float(g["r_full"].mean())}
                        for s, g in fp.groupby("symbol")}
    mon = fp.groupby(fp["exit_time"].dt.strftime("%Y-%m"))
    out["monthly_net_r"] = {k: float(v["r_full"].sum()) for k, v in mon}
    return out


def main():
    t0 = time.time()
    seal = _verify_frozen()
    prereg_hash = hashlib.sha256(open(os.path.join(ROOT, "PREREGISTRATION_Experiment_003.md"), "rb").read()).hexdigest()
    bars, fidx, fdf = {}, {}, {}
    for s in C.SYMBOLS:
        bars[s] = load_bars(s, "dev")
        fidx[s], fdf[s] = load_funding_index(s, "dev")
        assert bars[s]["time"].max() < pd.Timestamp(C.DEV_END)
    window_days = int((pd.Timestamp(C.DEV_END) - pd.Timestamp(C.DEV_START)).days)
    report = {"experiment": "003-dev", "registration_sha256": prereg_hash, "frozen_manifest_root": seal,
              "window": [C.DEV_START, C.DEV_END], "holdout_loaded": False,
              "data_quality": {s: {"filled_5m_bars": int(bars[s]["filled"].sum()), "bars": int(len(bars[s]))} for s in C.SYMBOLS},
              "trend": {}, "carry": {}}
    for name, spec in C.TREND.items():
        m = spec["agg_minutes"] // 5
        H5 = spec["max_hold_agg_bars"] * m
        frames = [run_strategy(bars[s], name, spec, fidx[s], C.COSTS, symbol=s) for s in C.SYMBOLS]
        fp = pd.concat(frames, ignore_index=True)
        st = stats(fp, window_days)
        entry = {"spec": spec, "stats": st}
        if len(fp) >= 3:
            gci = analyze(fp["r_gross"].to_numpy(), fp["exit_time"], block_days=C.BOOT["block_days"], window_days=window_days,
                          alpha_one_sided=C.SCREEN["gross_ci_alpha_one_sided"], B=C.BOOT["B"], seed=C.BOOT["seed"])
            nci = analyze(fp["r_full"].to_numpy(), fp["exit_time"], block_days=C.BOOT["block_days"], window_days=window_days,
                          alpha_one_sided=C.SCREEN["gross_ci_alpha_one_sided"], B=C.BOOT["B"], seed=C.BOOT["seed"])
            first_entry = (max(spec["donchian_n"], spec["atr_n"]) + 1) * m
            null, _ = run_conditional_null(fp, {s: bars[s] for s in C.SYMBOLS}, fidx, n_runs=C.NULL["runs"], seed=C.NULL["seed"],
                                           stride=m, first_entry=first_entry, horizon_bars=H5,
                                           masks={s: eligible_mask(bars[s], H5) for s in C.SYMBOLS})
            entry.update(gross_ci=gci, net_ci=nci, null=null["ALL"])
            entry["screen"] = screen(st["n"], st["net"]["expectancy_r"], gci["lo"], null["ALL"]["gross"]["p"], C.SCREEN)
        else:
            entry["screen"] = {"advance": False, "checks": {"min_trades": False}, "note": "too few trades"}
        rob = {}
        for N in C.ROBUSTNESS_DONCHIAN[name]:
            f2 = pd.concat([run_strategy(bars[s], name, spec, fidx[s], C.COSTS, symbol=s, donchian_n=N) for s in C.SYMBOLS], ignore_index=True)
            rob[str(N)] = {"n": int(len(f2)), "gross": float(f2["r_gross"].mean()) if len(f2) else None,
                           "net": float(f2["r_full"].mean()) if len(f2) else None}
        entry["robustness_reported_only"] = rob
        report["trend"][name] = entry
        fp.to_csv(os.path.join(ROOT, "results", f"dev_trades_{name}.csv"), index=False)
    # carry
    per = {s: simulate_carry(fdf[s], C.CARRY) for s in C.SYMBOLS}
    always = dict(C.CARRY, enter_trailing_mean_ge=-1.0, exit_trailing_mean_lt=-1.0)
    per_always = {s: simulate_carry(fdf[s], always) for s in C.SYMBOLS}
    pooled_yield = float(np.mean([per[s]["net_annualized_on_capital"] for s in C.SYMBOLS]))
    pooled_pos = float(np.mean([per[s]["share_positive_months"] for s in C.SYMBOLS]))
    report["carry"] = {"per_symbol": per, "always_on_descriptive": {s: {k: v for k, v in per_always[s].items() if k != "monthly"} for s in C.SYMBOLS},
                       "pooled_net_annualized_on_capital": pooled_yield, "pooled_share_positive_months": pooled_pos,
                       "usd_per_year_on_capital": pooled_yield * C.CARRY["capital_usd"],
                       "advance": bool(pooled_yield >= C.CARRY["min_net_annual_yield_on_capital"] and
                                       pooled_pos >= C.CARRY["min_share_positive_months"]),
                       "caveat": "upper bound: basis risk, margin, borrow and transfer frictions not modeled"}
    report["seconds"] = round(time.time() - t0)
    report["advance_to_holdout"] = [k for k, v in report["trend"].items() if v["screen"]["advance"]] + \
                                   (["CARRY"] if report["carry"]["advance"] else [])
    with open(os.path.join(ROOT, "results", "dev_report.json"), "w") as fh:
        json.dump(clean(report), fh, indent=1)
    print(json.dumps(clean({"advance_to_holdout": report["advance_to_holdout"],
                            "trend": {k: {"n": v["stats"]["n"], "gross": v["stats"].get("gross", {}).get("expectancy_r"),
                                          "net": v["stats"].get("net", {}).get("expectancy_r"),
                                          "gross_lo": v.get("gross_ci", {}).get("lo"), "null_p": v.get("null", {}).get("gross", {}).get("p"),
                                          "screen": v["screen"]} for k, v in report["trend"].items()},
                            "carry": {k: report["carry"][k] for k in ("pooled_net_annualized_on_capital", "pooled_share_positive_months", "usd_per_year_on_capital", "advance")}}), indent=1))


if __name__ == "__main__":
    main()
