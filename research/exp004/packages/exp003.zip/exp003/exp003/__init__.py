"""Experiment 003 - new strategy families (higher-timeframe trend, funding carry). Research / paper only."""
