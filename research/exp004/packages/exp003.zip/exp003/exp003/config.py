"""Frozen configuration for Experiment 003 (part of the seal manifest). No values are tuned on any data."""
DEV_START = "2024-11-01T00:00:00Z"
DEV_END = "2026-05-01T00:00:00Z"          # exclusive; holdout starts here
HOLDOUT_START = "2026-05-01T00:00:00Z"
HOLDOUT_END = "2026-11-01T00:00:00Z"      # exclusive
HOLDOUT_LOOKBACK_DAYS = 30                # lookback bars only; no entries before HOLDOUT_START
SYMBOLS = ("SOLUSDT", "XRPUSDT")

COSTS = {"fee_per_side": 0.0005, "slippage_per_side": 0.0002}          # perp taker scenario, as Experiment 002

# trend strategies (signal on closed aggregated bar, entry at the next 5m open)
TREND = {
    "T4": {"agg_minutes": 240, "donchian_n": 20, "atr_n": 14, "stop_atr": 2.0, "target_atr": 4.0, "max_hold_agg_bars": 42},
    "T1": {"agg_minutes": 60, "donchian_n": 48, "atr_n": 14, "stop_atr": 2.0, "target_atr": 4.0, "max_hold_agg_bars": 72},
}
ROBUSTNESS_DONCHIAN = {"T4": (10, 20, 40), "T1": (24, 48, 96)}          # reported only, never used to select

# dev screening rule (all must hold to advance a strategy to the one-time holdout run)
SCREEN = {"min_trades": 60, "net_expectancy_gt": 0.0, "gross_ci_alpha_one_sided": 0.05, "gross_ci_lower_gt": 0.0, "null_p_lt": 0.10}
BOOT = {"B": 10000, "seed": 20261111, "block_days": 7}
NULL = {"runs": 2000, "seed": 20261111}
HOLDOUT_ALPHA_TOTAL = 0.05                                               # split over strategies that advance

# funding carry: delta-neutral long spot + short perp; upper-bound estimate (basis risk not modeled)
CARRY = {"enter_trailing_mean_ge": 0.00008, "exit_trailing_mean_lt": 0.00002, "trailing_payments": 9,
         "spot_fee": 0.001, "perp_fee": 0.0005, "slippage_per_leg": 0.0002, "perp_leverage": 3.0,
         "min_net_annual_yield_on_capital": 0.05, "min_share_positive_months": 0.75, "capital_usd": 150.0}
