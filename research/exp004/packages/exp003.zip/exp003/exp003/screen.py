"""Dev screening rule (frozen in config.SCREEN). A strategy advances to the one-time holdout only if ALL checks hold (strict)."""
from __future__ import annotations


def screen(n_trades: int, net_mean: float, gross_ci_lower: float, null_p_gross: float, rule: dict) -> dict:
    checks = {"min_trades": n_trades >= rule["min_trades"],
              "net_expectancy_positive": net_mean > rule["net_expectancy_gt"],
              "gross_ci_lower_positive": gross_ci_lower > rule["gross_ci_lower_gt"],
              "null_p_below_cutoff": null_p_gross < rule["null_p_lt"]}
    return {"advance": all(checks.values()), "checks": checks}
