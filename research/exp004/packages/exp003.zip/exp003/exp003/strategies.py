"""Higher-timeframe Donchian breakout (T4: 4h, T1: 1h). Signal on a CLOSED aggregated bar; entry at the next 5m open;
stop/target are fixed references from the signal bar close and ATR; engine accounting (stop-first, gap-through stop fill)."""
from __future__ import annotations

import sys
import os

import numpy as np
import pandas as pd

sys.path.insert(0, os.environ.get("EXP001_PATH", "/home/claude/exp001"))
from experiment_001.engine_model import find_exit, fill_prices, levels_valid, r_components, zero_cost_gross  # noqa: E402
from experiment_001.costs import to_ns                                                                    # noqa: E402


def aggregate(df5: pd.DataFrame, minutes: int) -> dict:
    m = minutes // 5
    n = (len(df5) // m) * m
    o, h, l, c = (df5[k].to_numpy(float)[:n].reshape(-1, m) for k in ("open", "high", "low", "close"))
    bad = df5["filled"].to_numpy(bool)[:n].reshape(-1, m).any(axis=1)
    return {"O": o[:, 0], "H": h.max(axis=1), "L": l.min(axis=1), "C": c[:, -1], "bad": bad, "m": m}


def signals(agg: dict, donchian_n: int, atr_n: int) -> dict:
    H, L, C, bad = agg["H"], agg["L"], agg["C"], agg["bad"]
    hh = pd.Series(H).shift(1).rolling(donchian_n).max().to_numpy()
    ll = pd.Series(L).shift(1).rolling(donchian_n).min().to_numpy()
    prev_c = np.concatenate([[np.nan], C[:-1]])
    tr = np.maximum.reduce([H - L, np.abs(H - prev_c), np.abs(L - prev_c)])
    atr = pd.Series(tr).rolling(atr_n).mean().to_numpy()
    span = max(donchian_n, atr_n) + 1
    bad_roll = pd.Series(bad.astype(float)).rolling(span).sum().to_numpy() > 0
    side = np.where(C > hh, 1, np.where(C < ll, -1, 0))
    side = np.where(np.isnan(hh) | np.isnan(ll) | np.isnan(atr) | bad_roll | (atr <= 0), 0, side)
    return {"side": side, "atr": atr, "C": C}


def run_strategy(df5: pd.DataFrame, name: str, spec: dict, fidx, costs: dict, *, symbol: str, entry_start_idx: int = 0,
                 donchian_n: int | None = None) -> pd.DataFrame:
    n5 = len(df5)
    m = spec["agg_minutes"] // 5
    N = donchian_n or spec["donchian_n"]
    agg = aggregate(df5, spec["agg_minutes"])
    sg = signals(agg, N, spec["atr_n"])
    H5 = spec["max_hold_agg_bars"] * m
    o, h, l, c = (df5[k].to_numpy(float) for k in ("open", "high", "low", "close"))
    t_ns = to_ns(df5["time"])
    filled_cum = np.concatenate([[0], np.cumsum(df5["filled"].to_numpy(int))])
    fee, slip = costs["fee_per_side"], costs["slippage_per_side"]
    rows, next_free = [], -1
    for k in np.flatnonzero(sg["side"] != 0):
        e = (int(k) + 1) * m
        if e < entry_start_idx or e < next_free or e + H5 > n5:
            continue
        if filled_cum[e + H5] - filled_cum[e] > 0:
            continue
        side = int(sg["side"][k])
        ref, atr = sg["C"][k], sg["atr"][k]
        stop, target = ref - side * spec["stop_atr"] * atr, ref + side * spec["target_atr"] * atr
        if stop <= 0 or not bool(levels_valid(side, o[e] * (1 + side * slip), stop, target)):
            continue
        sl = slice(e, e + H5)
        reason, exit_ref, held = find_exit(side, o[sl], h[sl], l[sl], c[sl], stop, target)
        entry, exit_fill = fill_prices(side, o[e], exit_ref, slip)
        t1 = t_ns[e + held - 1] + 300_000_000_000
        fund = float(fidx.sum_between(t_ns[e], t1)) if fidx is not None else 0.0
        _, fee_r, fund_r, net, _ = r_components(side, entry, exit_fill, stop, fee, fund)
        rows.append(dict(symbol=symbol, strategy=name, side=side, entry_open=o[e], stop=stop, target=target, exit_ref=exit_ref,
                         exit_reason=reason, held_bars=held, horizon_bars=H5, entry_time=df5["time"].iloc[e],
                         exit_time=df5["time"].iloc[e + held - 1], fee_rate_per_side=fee, slippage_rate_per_side=slip,
                         funding_rate_total=fund, r_gross=float(zero_cost_gross(side, o[e], exit_ref, stop, target)),
                         r_full=float(net), fee_r=float(fee_r), funding_r=float(fund_r),
                         stop_dist_pct=abs(o[e] - stop) / o[e]))
        next_free = e + held
    return pd.DataFrame(rows)


def eligible_mask(df5: pd.DataFrame, horizon: int) -> np.ndarray:
    """Entry bars whose full hold window contains no gap-filled bar (used by the null)."""
    cum = np.concatenate([[0], np.cumsum(df5["filled"].to_numpy(int))])
    n = len(df5)
    ok = np.zeros(n, bool)
    idx = np.arange(0, n - horizon + 1)
    ok[idx] = (cum[idx + horizon] - cum[idx]) == 0
    return ok
