"""Funding carry (long spot + short perp). Income from historical funding payments only; costs per switch.
UPPER-BOUND estimate: spot/perp basis moves, margin calls, borrow and transfer frictions are NOT modeled.
Decision before payment i uses payments < i only (no look-ahead)."""
from __future__ import annotations

import numpy as np
import pandas as pd


def hold_flags(r: np.ndarray, p: dict) -> np.ndarray:
    """hold[i] = position held for payment i, decided from payments strictly before i."""
    k = p["trailing_payments"]
    hold = np.zeros(len(r), bool)
    state = False
    for i in range(len(r)):
        if i >= k:
            tm = r[i - k:i].mean()
            if not state and tm >= p["enter_trailing_mean_ge"]:
                state = True
            elif state and tm < p["exit_trailing_mean_lt"]:
                state = False
        hold[i] = state
    return hold


def simulate_carry(f: pd.DataFrame, p: dict, start=None, end=None) -> dict:
    f = f.sort_values("t").reset_index(drop=True)
    r = f["rate"].to_numpy(float)
    hold = hold_flags(r, p)
    switch_cost = p["spot_fee"] + p["perp_fee"] + 2 * p["slippage_per_leg"]      # per entry (and per exit), on notional
    switches = np.abs(np.diff(np.concatenate([[False], hold]).astype(int)))
    income = np.where(hold, r, 0.0)
    cost = switches * switch_cost
    net = income - cost
    cap_factor = 1.0 + 1.0 / p["perp_leverage"]                                     # capital per unit of notional
    df = pd.DataFrame({"t": f["t"], "month": f["t"].dt.strftime("%Y-%m"), "income": income, "cost": cost, "net": net, "hold": hold})
    mon = df.groupby("month").agg(income=("income", "sum"), cost=("cost", "sum"), net=("net", "sum"), held_share=("hold", "mean"))
    mon["net_on_capital"] = mon["net"] / cap_factor
    days = (df["t"].iloc[-1] - df["t"].iloc[0]).total_seconds() / 86400 + 1 / 3
    total_net_on_cap = df["net"].sum() / cap_factor
    return {"n_payments": int(len(r)), "held_share": float(hold.mean()), "n_switches": int(switches.sum()),
            "gross_income_on_notional": float(income.sum()), "costs_on_notional": float(cost.sum()),
            "net_annualized_on_capital": float(total_net_on_cap * 365 / days),
            "share_positive_months": float((mon["net"] > 0).mean()), "months": int(len(mon)),
            "mean_funding_rate_per_payment": float(r.mean()), "share_negative_payments": float((r < 0).mean()),
            "monthly": {k_: {c: float(v) for c, v in row.items()} for k_, row in mon.iterrows()}}
