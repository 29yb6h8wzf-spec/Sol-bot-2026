"""ONE-TIME holdout run for the strategies that advanced in dev (registration section 6). Written AFTER registration, lives outside the
frozen manifest (results/ is excluded); it only applies the registered rule to the frozen modules. Its own sha256 is stored in the report."""
import hashlib
import json
import os
import subprocess
import sys
import time

import pandas as pd

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, ROOT)
from exp003 import config as C                                              # noqa: E402
from exp003.data import load_bars, load_funding_index                        # noqa: E402
from exp003.run_dev import stats                                             # noqa: E402
from exp003.strategies import eligible_mask, run_strategy                    # noqa: E402
from experiment_001.block_bootstrap import analyze                           # noqa: E402
from experiment_001.metrics import clean                                     # noqa: E402
from experiment_001.null_model import run_conditional_null                   # noqa: E402

MARK = os.path.join(ROOT, "results", "HOLDOUT_CONSUMED.txt")
REPORT = os.path.join(ROOT, "results", "holdout_report.json")
r = subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "make_manifest.py"), "--verify"], capture_output=True, text=True)
if r.returncode != 0:
    raise SystemExit("ABORT: frozen code/config/registration changed")
if os.path.exists(MARK) and os.path.exists(REPORT):
    raise SystemExit("ABORT: the holdout has already been consumed")
token = hashlib.sha256(open(os.path.join(ROOT, "PREREGISTRATION_Experiment_003.md"), "rb").read()).hexdigest()
open(MARK, "w").write(f"STARTED {pd.Timestamp.now(tz='UTC').isoformat()} token {token}\n")
dev = json.load(open(os.path.join(ROOT, "results", "dev_report.json")))
advanced = [k for k in dev["advance_to_holdout"] if k in C.TREND]
k_adv = len(advanced)
alpha = C.HOLDOUT_ALPHA_TOTAL / k_adv
t0 = time.time()
bars, fidx = {}, {}
for s in C.SYMBOLS:
    bars[s] = load_bars(s, "holdout", unlock_token=token)
    fidx[s], _ = load_funding_index(s, "holdout")
hold_start = pd.Timestamp(C.HOLDOUT_START)
start_idx = int((hold_start - bars[C.SYMBOLS[0]]["time"].iloc[0]) / pd.Timedelta("5min"))
window_days = int((pd.Timestamp(C.HOLDOUT_END) - hold_start).days)
report = {"experiment": "003-holdout-ONE-TIME", "registration_sha256": token, "advanced": advanced, "alpha_one_sided": alpha,
          "runner_sha256": hashlib.sha256(open(__file__, "rb").read()).hexdigest(), "entry_start_idx": start_idx,
          "window": [C.HOLDOUT_START, C.HOLDOUT_END],
          "data_quality": {s: {"filled_5m_bars": int(bars[s]["filled"].sum()), "bars": int(len(bars[s]))} for s in C.SYMBOLS},
          "results": {}}
for name in advanced:
    spec = C.TREND[name]
    m = spec["agg_minutes"] // 5
    H5 = spec["max_hold_agg_bars"] * m
    fp = pd.concat([run_strategy(bars[s], name, spec, fidx[s], C.COSTS, symbol=s, entry_start_idx=start_idx) for s in C.SYMBOLS],
                   ignore_index=True)
    st = stats(fp, window_days)
    res = {"stats": st}
    if len(fp) >= 3:
        kw = dict(block_days=C.BOOT["block_days"], window_days=window_days, alpha_one_sided=alpha, B=C.BOOT["B"], seed=C.BOOT["seed"])
        gci, nci = analyze(fp["r_gross"].to_numpy(), fp["exit_time"], **kw), analyze(fp["r_full"].to_numpy(), fp["exit_time"], **kw)
        null, _ = run_conditional_null(fp, {s: bars[s] for s in C.SYMBOLS}, fidx, n_runs=C.NULL["runs"], seed=C.NULL["seed"], stride=m,
                                       first_entry=start_idx, horizon_bars=H5,
                                       masks={s: eligible_mask(bars[s], H5) for s in C.SYMBOLS})
        p = null["ALL"]["gross"]["p"]
        res.update(gross_ci=gci, net_ci=nci, null=null["ALL"])
        if st["n"] < 40:
            res["state"] = "INCONCLUSIVE_TOO_FEW_TRADES"
        elif gci["lo"] > 0 and p < alpha and nci["lo"] > 0:
            res["state"] = "EDGE_SUPPORTED_ON_HOLDOUT"
        else:
            res["state"] = "RETIRE"
        res["checks"] = {"gross_lower_gt_0": gci["lo"] > 0, "null_p_lt_alpha": p < alpha, "net_lower_gt_0": nci["lo"] > 0, "n_ge_40": st["n"] >= 40}
    else:
        res["state"] = "INCONCLUSIVE_TOO_FEW_TRADES"
    report["results"][name] = res
    fp.to_csv(os.path.join(ROOT, "results", f"holdout_trades_{name}.csv"), index=False)
report["seconds"] = round(time.time() - t0)
json.dump(clean(report), open(REPORT, "w"), indent=1)
open(MARK, "a").write(f"COMPLETED {pd.Timestamp.now(tz='UTC').isoformat()}\n")
print(json.dumps(clean({n: {"state": v["state"], "n": v["stats"]["n"], "gross": v["stats"].get("gross", {}).get("expectancy_r"),
                            "net": v["stats"].get("net", {}).get("expectancy_r"), "gross_ci": [v.get("gross_ci", {}).get(x) for x in ("lo", "point", "hi")],
                            "net_ci": [v.get("net_ci", {}).get(x) for x in ("lo", "point", "hi")],
                            "null_p": v.get("null", {}).get("gross", {}).get("p"), "checks": v.get("checks")} for n, v in report["results"].items()}), indent=1))
