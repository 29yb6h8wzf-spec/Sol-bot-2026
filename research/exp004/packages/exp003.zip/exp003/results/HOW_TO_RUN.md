Experiment 003 (dev window). Requirements: the experiment_001 package (b1_b9) on EXP001_PATH, the extracted monthly 5m + fundingRate zips in EXP003_DATA.
  EXP001_PATH=/path/to/experiment_001_parent EXP003_DATA=/path/to/data python -m unittest discover -s tests
  python scripts/make_manifest.py --verify        # must print VERIFIED (code/config/registration unchanged since registration)
  python -m exp003.run_dev                         # dev window only; the holdout is not loadable without the unlock token
Registration SHA-256 (PREREGISTRATION_Experiment_003.md): 10e211005fe19e871803f219ccf9d9a64b504e870229d91838e480181a35233e
Frozen manifest root: cb2efccceb5faa6bc50c17d7e973264049b09a4d8cc5bb928790b9d6f39bf8f4
