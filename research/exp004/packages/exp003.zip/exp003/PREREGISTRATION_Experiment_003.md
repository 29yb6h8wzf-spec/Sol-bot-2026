# Pre-registration - Experiment 003: new strategy families (higher-timeframe trend, funding carry)
Research / paper only. Nothing here authorizes live trading. Written and hashed BEFORE any strategy was run on any data.

## 1. Why
Experiment 001/002 showed zero gross edge for the 5m-scalping V3 signals and costs of ~0.56R per trade. This experiment tests two different sources of edge:
(a) trend breakouts on 1h/4h with wide stops (cost in R ~0.06-0.12R instead of 0.56R), (b) delta-neutral funding carry.
No claim is made in advance that either works.

## 2. Data and the lock
Symbols SOLUSDT, XRPUSDT; official Binance monthly 5m klines and funding history (the 24-month archive supplied by the owner).
Development window: 2024-11-01 .. 2026-04-30 (18 months). Holdout: 2026-05-01 .. 2026-10-31 (6 months).
The dev code PHYSICALLY never loads a bar at/after 2026-05-01 (tested). The holdout loader refuses to run without the unlock token (this document's SHA-256).
Disclosure: the old V3 strategies were evaluated on these months (by the owner's pipeline); the NEW strategies below never have been. The assistant has seen
September 2026 pilot figures of the OLD strategies only. Market-structure knowledge (e.g. that crypto trends) is not a clean blank; this limits, but does not remove, the value of the holdout.
A 1-day data gap exists in both symbols; gap bars are forward-filled and flagged; no signal or trade may touch a flagged bar.

## 3. Trend strategies (parameters fixed here, nothing tuned)
Signal on a CLOSED aggregated bar (UTC-aligned), entry at the next 5m open (slippage 2 bp adverse), one position per symbol per strategy, no overlap.
Long if close > highest high of the previous N bars; short if close < lowest low of the previous N bars. ATR = simple mean of true range over 14 bars.
Stop = signal-bar close -/+ 2.0 ATR, target = close +/- 4.0 ATR (fixed references), engine accounting (stop-first on the same 5m bar, gap-through stop fills at the open),
fee 5 bp/side, historical funding charged for the actual hold window. Dev trades must complete inside the dev window.
- T4: 4h bars, N=20, max hold 42 bars (7 days).   - T1: 1h bars, N=48, max hold 72 bars (3 days).
Robustness (reported only, never used to choose): N in {10,20,40} for T4, {24,48,96} for T1.

## 4. Funding carry (long spot + short perp, notional-matched)
Enter when the trailing mean of the previous 9 funding payments >= 0.00008, exit when < 0.00002 (decision uses payments strictly before the one being earned).
Costs per entry and per exit: spot 10 bp + perp 5 bp + 2 x 2 bp slippage. Capital per unit notional = 1 + 1/3 (perp leverage 3). Income = funding payments only.
UPPER-BOUND estimate: basis moves, margin events, borrow/transfer frictions are NOT modeled. Absolute scale reported for 150 USD.
Carry advances iff pooled (mean of the two symbols) net annualized yield on capital >= 5% AND share of positive months >= 75%.

## 5. Dev screening (all must hold, strict) for T1 and T4, pooled over both symbols
n >= 60 trades; net expectancy > 0; lower bound of the gross 7-day-block studentized bootstrap interval (one-sided alpha 0.05, B=10,000, seed 20261111) > 0;
conditional-null gross p < 0.10 (2,000 runs, stride = aggregated bar, per-symbol overlap, gap-masked grid).
If nothing advances, the answer is "no edge found in these families"; the holdout is not run and no variant is added afterwards.

## 6. Holdout (ONE run, only after the owner's explicit go-ahead)
Run only the advanced strategies, once, with the dev-frozen parameters. k = number of advanced trend strategies; one-sided alpha = 0.05/k.
EDGE_SUPPORTED_ON_HOLDOUT iff gross lower bound > 0 AND null p < alpha AND net lower bound > 0 (strict); otherwise retire. Minimum 40 holdout trades, else INCONCLUSIVE.
No parameter, rule or threshold may change after the holdout is touched. Carry: same criteria as section 4 on the holdout.
Even a positive holdout permits only forward paper trading (from 2026-12-01 on Binance Demo), never live trading. The owner's stated willingness to risk money is noted and is not a basis.

## 7. Known limits
Two symbols, 24 months, one volatility regime sequence; multiple families tested on the dev window (selection is the purpose of dev; the holdout is the confirmation).
Trend results are highly path-dependent with few trades (expect ~100-300 per strategy over 18 months). Carry income is small in absolute terms.
Backtest numbers ignore latency, order-book depth, API limits and exchange outages.
